# 手机端云构建说明（V0.7）

这个项目已经附带 GitHub Actions 自动构建工作流：`.github/workflows/android-build.yml`。
它会在仓库 `main` 分支 push 或手动触发时构建 Debug APK，并把 APK 保存为 Actions Artifact。

## 你需要做的事
1. 在手机浏览器登录 GitHub，创建一个空仓库（建议 Private）。
2. 把本 ZIP 解压后，将项目文件上传到仓库根目录。必须包含 `.github/workflows/android-build.yml`、`settings.gradle`、`build.gradle`、`gradle.properties` 和 `app/` 目录。
3. 提交到 `main` 分支。
4. 打开仓库的 Actions 页面，进入 `Build Android APK` 工作流，等待绿色成功标记。
5. 打开该次运行记录，在 Artifacts 区域下载 `RedFingerGameBot-debug-apk`，解压得到 `app-debug.apk`。
6. 把 APK 安装到红手指，首次打开授予悬浮窗权限，启动服务并允许 Root 授权。

## 重要
- GitHub Actions 的可用性受账户、仓库设置和免费额度限制。
- 该流程需要你在手机浏览器完成仓库创建和源码上传；我不能替你登录或替你点击账户授权。
- 当前工程没有在真实云构建服务中执行过，因此 workflow 仍需首次运行验证。
- APK 即使成功构建，也必须在红手指上验证 Root 授权、截图方向、OCR 和触控。
