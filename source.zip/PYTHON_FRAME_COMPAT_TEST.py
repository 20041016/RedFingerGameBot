"""Host-side smoke test for the Python/Java Map and List compatibility layer."""
from app.src.main.python.python.frame import Frame

class JavaMap:
    def __init__(self, values): self.values = values
    def get(self, key): return self.values.get(key)
    def containsKey(self, key): return key in self.values

class JavaList:
    def __init__(self, values): self.values = values
    def toArray(self): return self.values

raw = JavaMap({
    "width": 1280,
    "height": 720,
    "texts": JavaList([
        JavaMap({"text": "信号区", "left": 100, "top": 200, "right": 180, "bottom": 230}),
        JavaMap({"text": "开始游戏", "bounds": JavaMap({"left": 400, "top": 500, "right": 600, "bottom": 540})}),
    ]),
})
f = Frame.from_host(raw)
assert (f.width, f.height) == (1280, 720)
assert f.has("信号区") and f.find("信号区").center_x == 140
assert f.find("开始游戏").center_y == 520

py = Frame.from_host({"width": 720, "height": 1280, "texts": [{"text": "大厅", "left": 1, "top": 2, "right": 3, "bottom": 4}]})
assert py.full_text == "大厅"
print("Frame compatibility tests passed")
