import random
import time
from .config import *
from .coordinate import CoordinateMapper
from .frame import Frame


class GameBot:
    """V0.9 migration engine. Original scene keywords and game coordinates retained."""

    def __init__(self, host):
        self.host = host
        self.running = False
        self.state = "待命"
        self.diagnostic = "等待识别"
        self.mapper = None
        self.jump_coords = None
        self.jump_appear_ms = None
        self.jump_clicked = False
        self.flight_lost_count = 0
        self.is_sprinting = False
        self.need_reclick_run = False
        self.last_signal_exists = False
        self.signal_lost_start_ms = None
        self.continue_first_seen_ms = None
        self.next_extra_click_ms = None
        self.next_search_swipe_ms = 0
        self.rng = random.Random()

    def start(self):
        # 每次点击启动都重新识别当前画面；绝不默认大厅。
        self._reset()
        self.rng = random.Random()
        self.diagnostic = "正在获取首帧"
        self.running = True
        self.state = "识别中"
        self._log("挂机启动：开始识别当前游戏场景")

    def stop(self):
        self.running = False
        self.state = "已暂停"
        self.is_sprinting = False
        self._log("挂机已暂停")

    def step(self):
        if not self.running:
            return

        now = int(time.monotonic() * 1000)
        frame = Frame.from_host(self.host.capture())
        self.mapper = CoordinateMapper(frame.width, frame.height)
        full_text = frame.full_text
        self.diagnostic = full_text[:100] if full_text else "（本帧未识别到文字）"

        # 初始识别期间不执行任何游戏点击，避免未知画面误点大厅按钮。
        scene = self.detect_scene(frame)
        if self.state in ("待命", "识别中"):
            if scene is None:
                self._log("场景尚未识别；OCR=" + self.diagnostic)
                return
            self._adopt(scene)
            self._log("启动场景识别成功：" + scene + "；OCR=" + self.diagnostic)

        # 与原脚本一致：高优先级文字在常规场景逻辑之前处理。
        for word in HIGH_PRIORITY_TEXTS:
            item = frame.find(word)
            if item:
                self._tap_screen(item.center_x, item.center_y)
                self._log("高优先级点击：" + word)
                return

        if scene == "大厅":
            self._enter("大厅")
            self._tap_text(frame, "开始游戏")
            return

        if scene == "跳伞" and self.state not in ("等待跳伞", "飞行中"):
            self._enter("等待跳伞")
            self.jump_coords = None
            self.jump_appear_ms = None
            self.jump_clicked = False
        if scene == "飞行中" and self.state != "飞行中":
            self._enter("飞行中")
            self.jump_clicked = True
        if scene == "结算过渡":
            self._enter("结算过渡")

        if self.state in ("等待跳伞", "飞行中"):
            self._flight(frame, now)
            return
        if self.state == "结算过渡":
            if self._tap_text(frame, "继续"):
                return
            if self._tap_text(frame, "返回大厅"):
                self._reset()
                self._enter("大厅")
            return
        if self.state == "大厅":
            self._tap_text(frame, "开始游戏")
            return
        if self.state in ("战斗中奔跑", "战斗中寻敌"):
            self._battle(frame, now)

    def detect_scene(self, f):
        # 保留原始 609 行脚本 detectScene() 的场景关键词与优先顺序。
        t = f.full_text
        if "离开" in t or "舱内人数" in t:
            return "跳伞"
        if "请勿在现实中模仿" in t:
            return "飞行中"
        if "淘汰详情" in t or "返回大厅" in t:
            return "结算过渡"
        if "信号区" in t:
            return "战斗"
        if "剩余" in t:
            return "战斗"
        if "特惠" in t and "开始游戏" in t:
            return "大厅"
        return None

    def _adopt(self, scene):
        mapping = {
            "跳伞": "等待跳伞",
            "飞行中": "飞行中",
            "战斗": "战斗中寻敌",
            "结算过渡": "结算过渡",
            "大厅": "大厅",
        }
        state = mapping.get(scene)
        if state is None:
            self._enter("识别中")
            return
        self._enter(state)
        if scene == "飞行中":
            self.jump_clicked = True

    def _flight(self, f, now):
        if not self.jump_clicked:
            item = f.find("离开")
            if item and self.jump_coords is None:
                self.jump_coords = (item.center_x, item.center_y)
                self.jump_appear_ms = now
            if self.jump_coords and now - self.jump_appear_ms >= JUMP_WAIT_MS:
                self._tap_screen(*self.jump_coords)
                self.jump_clicked = True
                self.jump_coords = None
                self._enter("飞行中")
            return
        if f.has("请勿在现实中模仿"):
            self.flight_lost_count = 0
            return
        self.flight_lost_count += 1
        if self.flight_lost_count >= FLIGHT_LOST_THRESHOLD:
            self.flight_lost_count = 0
            self.jump_clicked = False
            self.need_reclick_run = True
            self._enter("战斗中寻敌")

    def _battle(self, f, now):
        if f.has("淘汰详情") or f.has("返回大厅"):
            self._enter("结算过渡")
            return
        if f.has("继续"):
            if self.continue_first_seen_ms is None:
                self.continue_first_seen_ms = now
            elif now - self.continue_first_seen_ms >= CONTINUE_CONFIRM_MS:
                self._enter("结算过渡")
                return
        else:
            self.continue_first_seen_ms = None

        signal = f.find("信号区")
        exists = signal is not None
        if exists and not self.last_signal_exists:
            self.need_reclick_run = True
            self.signal_lost_start_ms = None
        self.last_signal_exists = exists

        if exists:
            self._enter("战斗中奔跑")
            self.signal_lost_start_ms = None
            if not self.is_sprinting or self.need_reclick_run:
                self._tap_ref(*RUN_BUTTON)
                self.is_sprinting = True
                self.need_reclick_run = False
                self.next_extra_click_ms = now + self.rng.randint(
                    EXTRA_CLICK_MIN_MS, EXTRA_CLICK_MAX_MS)
            elif self.next_extra_click_ms is not None and now >= self.next_extra_click_ms:
                self._tap_ref(*EXTRA_BUTTON)
                self.next_extra_click_ms = now + self.rng.randint(
                    EXTRA_CLICK_MIN_MS, EXTRA_CLICK_MAX_MS)
            sx, _ = self.mapper.to_reference(signal.center_x, signal.center_y)
            dx = REFERENCE_WIDTH / 2 - sx
            if abs(dx) > DEAD_ZONE_REFERENCE_PX:
                x1, y = REFERENCE_WIDTH * .75, REFERENCE_HEIGHT / 2
                self._swipe_ref(x1, y, max(0, min(REFERENCE_WIDTH, x1 - dx * .3)), y, 200)
            return

        if self.is_sprinting:
            if self.signal_lost_start_ms is None:
                self.signal_lost_start_ms = now
            elif now - self.signal_lost_start_ms >= SIGNAL_WAIT_MS:
                self._tap_ref(*RUN_BUTTON)
                self.is_sprinting = False
                self.signal_lost_start_ms = None
                self._enter("战斗中寻敌")
            return

        self._enter("战斗中寻敌")
        if now >= self.next_search_swipe_ms:
            self._swipe_ref(960, 360, 660, 360, SEARCH_SWIPE_DURATION_MS)
            self.next_search_swipe_ms = now + SEARCH_SWIPE_DURATION_MS + SEARCH_SWIPE_PAUSE_MS

    def _reset(self):
        self.jump_coords = self.jump_appear_ms = None
        self.jump_clicked = False
        self.flight_lost_count = 0
        self.is_sprinting = False
        self.need_reclick_run = False
        self.last_signal_exists = False
        self.signal_lost_start_ms = self.continue_first_seen_ms = None
        self.next_extra_click_ms = None
        self.next_search_swipe_ms = 0

    def _tap_text(self, f, word):
        item = f.find(word)
        if not item:
            return False
        self._tap_screen(item.center_x, item.center_y)
        return True

    def _tap_screen(self, x, y):
        x = max(0, min(self.mapper.screen_width - 1, round(x)))
        y = max(0, min(self.mapper.screen_height - 1, round(y)))
        self.host.tap(x, y)

    def _tap_ref(self, x, y):
        self.mapper.tap(self.host, x, y)

    def _swipe_ref(self, x1, y1, x2, y2, duration):
        self.mapper.swipe(self.host, x1, y1, x2, y2, duration)

    def _enter(self, state):
        if self.state != state:
            self.state = state
            self._log("状态：" + state)

    def _log(self, msg):
        logger = getattr(self.host, "log", None)
        if callable(logger):
            logger(msg)
