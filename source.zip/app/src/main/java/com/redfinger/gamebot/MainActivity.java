package com.redfinger.gamebot;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 701;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);

        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);

        TextView title = new TextView(this);

        title.setText("RedFinger GameBot V0.9");
        title.setTextSize(22);

        layout.addView(title);

        TextView info = new TextView(this);

        info.setText(
                "打开应用不会自动启动挂机。\n\n" +
                "请先授予悬浮窗权限，再打开悬浮窗控制面板。\n\n" +
                "挂机的启动和停止都在悬浮窗内操作。"
        );

        info.setTextSize(15);

        layout.addView(info);

        // 悬浮窗权限按钮。
        Button permission = new Button(this);

        permission.setText("授予悬浮窗权限");

        permission.setOnClickListener(v -> {
            requestOverlayPermission();
        });

        layout.addView(permission);

        // 打开控制面板按钮。
        Button show = new Button(this);

        show.setText("打开悬浮窗控制面板");

        show.setOnClickListener(v -> {

            if (!Settings.canDrawOverlays(this)) {

                requestOverlayPermission();
                return;
            }

            Intent intent =
                    new Intent(this, BotService.class);

            intent.setAction(BotService.ACTION_SHOW);

            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        });

        layout.addView(show);

        setContentView(layout);
    }

    private void requestOverlayPermission() {

        if (!Settings.canDrawOverlays(this)) {

            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );

            startActivityForResult(
                    intent,
                    REQ_OVERLAY
            );
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode == REQ_OVERLAY
                && Settings.canDrawOverlays(this)) {

            // 授权完成后不自动启动挂机。
            // 用户需要自己点击“打开悬浮窗控制面板”。
        }
    }
}