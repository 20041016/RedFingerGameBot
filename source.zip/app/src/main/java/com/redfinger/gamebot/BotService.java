package com.redfinger.gamebot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BotService extends Service {

    public static final String ACTION_SHOW =
            "com.redfinger.gamebot.SHOW";
    public static final String ACTION_START_ENGINE =
            "com.redfinger.gamebot.START_ENGINE";
    public static final String ACTION_STOP_ENGINE =
            "com.redfinger.gamebot.STOP_ENGINE";
    public static final String ACTION_CLOSE =
            "com.redfinger.gamebot.CLOSE";

    private static final String CHANNEL = "rfgb_service";
    private static final int NOTIFICATION_ID = 601;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker =
            Executors.newSingleThreadExecutor();

    private volatile boolean active = false;
    private volatile boolean engineTaskRunning = false;
    private volatile boolean closeRequested = false;

    private RootHost host;
    private PyObject engine;

    private WindowManager windowManager;
    private View overlay;
    private TextView status;
    private WindowManager.LayoutParams overlayParams;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        windowManager = (WindowManager)
                getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        String action = intent == null
                ? ACTION_SHOW : intent.getAction();

        startForeground(
                NOTIFICATION_ID,
                buildNotification("控制面板已就绪")
        );

        if (ACTION_SHOW.equals(action)) {

            // 只显示悬浮窗，不启动挂机引擎。
            closeRequested = false;
            showOverlay();
            updateStatus(active ? "挂机运行中" : "已停止");

        } else if (ACTION_START_ENGINE.equals(action)) {

            closeRequested = false;
            showOverlay();
            startEngine();

        } else if (ACTION_STOP_ENGINE.equals(action)) {

            // 只停止挂机，不关闭面板和服务。
            stopEngine();

        } else if (ACTION_CLOSE.equals(action)) {

            // 只有明确关闭面板才移除悬浮窗。
            closePanel();

        } else {

            showOverlay();
            updateStatus(active ? "挂机运行中" : "已停止");
        }

        return START_STICKY;
    }

    /**
     * 启动挂机引擎。
     */
    private synchronized void startEngine() {

        if (active) {
            updateStatus("挂机运行中");
            return;
        }

        if (engineTaskRunning) {
            updateStatus("正在停止，请稍后再启动");
            return;
        }

        active = true;
        closeRequested = false;
        engineTaskRunning = true;

        updateStatus("正在初始化并识别场景");

        worker.execute(this::initializeAndLoop);
    }

    /**
     * 停止挂机，但保留悬浮窗。
     */
    private synchronized void stopEngine() {

        active = false;

        if (engineTaskRunning) {
            updateStatus("正在停止挂机…");
        } else {
            updateStatus("已停止（控制面板仍保留）");
        }
    }

    /**
     * 关闭整个控制面板。
     */
    private synchronized void closePanel() {

        closeRequested = true;
        active = false;

        if (!engineTaskRunning) {
            removeOverlayNow();
            stopForeground(true);
            stopSelf();
        } else {
            updateStatus("正在停止并关闭面板…");
        }
    }

    /**
     * Python 引擎工作线程。
     */
    private void initializeAndLoop() {

        try {

            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }

            host = new RootHost(getCacheDir());

            // Root 授权检查。
            String rootInfo = host.checkRoot();

            host.log("Root 授权成功：" + rootInfo);

            updateStatus("Root 已授权，正在初始化 OCR");

            // 初始化 Python 引擎。
            PyObject module =
                    Python.getInstance().getModule("python.bot");

            engine = module.callAttr("GameBot", host);

            // 每次启动都重置状态机并重新识别场景。
            engine.callAttr("start");

            updateStatus("正在识别当前游戏场景");

            while (active) {

                try {

                    engine.callAttr("step");

                    String currentState =
                            engine.get("state").toJava(String.class);

                    updateStatus(currentState);

                } catch (Exception e) {

                    if (host != null) {
                        host.log("挂机循环错误：" + e);
                    }

                    updateStatus("运行错误：" + e.getMessage());

                    Thread.sleep(1000);
                }

                if (active) {
                    Thread.sleep(300);
                }
            }

        } catch (Exception e) {

            android.util.Log.e(
                    "RFG-Service",
                    "初始化失败",
                    e
            );

            updateStatus("初始化失败：" + e.getMessage());

            active = false;

        } finally {

            try {
                if (engine != null) {
                    engine.callAttr("stop");
                }
            } catch (Exception ignored) {
            }

            try {
                if (host != null) {
                    host.close();
                }
            } catch (Exception ignored) {
            }

            host = null;
            engine = null;

            engineTaskRunning = false;

            main.post(() -> {

                if (closeRequested) {

                    removeOverlayNow();
                    stopForeground(true);
                    stopSelf();

                } else {

                    updateStatus("已停止（控制面板仍保留）");
                }
            });
        }
    }

    /**
     * 创建悬浮窗控制面板。
     */
    private void showOverlay() {

        if (!Settings.canDrawOverlays(this)) {
            return;
        }

        if (overlay != null) {
            return;
        }

        LinearLayout panel = new LinearLayout(this);

        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(10, 6, 10, 6);
        panel.setBackgroundColor(0xEE202020);

        // 标题。
        TextView title = new TextView(this);

        title.setText("RedFinger GameBot V0.9");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(14);

        panel.addView(title);

        // 状态。
        status = new TextView(this);

        status.setTextColor(0xFFFFFFFF);
        status.setText("状态：已停止");

        panel.addView(status);

        // 启动挂机按钮。
        Button start = new Button(this);

        start.setText("启动挂机");

        start.setOnClickListener(v -> {
            closeRequested = false;
            startEngine();
        });

        panel.addView(start);

        // 停止挂机按钮。
        Button stop = new Button(this);

        stop.setText("停止挂机");

        stop.setOnClickListener(v -> {
            stopEngine();
        });

        panel.addView(stop);

        // 关闭面板按钮。
        Button close = new Button(this);

        close.setText("关闭面板");

        close.setOnClickListener(v -> {
            closePanel();
        });

        panel.addView(close);

        overlayParams = new WindowManager.LayoutParams(

                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,

                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,

                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,

                PixelFormat.TRANSLUCENT
        );

        overlayParams.gravity =
                Gravity.TOP | Gravity.LEFT;

        overlayParams.x = 12;
        overlayParams.y = 120;

        // 拖动悬浮窗。
        final int[] down = new int[2];
        final float[] touch = new float[2];

        panel.setOnTouchListener((v, event) -> {

            if (event.getAction() == MotionEvent.ACTION_DOWN) {

                down[0] = overlayParams.x;
                down[1] = overlayParams.y;

                touch[0] = event.getRawX();
                touch[1] = event.getRawY();

                return false;
            }

            if (event.getAction() == MotionEvent.ACTION_MOVE) {

                overlayParams.x =
                        down[0] + (int) (event.getRawX() - touch[0]);

                overlayParams.y =
                        down[1] + (int) (event.getRawY() - touch[1]);

                try {
                    windowManager.updateViewLayout(
                            panel,
                            overlayParams
                    );
                } catch (Exception ignored) {
                }

                return true;
            }

            return false;
        });

        overlay = panel;

        try {

            windowManager.addView(
                    overlay,
                    overlayParams
            );

        } catch (Exception e) {

            android.util.Log.e(
                    "RFG-Service",
                    "悬浮窗创建失败",
                    e
            );

            overlay = null;
            status = null;
        }
    }

    /**
     * 更新悬浮窗状态和通知。
     */
    private void updateStatus(String value) {

        main.post(() -> {

            if (status != null) {
                status.setText("状态：" + value);
            }

            NotificationManager nm =
                    getSystemService(NotificationManager.class);

            if (nm != null) {
                nm.notify(
                        NOTIFICATION_ID,
                        buildNotification(value)
                );
            }
        });
    }

    /**
     * 立即移除悬浮窗。
     * 只在明确关闭面板时调用。
     */
    private void removeOverlayNow() {

        if (overlay != null) {

            try {
                windowManager.removeView(overlay);
            } catch (Exception ignored) {
            }

            overlay = null;
            status = null;
        }
    }

    private Notification buildNotification(String text) {

        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("RedFinger GameBot")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {

        if (Build.VERSION.SDK_INT >= 26) {

            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL,
                            "挂机服务",
                            NotificationManager.IMPORTANCE_LOW
                    );

            getSystemService(NotificationManager.class)
                    .createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {

        active = false;

        removeOverlayNow();

        worker.shutdown();

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}