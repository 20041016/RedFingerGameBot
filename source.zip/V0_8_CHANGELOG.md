# RedFinger GameBot V0.8

## 修复内容
- 修复 Chaquopy 将 Java `HashMap` 传入 Python 后，`raw["width"]` / `item.get(..., default)` 引发的 `TypeError`。
- `Frame.from_host()` 现在兼容 Python `dict`、Java `Map`、Python list/tuple，以及可通过 `toArray()` 或 `iterator()` 遍历的 Java List。
- 增加空截图数据、缺少宽高和非法尺寸的明确错误提示。
- Android `versionCode` 更新为 7，`versionName` 更新为 0.8.0。
- 原状态机逻辑、中文 OCR 匹配方式、参考坐标 1280×720、奔跑按钮 `(1066, 194)` 和额外按钮 `(1231, 503)` 均保持不变。

## 验证范围
- 主机侧 Python 兼容性测试覆盖 Java Map/List 模拟对象和 Python dict/list。
- 这不是 Android 实机测试；仍需在红手指安装新 APK 后验证 Root 截图、OCR 和触控。
