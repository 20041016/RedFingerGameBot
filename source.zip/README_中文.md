# RedFinger GameBot V0.7 — Android 集成与云构建版

V0.7 在 V0.6 基础上完善了 Root 授权预检、悬浮窗拖动、服务停止流程，并加入 GitHub Actions 云端 APK 构建配置。

## 已包含
- Android Activity 启停入口
- 前台 Service 和悬浮窗状态面板（可拖动）
- RootHost：Root 检查、截图、中文 ML Kit OCR、点击、滑动
- Chaquopy 内嵌 Python 状态机
- 1280×720 参考坐标及原始按钮坐标 `(1066,194)`、`(1231,503)`
- GitHub Actions Debug APK 构建工作流

## 构建
请查看 `CLOUD_BUILD_手机端说明.md`。首次构建需要在云端运行 Gradle；当前没有可验证的 APK 文件。

## 重要实测限制
终端里 `su` 成功不等于 APK 获得 Root。本版本在引擎开始截图和点击前先执行 `id` 检查；未得到 uid=0 时会显示初始化失败并停止。
截图方向、ML Kit 中文识别、红手指 Root 对应用缓存目录的访问仍需在目标云手机实测。
