package com.redfinger.gamebot;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Root-only type-B multitouch injector using sendevent. Device support must be verified per handset. */
public final class RootTouchController implements AutoCloseable {
    private static final String TAG = "RFG-Touch";
    private static final int EV_SYN = 0, EV_ABS = 3;
    private static final int SYN_REPORT = 0, ABS_MT_SLOT = 0x2f;
    private static final int ABS_MT_POSITION_X = 0x35, ABS_MT_POSITION_Y = 0x36;
    private static final int ABS_MT_TRACKING_ID = 0x39;
    private static final Pattern DEVICE = Pattern.compile("add device \\d+: (\\S+)");
    private static final Pattern ABS_LINE = Pattern.compile("(\\w{4})\\s*:\\s*value (-?\\d+), min (-?\\d+), max (-?\\d+)");

    private final String suPath;
    private final int logicalWidth, logicalHeight;
    private String eventPath;
    private int minX, maxX, minY, maxY, maxSlot = 9;
    private Process shell;
    private OutputStream shellIn;
    private int nextTrackingId = 100;
    private final int[] trackingIds = new int[10];

    public RootTouchController(String suPath, int logicalWidth, int logicalHeight) {
        this.suPath = suPath;
        this.logicalWidth = logicalWidth;
        this.logicalHeight = logicalHeight;
        for (int i = 0; i < trackingIds.length; i++) trackingIds[i] = -1;
    }

    public synchronized String initialize() throws Exception {
        String listing = run("getevent -lp");
        parseDevice(listing);
        shell = new ProcessBuilder(suPath).redirectErrorStream(true).start();
        shellIn = shell.getOutputStream();
        // Drain shell output so a rejected sendevent cannot fill the pipe.
        Thread drain = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(shell.getInputStream()))) {
                while (r.readLine() != null) { /* drain */ }
            } catch (Exception ignored) {}
        }, "rfg-root-touch-output");
        drain.setDaemon(true);
        drain.start();
        write("id");
        return eventPath + " X[" + minX + "," + maxX + "] Y[" + minY + "," + maxY + "] slots=" + (maxSlot + 1);
    }

    private void parseDevice(String listing) {
        String current = null;
        boolean hasX = false, hasY = false, hasSlot = false, hasTracking = false;
        int lx = 0, hx = 0, ly = 0, hy = 0, slots = 9;
        String[] lines = listing.split("\\r?\\n");
        for (String line : lines) {
            Matcher dm = DEVICE.matcher(line.trim());
            if (dm.find()) {
                if (current != null && hasX && hasY && hasSlot && hasTracking && slots >= 5) {
                    eventPath = current; minX = lx; maxX = hx; minY = ly; maxY = hy; maxSlot = slots;
                    return;
                }
                current = dm.group(1);
                hasX = hasY = hasSlot = hasTracking = false;
                continue;
            }
            Matcher am = ABS_LINE.matcher(line.trim());
            if (!am.find()) continue;
            String code = am.group(1).toLowerCase(Locale.ROOT);
            int min = Integer.parseInt(am.group(3)), max = Integer.parseInt(am.group(4));
            if ("0035".equals(code)) { hasX = true; lx = min; hx = max; }
            else if ("0036".equals(code)) { hasY = true; ly = min; hy = max; }
            else if ("002f".equals(code)) { hasSlot = true; slots = Math.max(0, max); }
            else if ("0039".equals(code)) hasTracking = true;
        }
        if (current != null && hasX && hasY && hasSlot && hasTracking && slots >= 5) {
            eventPath = current; minX = lx; maxX = hx; minY = ly; maxY = hy; maxSlot = slots; return;
        }
        throw new IllegalStateException("未找到支持 Type-B 多点触控的设备节点。请提供 getevent -lp 输出；部分设备需适配 Type-A 或厂商驱动。");
    }

    public synchronized void down(int x, int y, int pointerId) throws Exception {
        ensureReady(pointerId);
        int rawX = scale(x, logicalWidth, minX, maxX);
        int rawY = scale(y, logicalHeight, minY, maxY);
        if (trackingIds[pointerId] < 0) trackingIds[pointerId] = nextTrackingId++;
        send(ABS_MT_SLOT, pointerId);
        send(ABS_MT_TRACKING_ID, trackingIds[pointerId]);
        send(ABS_MT_POSITION_X, rawX);
        send(ABS_MT_POSITION_Y, rawY);
        sync();
    }

    public synchronized void up(int pointerId) throws Exception {
        ensureReady(pointerId);
        if (trackingIds[pointerId] < 0) return;
        send(ABS_MT_SLOT, pointerId);
        send(ABS_MT_TRACKING_ID, -1);
        sync();
        trackingIds[pointerId] = -1;
    }

    public synchronized void releaseAll() {
        if (shell == null || shellIn == null) return;
        for (int i = 0; i < trackingIds.length; i++) {
            if (trackingIds[i] >= 0) {
                try { send(ABS_MT_SLOT, i); send(ABS_MT_TRACKING_ID, -1); sync(); }
                catch (Exception e) { Log.w(TAG, "释放触点失败", e); }
                trackingIds[i] = -1;
            }
        }
    }

    private int scale(int value, int logicalSize, int min, int max) {
        int clamped = Math.max(0, Math.min(logicalSize - 1, value));
        return min + Math.round((max - min) * (clamped / (float) Math.max(1, logicalSize - 1)));
    }

    private void ensureReady(int pointerId) {
        if (shell == null || !shellAlive()) throw new IllegalStateException("Root 多点触控会话未初始化或已退出");
        if (pointerId < 0 || pointerId > maxSlot || pointerId >= trackingIds.length)
            throw new IllegalArgumentException("触点 ID 超出设备支持范围：" + pointerId);
    }

    private boolean shellAlive() {
        try { shell.exitValue(); return false; }
        catch (IllegalThreadStateException stillRunning) { return true; }
    }

    private void send(int code, int value) throws Exception { write("sendevent " + eventPath + " " + EV_ABS + " " + code + " " + value); }
    private void sync() throws Exception { write("sendevent " + eventPath + " " + EV_SYN + " " + SYN_REPORT + " 0"); }
    private void write(String command) throws Exception { shellIn.write((command + "\n").getBytes("UTF-8")); shellIn.flush(); }

    private String run(String command) throws Exception {
        Process p = new ProcessBuilder(suPath, "-c", command).redirectErrorStream(true).start();
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line; while ((line = r.readLine()) != null) b.append(line).append('\n');
        }
        int code = p.waitFor();
        if (code != 0) throw new IllegalStateException("Root 命令失败：" + b);
        return b.toString();
    }

    @Override public synchronized void close() {
        releaseAll();
        if (shellIn != null) try { shellIn.write("exit\n".getBytes("UTF-8")); shellIn.flush(); } catch (Exception ignored) {}
        if (shell != null) shell.destroy();
        shell = null; shellIn = null;
    }
}
