from dataclasses import dataclass

@dataclass(frozen=True)
class TextItem:
    text: str
    left: float = 0
    top: float = 0
    right: float = 0
    bottom: float = 0

    @property
    def center_x(self):
        return (self.left + self.right) / 2

    @property
    def center_y(self):
        return (self.top + self.bottom) / 2

@dataclass(frozen=True)
class Frame:
    width: int
    height: int
    texts: tuple

    @classmethod
    def from_host(cls, raw):
        width, height = int(raw["width"]), int(raw["height"])
        items = []
        for item in raw.get("texts", []) or []:
            bounds = item.get("bounds", item)
            items.append(TextItem(
                str(item.get("text", "") or ""),
                float(bounds.get("left", 0)), float(bounds.get("top", 0)),
                float(bounds.get("right", 0)), float(bounds.get("bottom", 0))))
        return cls(width, height, tuple(items))

    @property
    def full_text(self):
        return " ".join(x.text for x in self.texts)

    def find(self, needle):
        return next((x for x in self.texts if needle in x.text), None)

    def has(self, needle):
        return self.find(needle) is not None
