"""Host-side smoke test for the six-lane Python engine (does not test Android sendevent)."""
from app.src.main.python.python.music_bot import MusicBot


class FakeHost:
    def __init__(self):
        self.press_blue = [255] * 6
        self.release_blue = [255] * 6
        self.down = []
        self.up = []
        self.released = False

    def initializeMultiTouch(self, width, height):
        assert (width, height) == (1440, 3200)
        return "fake-type-b-device"

    def captureBlueValues(self, xs, press_y, release_y):
        assert xs == [778, 1100, 1440, 1780, 2100, 2440]
        assert (press_y, release_y) == (1120, 1280)
        return {"pressBlue": self.press_blue, "releaseBlue": self.release_blue}

    def touchDown(self, x, y, pointer_id):
        self.down.append((x, y, pointer_id))

    def touchUp(self, pointer_id):
        self.up.append(pointer_id)

    def releaseAllTouches(self):
        self.released = True

    def log(self, message):
        pass


host = FakeHost()
bot = MusicBot(host)
bot.start()
host.press_blue = [100, 100, 255, 100, 255, 100]
bot.step()
assert [x[2] for x in host.down] == [0, 1, 3, 5]
assert [x[1] for x in host.down] == [778, 1100, 1780, 2440]
host.release_blue = [100, 100, 255, 100, 255, 100]
bot.step()
assert host.up == []  # wait until the lower gate has been crossed
host.release_blue = [255] * 6
bot.step()
assert sorted(host.up) == [0, 1, 3, 5]
bot.stop()
assert host.released
print("Music engine smoke test passed")
