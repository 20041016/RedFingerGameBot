"""Smoke test: predictive-only engine; legacy blue-pixel trigger is disabled."""
from app.src.main.python.python.music_bot import MusicBot


class FakeHost:
    def __init__(self):
        self.blue = [100] * 6
        self.down = []
        self.up = []
        self.active = set()
        self.notes = []

    def getMusicPressLeadMs(self):
        return 60

    def getMusicCoordinateConfig(self):
        return [778, 1100, 1440, 1780, 2100, 2440, 1210, 230, -1]

    def initializeMultiTouch(self, width, height):
        assert (width, height) == (1440, 3200)
        return "fake-type-b-device"

    def captureNotes(self, xs, y, half_width, scan_top, scan_bottom):
        return {"blue": self.blue, "notes": self.notes, "captureMs": 0, "decodeMs": 0}

    def updateTouches(self, states, xs, ys):
        assert len(states) == len(xs) == len(ys) == 6
        for i, state in enumerate(states):
            if state and i not in self.active:
                self.down.append(i)
            elif not state and i in self.active:
                self.up.append(i)
        self.active = {i for i, state in enumerate(states) if state}
        return 0

    def releaseAllTouches(self):
        self.active.clear()

    def log(self, message):
        pass


host = FakeHost()
bot = MusicBot(host)
bot.start()

# The Java bridge contract is four integers per note: lane, headY, tailY, type.
host.notes = [0, 1000, 700, 1, 1, 900, -1, 0]
_, parsed, _, _ = bot._capture()
assert parsed[0] == {"lane": 0, "head_y": 1000, "tail_y": 700, "kind": 1}
assert parsed[1] == {"lane": 1, "head_y": 900, "tail_y": -1, "kind": 0}
host.notes = []

# Mechanism B must not press even though all judge-line blue values are below threshold.
bot.step()
assert host.down == [], "blue-pixel fallback unexpectedly pressed a lane"

# Hold note tracking keeps the head and tail separate and predicts tail arrival.
bot.speed = 1.0
bot._update_tracks([{"lane": 2, "head_y": 1000, "tail_y": 700, "kind": 1}], 1000.0)
due = bot._due_presses(1150.0)
assert len(due) == 1 and due[0][2] == 2
assert due[0][3]["kind"] == 1 and due[0][3]["tail_y"] == 700

# A stationary clipped tail (for example behind the floating overlay) is not accepted.
bot._update_tracks([{"lane": 3, "head_y": 500, "tail_y": 200, "kind": 1}], 1000.0)
bot._update_tracks([{"lane": 3, "head_y": 700, "tail_y": 200, "kind": 1}], 1200.0)
clipped = bot.tracks[3][0]
assert not clipped["tail_valid"], "stationary/occluded tail was incorrectly trusted"
# Once the tail edge moves with the head, it becomes a valid release reference.
bot._update_tracks([{"lane": 3, "head_y": 900, "tail_y": 400, "kind": 1}], 1400.0)
assert bot.tracks[3][0]["tail_valid"], "moving hold tail was not validated"

# A predictive press remains held until its predicted hold deadline, then releases.
bot.track_pressed[0] = True
host.active.add(0)
bot.hold_until[0] = bot._now_ms() - 1
bot.step()
assert host.up == [0], "predicted hold deadline did not release the lane"

bot.stop()
print("Predictive-only music engine smoke test passed")
