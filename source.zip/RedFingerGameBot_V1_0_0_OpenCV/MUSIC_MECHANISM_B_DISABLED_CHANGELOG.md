# Music Mechanism B Disabled

- Temporarily disabled the legacy judge-line blue-pixel reactive press trigger.
- Disabled the blue-pixel release gate as well; predictive presses now release when their predicted hold deadline expires (while preserving `MIN_HOLD_MS` and `HOLD_AFTER_ARRIVAL_MS`).
- Kept note detection, tracking, speed estimation, predictive scheduling, and the floating `PRESS_LEAD_MS` setting unchanged.
- Updated diagnostics to report predictive-only mode and updated the host smoke test to verify that low blue values cannot trigger presses.
