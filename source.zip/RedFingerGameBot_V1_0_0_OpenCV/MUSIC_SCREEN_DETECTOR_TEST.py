"""Host-independent tests for MusicScreenDetector."""
import pathlib
import sys

PROJECT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT / "app" / "src" / "main" / "python"))

from python.music_screen_detector import MusicScreenDetector, ScreenState


def frame(*lines):
    return {"width": 1920, "height": 864,
            "texts": [{"text": line} for line in lines]}


def test_song_list_requires_three_frames():
    d = MusicScreenDetector(confirm_frames=3)
    f = frame("前往演奏", "创作曲谱", "须臾的舒闲")
    assert d.observe(f).state == ScreenState.UNKNOWN
    assert d.observe(f).state == ScreenState.UNKNOWN
    assert d.observe(f).state == ScreenState.SONG_LIST


def test_difficulty_screen():
    d = MusicScreenDetector(confirm_frames=1)
    result = d.observe(frame("普通", "困难", "大师", "传说", "开始演奏"))
    assert result.state == ScreenState.DIFFICULTY_SELECT


def test_result_screen():
    d = MusicScreenDetector(confirm_frames=1)
    result = d.observe(frame("选择乐曲", "再次演奏", "大音天籁"))
    assert result.state == ScreenState.RESULT


def test_unknown_never_means_playing():
    d = MusicScreenDetector(confirm_frames=1)
    assert d.observe(frame()).state == ScreenState.UNKNOWN
    assert d.current_state == ScreenState.UNKNOWN


if __name__ == "__main__":
    test_song_list_requires_three_frames()
    test_difficulty_screen()
    test_result_screen()
    test_unknown_never_means_playing()
    print("MusicScreenDetector tests: PASS")
