"""Host-side smoke test for the album automation engine (needs no Android/Root).

Covers the acceptance criteria in《音游专辑自动脚本需求规格》:
1. 启动时未识别到“千音雅集”会停止。
2. 能按配置区分 legend_only 与 all_difficulties。
3. all_difficulties 按 传说>大师>困难>普通 补齐，且不会提前切下一首。
4. 结算未到 100.0% 会无限“再次演奏”并重新打歌。
5. 每次点击下一首前都确认已出现“千音雅集”（未出现属于等待，不发邮件）。
6. 12 首处理完成后停止脚本。
7. 非预期界面会发送邮件提醒。
8. 两个固定坐标均可由用户自定义。
"""
import time

from app.src.main.python.python.album_bot import AlbumBot
from app.src.main.python.python.frame import Frame

SCREEN_W, SCREEN_H = 1280, 720


def item(text, x, y, w=140, h=30):
    return {"text": text, "left": x, "top": y, "right": x + w, "bottom": y + h}


def center(x, y, w=140, h=30):
    return (x + w / 2, y + h / 2)


CATALOG = [item("千音雅集", 200, 40), item("前往演奏", 520, 620)]
CATALOG_CENTER = center(520, 620)
GO_RETURN = (200, 600)          # coord_difficulty_done_return
GO_NEXT = (1000, 600)           # coord_next_song

LABELS = {"普通": (400, 160), "困难": (400, 300), "大师": (400, 440), "传说": (400, 580)}
LABEL_CENTERS = {name: center(*pos) for name, pos in LABELS.items()}
START_BTN_CENTER = center(560, 660)
RETRY_BTN_CENTER = center(360, 600)
CHOOSE_BTN_CENTER = center(760, 600)


def difficulty(done):
    screens = [item(name, x, y) for name, (x, y) in LABELS.items()]
    for name in done:
        screens.append(item("大音天籁", 700, LABELS[name][1]))
    screens.append(item("开始演奏", 560, 660))
    return screens


def settlement(rate):
    return [item("演奏完成率", 400, 120), item(rate, 640, 120),
            item("再次演奏", 360, 600), item("选择曲目", 760, 600)]


PLAY_SCREEN = [item("节奏进行中", 600, 300)]
ERROR_SCREEN = [item("网络异常", 520, 300), item("重试", 520, 400)]
LOADING_SCREEN = [item("加载中", 500, 300)]

BASE_CONFIG = {"completion_mode": "legend_only", "on_exception": "stop",
               "next_x": GO_NEXT[0], "next_y": GO_NEXT[1],
               "return_x": GO_RETURN[0], "return_y": GO_RETURN[1]}


class FakeHost:
    def __init__(self, **config):
        self.config = config
        self.screen = []
        self.watch = None
        self.taps = []
        self.emails = []
        self.logs = []
        self.watcher_running = False

    # ---- AlbumBot host API ----
    def getAlbumConfig(self):
        return dict(self.config)

    def capture(self):
        return {"width": SCREEN_W, "height": SCREEN_H,
                "texts": [dict(t) for t in self.screen]}

    def tap(self, x, y):
        self.taps.append((x, y))

    def log(self, message):
        self.logs.append(str(message))

    def sendEmailAlert(self, subject, body):
        self.emails.append((subject, body))

    def startOcrWatcher(self, interval_ms):
        self.watcher_running = True

    def stopOcrWatcher(self):
        self.watcher_running = False

    def getOcrWatchFrame(self):
        if self.watch is None:
            return None
        return {"width": SCREEN_W, "height": SCREEN_H,
                "texts": [dict(t) for t in self.watch],
                "updatedAtMs": int(time.time() * 1000)}

    # ---- MusicBot (black box) host API ----
    def getMusicCoordinateConfig(self):
        return [778, 1100, 1440, 1780, 2100, 2440, 1210, 230, -1]

    def initializeMultiTouch(self, logical_width, logical_height):
        assert (logical_width, logical_height) == (1440, 3200)
        return "fake-type-b-device"

    def captureBlueValues(self, xs, y):
        return {"blue": [255] * 6}

    def updateTouches(self, states, xs, ys):
        return 0

    def releaseAllTouches(self):
        pass


def test_1_startup_stops_without_marker():
    host = FakeHost(**BASE_CONFIG)
    host.screen = LOADING_SCREEN
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    assert bot.running is False and bot.state == "启动失败", bot.state
    assert host.taps == [] and host.emails == []
    print("PASS 1: 启动未识别“千音雅集”直接停止")


def test_2_legend_only_skip_and_custom_coords():
    host = FakeHost(**BASE_CONFIG)
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    assert bot.phase == "CATALOG"
    bot.step()                                   # 点击“前往演奏”
    assert host.taps == [CATALOG_CENTER], host.taps
    assert bot.phase == "DIFFICULTY"
    host.screen = difficulty(["传说"])            # 传说已“大音天籁”
    bot.step()                                   # 点击 coord_difficulty_done_return
    assert host.taps[-1] == GO_RETURN, host.taps
    assert bot.phase == "RETURN_NEXT"
    host.screen = list(CATALOG)
    bot.step()                                   # 确认“千音雅集”后点击 coord_next_song
    assert host.taps[-1] == GO_NEXT, host.taps
    assert bot.song_index == 2 and bot.phase == "CATALOG"
    print("PASS 2: legend_only 跳过已完成曲目，两个固定坐标均为配置值")


def test_3_legend_play_retry_until_100():
    host = FakeHost(**BASE_CONFIG)
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    bot.step()                                   # 前往演奏
    host.screen = difficulty(["普通"])            # 传说未完成
    bot.step()                                   # 选传说 + 开始演奏 + 启动打歌模块
    assert bot.phase == "PLAYING" and bot.current_difficulty == "传说"
    assert host.taps[-2] == LABEL_CENTERS["传说"], host.taps
    assert host.taps[-1] == START_BTN_CENTER, host.taps
    assert host.watcher_running and bot.music.running

    host.watch = list(PLAY_SCREEN)               # 打歌中
    bot.step()
    assert bot.phase == "PLAYING" and host.taps[-1] == START_BTN_CENTER

    time.sleep(0.3)                              # 让监视线程检查间隔到期
    host.watch = settlement("98.5%")             # 未到 100.0%
    host.screen = settlement("98.5%")
    bot.step()                                   # 识别结算页 → 停止打歌模块
    assert bot.phase == "SETTLE" and host.watcher_running is False
    bot.step()                                   # 点击“再次演奏”→ 重新打歌（不选曲不选难度）
    assert host.taps[-1] == RETRY_BTN_CENTER, host.taps
    assert bot.retry_count == 1 and bot.phase == "PLAYING"
    assert bot.music.running and host.watcher_running

    time.sleep(0.3)
    host.watch = settlement("100.0%")
    host.screen = settlement("100.0%")
    bot.step()
    assert bot.phase == "SETTLE"
    bot.step()                                   # 点击“选择曲目”→ 准备切下一首
    assert host.taps[-1] == CHOOSE_BTN_CENTER, host.taps
    assert bot.phase == "RETURN_NEXT"
    host.screen = list(CATALOG)
    bot.step()
    assert host.taps[-1] == GO_NEXT and bot.song_index == 2
    print("PASS 3: 结算 <100.0% 无限“再次演奏”，100.0% 后“选择曲目”切下一首")


def test_4_all_difficulties_priority_order():
    host = FakeHost(completion_mode="all_difficulties", on_exception="stop",
                    next_x=GO_NEXT[0], next_y=GO_NEXT[1],
                    return_x=GO_RETURN[0], return_y=GO_RETURN[1])
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    picked = []
    done = ["普通"]
    for expected in ("传说", "大师", "困难"):
        bot.step()                               # 目录点击“前往演奏”
        assert bot.phase == "DIFFICULTY"
        host.screen = difficulty(done)
        bot.step()                               # 选难度 + 开始演奏
        assert bot.phase == "PLAYING" and bot.current_difficulty == expected
        picked.append(expected)
        assert host.taps[-2] == LABEL_CENTERS[expected], host.taps
        host.watch = settlement("100.0%")        # 直接 100.0% 结算
        host.screen = settlement("100.0%")
        time.sleep(0.3)
        bot.step()                               # → SETTLE
        bot.step()                               # “选择曲目”→ 回目录继续补难度
        assert bot.phase == "CATALOG"
        done.append(expected)
        host.screen = list(CATALOG)              # 目录页出现，可再次“前往演奏”
    # 四个难度全部“大音天籁”→ 点击返回坐标，之后才切下一首
    bot.step()
    assert bot.phase == "DIFFICULTY"
    host.screen = difficulty(done)
    bot.step()
    assert host.taps[-1] == GO_RETURN and bot.phase == "RETURN_NEXT"
    host.screen = list(CATALOG)
    bot.step()
    assert host.taps[-1] == GO_NEXT and bot.song_index == 2
    assert picked == ["传说", "大师", "困难"], picked
    assert host.taps.count(GO_NEXT) == 1, host.taps
    print("PASS 4: all_difficulties 按 传说>大师>困难>普通 补齐，未提前切下一首")


def test_5_next_song_requires_catalog_marker():
    host = FakeHost(**BASE_CONFIG)
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    bot.step()
    host.screen = difficulty(["传说"])
    bot.step()                                   # → RETURN_NEXT
    taps_before = list(host.taps)
    host.screen = LOADING_SCREEN                 # 未识别“千音雅集”
    bot.step()
    assert host.taps == taps_before, host.taps   # 不点击下一首
    assert bot.phase == "RETURN_NEXT" and host.emails == []   # 也不发邮件
    host.screen = list(CATALOG)
    bot.step()
    assert host.taps[-1] == GO_NEXT
    print("PASS 5: 切下一首前确认“千音雅集”；未识别到属于等待，不发邮件")


def test_6_twelve_songs_then_stop():
    host = FakeHost(**BASE_CONFIG)
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    for _ in range(12):
        bot.step()                               # 前往演奏
        host.screen = difficulty(["传说"])
        bot.step()                               # 传说完成 → 返回目录
        host.screen = list(CATALOG)
        bot.step()                               # 切下一首
    assert bot.running is False and bot.phase == "DONE", bot.phase
    assert host.taps.count(GO_NEXT) == 12
    print("PASS 6: 12 首处理完成后停止脚本")


def test_7_unexpected_screen_sends_email():
    host = FakeHost(**BASE_CONFIG)
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    host.screen = list(ERROR_SCREEN)             # 网络异常弹窗
    bot.step()
    assert len(host.emails) == 1, host.emails
    assert "网络异常" in host.emails[0][1]
    assert bot.running is False and bot.state == "异常停止"

    host = FakeHost(on_exception="continue", **{k: v for k, v in BASE_CONFIG.items()
                                                if k != "on_exception"})
    host.screen = list(CATALOG)
    bot = AlbumBot(host)
    bot.start()
    bot.step()
    host.screen = list(ERROR_SCREEN)
    bot.step()
    assert len(host.emails) == 1 and bot.running is True
    assert host.taps == []
    host.screen = list(CATALOG)                  # 画面恢复后继续
    bot.step()
    assert host.taps == [CATALOG_CENTER]
    print("PASS 7: 非预期界面发送邮件提醒（stop / continue 两种动作）")


def test_8_missing_coord_config_fails_fast():
    host = FakeHost(completion_mode="legend_only")
    try:
        AlbumBot(host).start()
    except ValueError:
        print("PASS 8: 固定坐标未配置时启动即报错（坐标可由用户自定义）")
        return
    raise AssertionError("expected ValueError for missing fixed coordinates")


def test_rate_ocr_normalization():
    frame = Frame.from_host({"width": SCREEN_W, "height": SCREEN_H,
                             "texts": [item("演奏完成率", 400, 120), item("l00.0%", 640, 120)]})
    assert AlbumBot._parse_completion_rate(frame) == 100.0
    frame = Frame.from_host({"width": SCREEN_W, "height": SCREEN_H,
                             "texts": [item("演奏完成率 98.5％", 400, 120)]})
    assert AlbumBot._parse_completion_rate(frame) == 98.5
    print("PASS 9: 完成率解析容忍 OCR 误识别（l/0、全角％）")


if __name__ == "__main__":
    test_1_startup_stops_without_marker()
    test_2_legend_only_skip_and_custom_coords()
    test_3_legend_play_retry_until_100()
    test_4_all_difficulties_priority_order()
    test_5_next_song_requires_catalog_marker()
    test_6_twelve_songs_then_stop()
    test_7_unexpected_screen_sends_email()
    test_8_missing_coord_config_fails_fast()
    test_rate_ocr_normalization()
    print("Album engine smoke test passed")
