# Verification Base64 Decode Fix6

## 基础版本
- Fix6 以 Fix4 为唯一基础版本制作；Fix5 仅用于分析 Base64 解码实现和已知回归问题。
- 保留 Fix4 的项目文件、目录结构、游戏挂机逻辑、六轨道音乐逻辑及验证状态机。

## 修改内容
- 在 Python 层增加 `url_prefix` 查询参数解析及 Base64 / Base64URL 解码，自动补齐 padding，并验证 UTF-8 与 HTTP(S) URL。
- 新增可选的解码结果保存调用，目标文件为 `/storage/emulated/0/RedFingerGameBot/verification_decoded.txt`。
- 解码或解码结果保存失败时，仅记录错误，不中断原始 URI 的保存、复制和物理返回键处理。
- 原始 `mqqapi://` URI 仍保存到 `verification_urls.txt`，并仍复制原始 URI，而非解码后的 URL。
- 在 `RootHost.java` 中新增 `saveVerificationDecoded()`，修正 Java 正则表达式转义，并通过项目现有 `shellQuote()` 安全构造追加写入命令。
- 日志不输出完整解码 URL；解码 URL 仅本地追加保存。

## 修改文件
1. `app/src/main/python/python/bot.py`
   - 新增 Base64 与 URL 解析导入。
   - 新增 `_decode_mqqapi_url_prefix()`。
   - 将可选解码保存与原始 URI 保存、剪贴板复制、返回键处理隔离。
2. `app/src/main/java/com/redfinger/gamebot/RootHost.java`
   - 新增 `saveVerificationDecoded(String, String)`。
3. `VERIFICATION_BASE64_DECODE_FIX6_CHANGELOG.md`
   - 新增本版本变更记录。

## 验证
- Python `py_compile`：通过。
- Base64 测试：给定示例 URL 解码成功；标准 Base64（含原始 `+`、URL 编码 `+`）、Base64URL（含 `-` / `_`）及缺失 padding 均通过。
- 错误输入测试：缺失参数、空参数、非法 Base64、非 UTF-8、非 HTTP(S) 均安全返回空字符串。
- 流程隔离测试：模拟解码结果保存抛出异常，以及解码失败；两种情况下原始 URI 保存后仍继续复制原始 URI并调用物理返回键。
- Java 正则表达式：使用 Java 21 对照 `RootHost.java` 中的两个正则表达式进行独立编译和运行测试，通过。
- ZIP 完整性：打包后执行 CRC / 解压检查，并核对 Fix4 原始条目均保留。
- Android Gradle 编译及真实设备运行：未完成；当前环境未配置 Android SDK，且项目未附带 Gradle Wrapper，需在 Android Studio / 目标设备上验证。

## 安全
- 不自动打开解码 URL，不向第三方上传，不自动提交或绕过身份验证。
- 解码 URL 可能含验证令牌，请妥善保管本地 `verification_decoded.txt`。
