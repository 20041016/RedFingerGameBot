# 专辑设置移入悬浮窗（Album Settings → Overlay）CHANGELOG

## 变更内容
1. 专辑自动脚本的配置从独立设置页移入悬浮窗：
   - `BotService.showCoordinateWindow()` 按模式分发，专辑模式打开新的 `showAlbumCoordinateWindow()` 子窗口
     （与游戏挂机坐标窗口相同的卡片样式、拖动、屏内定位与滚动布局）。
   - 自定义坐标改用悬浮窗中已有的“记录 X/Y”点选录入实现（`beginPairCoordinateCapture`，Root 触摸采集 +
     横屏 1280 × 720 换算），不再手动填写数字：
     - 切换下一首歌曲（coord_next_song_x/y）
     - 难度全部完成后返回目录（coord_difficulty_done_return_x/y）
   - 新增“完成难度选择”芯片按钮：仅传说难度（legend_only）/ 四个难度全部完成（all_difficulties），
     选中项高亮，随“保存参数”持久化。
2. 删除 `AlbumSettingsActivity` 及其在 `MainActivity`、`AndroidManifest.xml` 中的注册；
   主界面卡片文案改为“启动前请在悬浮窗中配置完成难度与坐标”。
3. 通用化原游戏坐标窗口辅助方法（供游戏/专辑两个窗口共用）：
   `addGameCoordinatePairRow` → `addCoordinatePairRow`，
   `formatGameCoordinatePair` → `formatCoordinatePair`，
   `beginGameCoordinateCapture` → `beginPairCoordinateCapture`，
   `refreshGameCoordinateValues` → `refreshCoordinatePairValues`（含专辑坐标对）。

## 兼容性
- 偏好存储仍为 `album_automation`（键名不变：completion_mode、coord_*），`RootHost.getAlbumConfig()` 与
  `python.album_bot.AlbumBot` 无需改动。
- 记录坐标前需先停止脚本（沿用现有防误采保护）。

## 验证限制
未提供 Android SDK/Gradle，未能编译 APK；已做括号/结构静态检查与引用一致性检查，需实机验证点选换算与窗口交互。
