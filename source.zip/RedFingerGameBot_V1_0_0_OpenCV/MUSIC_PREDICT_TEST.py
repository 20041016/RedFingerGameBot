"""Offline real-time simulation of the predictive rhythm timing (no Android needed).

Simulates 60 FPS frames, a 8 ms capture age, 30 ms touch latency, a constant note speed,
notes hidden behind the floating controller (lanes 0/1, y 700-1000) and one hold note.
Reports how far each press lands from the note's true arrival, predictive vs legacy.
"""
import sys, time, statistics
sys.path.insert(0, "app/src/main/python")
from python.music_bot import MusicBot

XS = [778, 1100, 1440, 1780, 2100, 2440]
JUDGE = 1210
SPEED = 1.40            # px per ms (hidden from the bot)
AGE = 8.0               # ms between the screen showing a state and the bot receiving the frame
TOUCH_LAT = 30.0        # ms from updateTouches() to the game seeing the touch
RADIUS = 60             # note body radius that covers the judge pixel
FRAME = 1000.0 / 60


def now():
    return time.perf_counter() * 1000.0


class FakeHost:
    def __init__(self, t0, arrivals, hold):
        self.t0 = t0
        self.arrivals = arrivals            # [(lane, t_arrival_ms_relative)]
        self.hold = hold                    # (lane, start, end) relative
        self.events = []                    # (game_time_rel, lane, pressed)
        self.state = [0] * 6
        self.tick = 0

    def getMusicCoordinateConfig(self): return [*XS, JUDGE, 230, -1]
    def initializeMultiTouch(self, w, h): return "fake"
    def releaseAllTouches(self): pass
    def log(self, m): pass

    def _frame(self, with_notes):
        self.tick += 1
        target = self.t0 + self.tick * FRAME
        while now() < target:
            time.sleep(0.0005)
        t = (now() - AGE) - self.t0                      # state shown in this frame
        notes, blue = [], [255] * 6
        for lane, arr in self.arrivals:
            y = JUDGE - SPEED * (arr - t)
            if 217 <= y <= 1270:
                hidden = lane in (0, 1) and 700 <= y <= 1000
                if not hidden:
                    notes += [lane, int(y), 60]
            if abs(y - JUDGE) <= RADIUS and y <= JUDGE + RADIUS:
                blue[lane] = 90
        lane, s, e = self.hold
        if s - 20 <= t <= e:
            blue[lane] = 80
        res = {"blue": blue, "captureMs": 11, "decodeMs": 2}
        if with_notes:
            res["notes"] = notes
        return res

    def captureNotes(self, *a): return self._frame(True)
    def captureBlueValues(self, *a): return self._frame(False)

    def updateTouches(self, states, xs, ys):
        game_t = now() + TOUCH_LAT - self.t0
        for lane in range(6):
            if bool(states[lane]) != bool(self.state[lane]):
                self.events.append((game_t, lane, bool(states[lane])))
        self.state = list(states)
        return 1


LAST = {}


def host_events_of(bot):
    return LAST['host'].events


def run(predict):
    t0 = now() + 50
    arrivals = [(3, 700), (4, 700), (0, 1100), (1, 1400), (5, 1700), (2, 2300), (3, 2700), (0, 3000), (1, 3300), (4, 3600)]
    hold = (2, 2300, 2700)
    host = FakeHost(t0, arrivals, hold)
    bot = MusicBot(host)
    LAST['host'] = host
    bot.PREDICT_ENABLED = predict
    bot.PRESS_LEAD_MS = TOUCH_LAT     # what a tuned user converges to (frame age is handled separately)
    bot.start()
    while now() - t0 < 4300:
        bot.step()
    bot.stop()
    errs, holds = [], {}
    for lane, arr in arrivals:
        if (lane, arr) == (3, 2700):      # note directly after a hold on another lane: still normal
            pass
        cand = [t for t, l, p in host.events if l == lane and p and abs(t - arr) < 250]
        if cand:
            errs.append(min(cand, key=lambda t: abs(t - arr)) - arr)
        else:
            errs.append(None)
    rel = [(round(t), l, "↓" if p else "↑") for t, l, p in host.events]
    return errs, rel, bot


for predict in (False, True):
    errs, rel, bot = run(predict)
    got = [e for e in errs if e is not None]
    print("predictive" if predict else "legacy    ", "errors(ms):", [None if e is None else round(e) for e in errs])
    if got:
        print("    mean %+.1f  max|err| %.1f  missed %d" % (statistics.mean(got), max(abs(e) for e in got), errs.count(None)))
    if predict:
        print("    speed estimate %.3f px/ms (true %.2f), predicted=%d reactive=%d" % (bot.speed, SPEED, bot.predicted_presses, bot.reactive_presses))
        h = [(round(t), "down" if p else "up") for t, l, p in host_events_of(bot) if l == 2]
        print("    hold lane 2 (note arrives 2300, hold ends 2700):", h)
