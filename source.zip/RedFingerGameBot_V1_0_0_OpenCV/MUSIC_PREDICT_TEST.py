"""Offline real-time simulation of the rhythm timing (no Android needed).

60 FPS frames, constant note speed, capture age with +-3 ms jitter, 30 ms touch latency,
notes hidden behind the floating controller (lanes 0/1), random arrival phase vs. the frame clock.
Compares the old reactive trigger with predictive mode (offset 0 = parity with the old timing,
offset +8 = 8 ms earlier) by the press error vs. the true arrival.
"""
import random, statistics, sys, time
sys.path.insert(0, "app/src/main/python")
from python.music_bot import MusicBot

XS = [778, 1100, 1440, 1780, 2100, 2440]
JUDGE, SPEED, AGE, TOUCH_LAT, RADIUS = 1210, 1.40, 8.0, 30.0, 60
FRAME = 1000.0 / 60


def now():
    return time.perf_counter() * 1000.0


class FakeHost:
    def __init__(self, t0, arrivals, rnd):
        self.t0, self.arrivals, self.rnd = t0, arrivals, rnd
        self.events, self.state, self.tick = [], [0] * 6, 0

    def getMusicCoordinateConfig(self): return [*XS, JUDGE, 230, -1]
    def initializeMultiTouch(self, w, h): return "fake"
    def releaseAllTouches(self): pass
    def log(self, m): pass

    def _frame(self, with_notes):
        self.tick += 1
        target = self.t0 + self.tick * FRAME
        while now() < target:
            time.sleep(0.0005)
        t = (now() - (AGE + self.rnd.uniform(-3, 3))) - self.t0
        notes, blue = [], [255] * 6
        for lane, arr in self.arrivals:
            y = JUDGE - SPEED * (arr - t)
            if 217 <= y <= 1270 and not (lane in (0, 1) and 700 <= y <= 1000):
                notes += [lane, int(y), 60]
            if abs(y - JUDGE) <= RADIUS and y <= JUDGE + RADIUS:
                blue[lane] = 90
        res = {"blue": blue, "captureMs": 11, "decodeMs": 2}
        if with_notes:
            res["notes"] = notes
        return res

    def captureNotes(self, *a): return self._frame(True)
    def captureBlueValues(self, *a): return self._frame(False)

    def updateTouches(self, states, xs, ys):
        game_t = now() + TOUCH_LAT - self.t0
        for lane in range(6):
            if bool(states[lane]) != bool(self.state[lane]):
                self.events.append((game_t, lane, bool(states[lane])))
        self.state = list(states)
        return 1


def run(predict, offset, seed=7, notes=30):
    rnd = random.Random(seed)
    t0 = now() + 50
    arrivals, t = [], 900.0
    for i in range(notes):
        t += 260 + rnd.uniform(0, 140)
        arrivals.append((rnd.randrange(6), t))
    host = FakeHost(t0, arrivals, rnd)
    bot = MusicBot(host)
    bot.PREDICT_ENABLED = predict
    bot.PRESS_OFFSET_MS = offset
    bot.start()
    while now() - t0 < arrivals[-1][1] + 300:
        bot.step()
    bot.stop()
    errs = []
    for idx, (lane, arr) in enumerate(arrivals):
        c = [tt for tt, l, p in host.events if l == lane and p and abs(tt - arr) < 200]
        errs.append((idx, min(c, key=lambda tt: abs(tt - arr)) - arr) if c else (idx, None))
    return errs, bot


def summary(name, errs, skip):
    got = [e for i, e in errs if e is not None and i >= skip]
    miss = sum(1 for i, e in errs if e is None and i >= skip)
    print("%-26s mean %+5.1f  std %4.1f  max|err| %5.1f  missed %d" % (
        name, statistics.mean(got), statistics.pstdev(got), max(abs(e) for e in got), miss))


SKIP = 10    # predictive mode needs a few notes to measure speed and contact radius
legacy, _ = run(False, 0)
summary("legacy (old trigger)", legacy, SKIP)
p0, bot = run(True, 0)
summary("predictive, offset 0", p0, SKIP)
print("    speed %.3f px/ms (true %.2f), contact radius %.0f px (true %d), predicted=%d reactive=%d, jitter %.1f ms" % (
    bot.speed, SPEED, bot.radius_px or 0, RADIUS, bot.predicted_presses, bot.reactive_presses, bot.jitter_ms))
p8, _ = run(True, 8)
summary("predictive, offset +8", p8, SKIP)
