# Rhythm mode: predictive timing (v2, self-calibrating)

- Java `captureNotes()` returns the six judge-line blue values plus every note centre found in each lane strip
  (pale-yellow centre: R 238-255, G 226-255, B 120-185; checked on two real screenshots: all notes found, no false hits).
- `MusicBot` tracks notes per lane, estimates the fall speed (long-baseline samples, median) and each note's arrival
  time (median over its last 8 sightings, so single-frame jitter averages out). Hidden notes are extrapolated.
- **Timing baseline = the old trigger.** The bot measures when the judge pixel changes shortly before arrival (the
  old trigger moment) and reproduces that average timing. The first ~10 notes use the old logic while it measures
  speed and contact radius (diagnostics line shows "校准中").
- **提前量 ms** (floating settings window, rhythm mode, applied within ~0.5 s): relative to the old timing.
  0 = same average timing as before; + earlier; - later. Hits late -> raise; early -> lower (5-10 per step).
- 预判模式 off = exactly the old behaviour. 最短按住 = minimum press length of a tap.
- Diagnostics: `基准提前Nms` (measured old trigger lead), `抖动±x` (arrival-estimate noise, ms), `预N补M`
  (predicted presses / presses made by the old colour trigger as a fallback).
- Hold-note releases are still reactive (judge pixel clears).

Simulation (`MUSIC_PREDICT_TEST.py`: 60 FPS, +-3 ms capture-age jitter, occlusion): old trigger mean +3.5 / std 5.7 ms,
predictive offset 0 mean +1.6 / std 0.9 ms; offset +8 shifts it by ~8 ms. Not run on a device.
