# Rhythm mode: predictive timing

- Java `captureNotes()` returns the usual six judge-line blue values plus every note centre found in each
  lane strip (pale-yellow centre: R 238-255, G 226-255, B 120-185 — checked on two real screenshots: all notes
  found, no false hits on backgrounds, effects or text).
- `MusicBot` tracks notes per lane, estimates the fall speed (median of frame-to-frame samples) and presses at
  `arrival - PRESS_LEAD_MS`. Notes hidden behind the floating controller keep being extrapolated.
- Falls back to the original blue<220 trigger when a note was not detected, and keeps holds pressed with it.
- Releases are still reactive (judge pixel clears), so hold-note releases are as late as before.

## Tuning (music floating settings window)
- Open the floating settings (target/settings icon) and edit `PRESS_LEAD_MS` in milliseconds.
- Hits late -> raise the value by ~10; early -> lower it. Negative values are fine.
- Save persists the value; if music mode is running, the new value is applied live.
- Diagnostics on the controller: `预判 速度x.xxpx/ms 预N 补M` (N = predicted presses, M = fallback presses).
  `预判校准中` means speed is still being measured (first notes use the old trigger).
- `PREDICT_ENABLED = False` restores the original behaviour exactly.
- FPS below ~60 on the diagnostics line means frames queue up and add latency regardless of this change.

Not run on a device. `MUSIC_PREDICT_TEST.py` simulates 60 FPS, constant speed, occlusion and a hold note.
