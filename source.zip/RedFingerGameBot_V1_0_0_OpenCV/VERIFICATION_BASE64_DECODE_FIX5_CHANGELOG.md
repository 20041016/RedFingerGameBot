# Verification Base64 Decode Fix5

- Captured `mqqapi://` URL is still saved unchanged to `verification_urls.txt` and copied to clipboard.
- Reads the `url_prefix` query parameter, URL-decodes it, then decodes standard Base64/Base64URL (including missing padding).
- Saves the decoded HTTP(S) target and its source mqqapi URL to `verification_decoded.txt`.
- Invalid, absent, non-UTF-8, or non-HTTP(S) values are not decoded; the original URL remains saved.
- Does not send email or change game/music bot operation.
- The decoded URL may contain verification tokens. Keep the output file private and do not share it publicly.
