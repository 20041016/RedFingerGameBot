# RedFinger GameBot V1.0.0 — MediaProjection + OpenCV 音游版

本源码包基于 V1.0.0 双功能项目，保留游戏挂机入口与六轨音游辅助。此版本按用户授权改用 Android 系统屏幕采集权限，Root 仍负责触摸注入。

## 音游架构
- **屏幕采集：** 启动音游时请求 Android 系统屏幕录制确认；服务使用 MediaProjection + VirtualDisplay + ImageReader 连续取帧，不逐帧启动截图命令，不写 PNG 临时文件。
- **图像处理：** Java OpenCV 4.10.0 原生库；复用 RGBA 缓冲区和 Mat，只采样六条轨道的原有像素位置。
- **触摸注入：** Java `RootTouchController`，Root `sendevent` Type-B 多点触控，按下/释放批量写入。
- **音符逻辑：** 保留原 `MusicBot` 六轨状态机。

## 保持的原始参数
- 检测 X：`778, 1100, 1440, 1780, 2100, 2440`
- 检测 Y：`1210`
- 蓝色通道判定：`blue < 220`
- 触摸逻辑坐标 X：`230`
- 触摸逻辑坐标 Y：各轨道检测 X
- 触点 ID：`0..5`
- 逻辑屏幕：`1440 × 3200`

本版本没有改变检测坐标、触摸坐标或阈值。

## 权限与运行方式
- 音游启动时会弹出 Android 系统的屏幕录制/投射确认窗口；这是 MediaProjection 必需的用户授权。
- 每次重新启动音游都需要重新确认一次；停止后请回到应用主页再次启动，不要使用悬浮窗按钮直接重启旧会话。
- 不增加 Accessibility Service 或无障碍权限。
- Root 继续用于 `sendevent` Type-B 多点触控；屏幕画面由 MediaProjection 提供。
- 启动音游前应用会切换到横屏，以保持原有六轨横屏坐标映射。

## 构建要求
- Android Studio / Gradle
- 项目现有 Android Gradle Plugin 8.13.2、Chaquopy 17.2.0
- Gradle 需能访问 Google Maven 与 Maven Central，以下载 `org.opencv:opencv:4.10.0` AAR
- 当前项目 `minSdk 24`，ABI 保留 `arm64-v8a` 和 `armeabi-v7a`

在 Android Studio 中打开项目根目录，执行 Sync，再构建 APK。

## 首次运行验证
1. 安装并授予原有 Root 与悬浮窗权限。
2. 从应用主页点击“启动音游辅助”。
3. 在 Android 系统弹窗中选择“立即开始/允许”屏幕录制。
4. 切回音游画面，观察悬浮窗诊断：帧数、FPS、帧获取耗时、OpenCV 处理耗时、输入批次耗时和六个蓝色采样值。
5. 若仍有漏按，请把悬浮窗诊断完整文字和对应游戏画面发回。

## 验证边界
Python 引擎烟雾测试通过，ZIP 完整性检查通过。当前构建环境没有 Android SDK/Gradle，**未能在此处完成 Android APK 编译，也未在目标手机上实测 MediaProjection 兼容性或实际 FPS**。性能必须以手机实测为准。
