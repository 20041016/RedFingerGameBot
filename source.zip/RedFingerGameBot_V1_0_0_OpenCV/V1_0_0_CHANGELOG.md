# RedFinger GameBot V1.0.0 — 双功能开发版

## 主页
- 改为简洁现代风格。
- 增加游戏挂机、音游辅助两个独立功能入口。
- 展示悬浮窗权限状态和 Root 授权提示。

## 新增音游辅助
- 新增六轨蓝色通道采样引擎。
- 新增 Root Type-B 多点触控控制器，按触摸驱动 ABS 范围缩放坐标。
- 按下/抬起状态独立管理，停止或异常时释放全部触点。
- 不申请无障碍服务权限。

## 运行管理
- 两个引擎独立选择，切换时先停止旧引擎。
- 音游状态通知限频，避免 5ms 循环频繁刷新通知。

## 注意
- 当前多点触控仅支持可识别的 Type-B `/dev/input/event*` 设备，且至少 6 个 slot。
- 触摸坐标按原脚本竖屏 1440x3200 逻辑坐标映射；需要真机校准。
- 未进行 Android APK 构建和真实设备测试。


## Root Type-B 多点触控整合修订
- 将实测通过的首指/末指全局触摸状态管理并入 `RootTouchController`。
- 首个活动 Slot 按下时发送 `BTN_TOUCH` 与 `BTN_TOOL_FINGER` DOWN。
- 仅在最后一个活动 Slot 释放时发送对应 UP；释放单指不会清除其他活动触点。
- `releaseAll()` 统一释放活动 Slot 并清理全局触摸状态。
- 目标设备实测参数：Goodix event7、10 slots、1440×3200、X 0–143999、Y 0–319999。

## OpenCV 音游性能更新
- 新增官方 OpenCV Android AAR（4.10.0），使用 Java 原生库解码 Root 截图 PNG。
- 音游截图改为持久 Root shell 的 `screencap -p` 标准输出，不再每帧创建 PNG 文件、写盘并通过 BitmapFactory 解码。
- OpenCV 仅采样原有六个像素点的 BGR 蓝色通道，保持原六轨坐标、阈值 220 和按键逻辑不变。
- 音游循环不再额外固定 sleep 5ms，循环由截图帧流自然节流。
- Root sendevent 按下/释放事件合并成单次 shell 写入并 flush，减少逐事件刷新开销。
- 悬浮窗诊断增加平均 FPS、截图耗时、OpenCV 解码耗时和单轮耗时。
- 不使用 MediaProjection，不申请屏幕录制授权，不添加 Accessibility Service。
