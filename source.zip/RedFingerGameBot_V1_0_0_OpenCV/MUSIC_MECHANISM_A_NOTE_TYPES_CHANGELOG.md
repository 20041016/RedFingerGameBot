# Mechanism A note-type tracking update

- OpenCV now returns per-note records: lane, head Y, tail Y, and type (tap/hold).
- Yellow flower notes are treated as taps.
- Hold notes require a saturated red-orange vertical body and a matching flower-head colour/shape check, reducing false positives from the warm background and red overlay controls.
- Hold press time is predicted from the flower/head position; release time is predicted from the bar tail.
- A tail edge must move consistently with the head before it is trusted. This prevents a stationary occlusion boundary (for example, a floating overlay covering the top of a hold bar) from causing early release.
- Speed is still shared across all six lanes, while note tracking and touch state remain lane-independent.
- Mechanism B remains disabled. The floating `PRESS_LEAD_MS` setting is preserved.

## Validation

- Python syntax compilation passed.
- Predictive engine smoke test passed, including tap/hold tuple parsing and clipped-tail validation.
- The supplied screenshot was used for offline colour-mask sanity checks. This is not a substitute for live-game testing or a calibrated full-screen capture.
- Android Gradle build and device/gameplay tests were not run in this environment.
