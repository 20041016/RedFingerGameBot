package com.redfinger.gamebot;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.util.Log;
import java.util.Locale;

/** Reads visible UI labels only. It never performs identity verification or extracts session data. */
public class VerificationAccessibilityService extends AccessibilityService {
    private static final String TAG = "RFG-VerifyA11y";
    private long lastSignalMs;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        StringBuilder visible = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence item : event.getText()) if (item != null) visible.append(item).append(' ');
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            collectVisibleText(root, visible, 0);
            root.recycle();
        }
        String text = visible.toString().toLowerCase(Locale.ROOT);
        boolean verification = text.contains("人脸识别验证") || text.contains("人脸识别")
                || text.contains("身份验证") || text.contains("开始验证")
                || text.contains("前往验证");
        if (verification) {
            long now = System.currentTimeMillis();
            if (now - lastSignalMs > 2500) {
                lastSignalMs = now;
                Log.w(TAG, "检测到可见的账号验证页面，暂停游戏挂机");
                BotService.onVerificationPromptDetected();
            }
        }
    }

    private void collectVisibleText(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || depth > 18 || out.length() > 12000) return;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        if (text != null) out.append(text).append(' ');
        if (desc != null) out.append(desc).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectVisibleText(child, out, depth + 1);
                child.recycle();
            }
        }
    }

    @Override public void onInterrupt() { }
}
