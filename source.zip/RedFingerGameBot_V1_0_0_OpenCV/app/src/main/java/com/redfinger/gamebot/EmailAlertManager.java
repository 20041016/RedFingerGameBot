package com.redfinger.gamebot;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/** SMTP alert delivery and persistent alert-state tracking. */
public final class EmailAlertManager {
    private static final String PREF = "email_alerts";
    private static final String KEY_ALIAS = "rfgb_email_secret_v1";
    private static final long INTERVAL = 30L * 60L * 1000L;
    private final Context context;
    private final SharedPreferences prefs;

    public EmailAlertManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static void saveConfig(Context c, String host, String port, String from,
                                  String password, String to) throws Exception {
        int p = Integer.parseInt(port.trim());
        if (host.trim().isEmpty() || from.trim().isEmpty() || to.trim().isEmpty()
                || password.isEmpty() || p < 1 || p > 65535) {
            throw new IllegalArgumentException("请完整填写 SMTP 服务器、端口、发件邮箱、授权码和收件邮箱");
        }
        String encrypted = encrypt(c, password);
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("host", host.trim()).putInt("port", p)
                .putString("from", from.trim()).putString("to", to.trim())
                .putString("password", encrypted).apply();
    }

    public static String[] loadConfig(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String secret = p.getString("password", "");
        String password = "";
        try { if (!secret.isEmpty()) password = decrypt(c, secret); } catch (Exception ignored) {}
        return new String[]{p.getString("host", "smtp.gmail.com"),
                String.valueOf(p.getInt("port", 587)), p.getString("from", ""),
                password, p.getString("to", "")};
    }

    public void observe(String state, boolean identityVerification) {
        long now = System.currentTimeMillis();
        synchronized (this) {
            if (identityVerification) {
                boolean wasActive = prefs.getBoolean("identity_active", false);
                long last = prefs.getLong("identity_last_alert", 0L);
                if (!wasActive || last == 0L || now - last >= INTERVAL) {
                    prefs.edit().putBoolean("identity_active", true)
                            .putLong("identity_last_alert", now).apply();
                    sendAsync("身份验证提醒", "检测到程序进入身份验证状态。\n当前状态：" + state
                            + "\n时间：" + new java.util.Date(now));
                }
                return;
            }
            if (prefs.getBoolean("identity_active", false)) {
                prefs.edit().putBoolean("identity_active", false)
                        .putLong("identity_last_alert", 0L).apply();
            }
            String previous = prefs.getString("stuck_state", "");
            long since = prefs.getLong("stuck_since", now);
            boolean alerted = prefs.getBoolean("stuck_alerted", false);
            if (!state.equals(previous)) {
                prefs.edit().putString("stuck_state", state).putLong("stuck_since", now)
                        .putBoolean("stuck_alerted", false).apply();
            } else if (!alerted && now - since > INTERVAL) {
                prefs.edit().putBoolean("stuck_alerted", true).apply();
                sendAsync("状态机疑似卡死提醒", "程序状态连续超过 30 分钟未变化。\n当前状态：" + state
                        + "\n开始时间：" + new java.util.Date(since)
                        + "\n检测时间：" + new java.util.Date(now));
            }
        }
    }

    public void resetMonitoring() {
        prefs.edit().remove("stuck_state").remove("stuck_since").remove("stuck_alerted")
                .putBoolean("identity_active", false).putLong("identity_last_alert", 0L).apply();
    }

    public void sendTestAsync() { sendAsync("RedFingerGameBot 邮件测试", "邮件提醒配置成功。此邮件用于确认 SMTP 设置可用。"); }

    private void sendAsync(String subject, String body) {
        new Thread(() -> {
            Exception last = null;
            for (int attempt = 1; attempt <= 3; attempt++) {
                try { send(subject, body); return; }
                catch (Exception e) {
                    last = e;
                    android.util.Log.e("RFG-Email", "邮件发送失败，第 " + attempt + " 次", e);
                    if (attempt < 3) {
                        try { Thread.sleep(30_000L); }
                        catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); return; }
                    }
                }
            }
            if (last != null) android.util.Log.e("RFG-Email", "邮件重试仍失败，请检查 SMTP 设置", last);
        }, "RFG-Email-Sender").start();
    }

    private void send(String subject, String body) throws Exception {
        String host = prefs.getString("host", "");
        int port = prefs.getInt("port", 587);
        String from = prefs.getString("from", "");
        String to = prefs.getString("to", "");
        String encrypted = prefs.getString("password", "");
        if (host.isEmpty() || from.isEmpty() || to.isEmpty() || encrypted.isEmpty())
            throw new IllegalStateException("尚未配置邮件提醒");
        String password = decrypt(context, encrypted);
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", String.valueOf(port));
        props.put("mail.smtp.connectiontimeout", "15000");
        props.put("mail.smtp.timeout", "15000");
        props.put("mail.smtp.writetimeout", "15000");
        Session session = Session.getInstance(props, new Authenticator() {
            @Override protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
        message.setSubject(subject, "UTF-8");
        message.setText(body, "UTF-8");
        Transport.send(message);
    }

    private static String encrypt(Context c, String value) throws Exception {
        SecretKey key = getKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV();
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] all = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, all, 0, iv.length);
        System.arraycopy(encrypted, 0, all, iv.length, encrypted.length);
        return Base64.encodeToString(all, Base64.NO_WRAP);
    }

    private static String decrypt(Context c, String value) throws Exception {
        byte[] all = Base64.decode(value, Base64.NO_WRAP);
        byte[] iv = new byte[12];
        System.arraycopy(all, 0, iv, 0, 12);
        byte[] encrypted = new byte[all.length - 12];
        System.arraycopy(all, 12, encrypted, 0, encrypted.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    private static SecretKey getKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return (SecretKey) ks.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();
    }
}
