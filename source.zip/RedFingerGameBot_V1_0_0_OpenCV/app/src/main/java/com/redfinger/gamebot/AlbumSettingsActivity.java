package com.redfinger.gamebot;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/** Configuration for the 12-song album controller. */
public class AlbumSettingsActivity extends Activity {
    private Spinner mode;
    private EditText nextX, nextY, doneX, doneY;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences p = getSharedPreferences("album_automation", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(246,248,251));
        scroll.addView(root);
        TextView title = label("专辑自动脚本设置", 23, true); root.addView(title);
        TextView desc = label("固定处理12首歌曲。请先填写两个返回/切歌坐标；坐标使用当前横屏截图像素。", 13, false);
        root.addView(desc);
        root.addView(label("完成模式", 16, true));
        mode = new Spinner(this);
        mode.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"仅传说难度（legend_only）", "四个难度全部完成（all_difficulties）"}));
        mode.setSelection("all_difficulties".equals(p.getString("completion_mode","legend_only")) ? 1 : 0);
        root.addView(mode);
        root.addView(label("切换下一首歌曲坐标", 16, true));
        nextX = field(root, "X 坐标", p.getInt("coord_next_song_x",0));
        nextY = field(root, "Y 坐标", p.getInt("coord_next_song_y",0));
        root.addView(label("难度全部完成后返回目录坐标", 16, true));
        doneX = field(root, "X 坐标", p.getInt("coord_difficulty_done_return_x",0));
        doneY = field(root, "Y 坐标", p.getInt("coord_difficulty_done_return_y",0));
        TextView caution = label("注意：此版本采用异常后暂停并发送邮件的保守策略；千音雅集目录等待按需求无限等待。SMTP 请在“邮箱提醒设置”中配置。", 13, false);
        root.addView(caution);
        Button save = new Button(this); save.setText("保存专辑设置"); save.setAllCaps(false);
        root.addView(save);
        save.setOnClickListener(v -> save());
        setContentView(scroll);
    }

    private EditText field(LinearLayout root, String hint, int value) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setInputType(2); e.setHint(hint); e.setText(value > 0 ? String.valueOf(value) : "");
        root.addView(e); return e;
    }
    private void save() {
        try {
            int nx = Integer.parseInt(nextX.getText().toString().trim());
            int ny = Integer.parseInt(nextY.getText().toString().trim());
            int dx = Integer.parseInt(doneX.getText().toString().trim());
            int dy = Integer.parseInt(doneY.getText().toString().trim());
            if (nx <= 0 || ny <= 0 || dx <= 0 || dy <= 0) throw new IllegalArgumentException();
            getSharedPreferences("album_automation", MODE_PRIVATE).edit()
                    .putString("completion_mode", mode.getSelectedItemPosition()==1 ? "all_difficulties" : "legend_only")
                    .putInt("coord_next_song_x", nx).putInt("coord_next_song_y", ny)
                    .putInt("coord_difficulty_done_return_x", dx).putInt("coord_difficulty_done_return_y", dy)
                    .apply();
            Toast.makeText(this, "专辑设置已保存", Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "请填写四个大于0的坐标", Toast.LENGTH_LONG).show();
        }
    }
    private TextView label(String text, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size);
        t.setTextColor(Color.rgb(35,45,58)); if (bold) t.setTypeface(null,1);
        t.setPadding(0,dp(12),0,dp(5)); return t;
    }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
}
