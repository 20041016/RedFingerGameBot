package com.redfinger.gamebot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.HashMap;
import java.util.Map;

public class BotService extends Service {
    private static volatile BotService instance;
    public static final String ACTION_SHOW = "com.redfinger.gamebot.SHOW";
    public static final String ACTION_START_ENGINE = "com.redfinger.gamebot.START_ENGINE";
    public static final String ACTION_STOP_ENGINE = "com.redfinger.gamebot.STOP_ENGINE";
    public static final String ACTION_CLOSE = "com.redfinger.gamebot.CLOSE";
    public static final String ACTION_START = ACTION_SHOW;
    public static final String ACTION_STOP = ACTION_CLOSE;
    public static final String EXTRA_MODE = "engine_mode";
    public static final String MODE_GAME = "game";
    public static final String MODE_MUSIC = "music";

    private static final String CHANNEL = "rfgb_service";
    private static final int NOTIFICATION_ID = 601;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private volatile boolean active = false;
    private volatile boolean engineTaskRunning = false;
    private volatile boolean closeRequested = false;
    private volatile String selectedMode = MODE_GAME;
    private volatile String pendingMode = null;
    private RootHost host;
    private PyObject engine;
    private WindowManager windowManager;

    private LinearLayout overlay;
    private LinearLayout expandedPanel;
    private LinearLayout coordinatePanel;
    private LinearLayout coordinateWindow;
    private WindowManager.LayoutParams coordinateWindowParams;
    private TextView coordinateMenuButton;
    private TextView coordinateProgressText;
    private String pendingCoordinateKey = null;
    private RootTouchCapture coordinateCapture;
    private final Map<String, TextView> coordinateValueViews = new HashMap<>();
    private final Map<String, Integer> coordinateValues = new HashMap<>();
    private static final String[] COORD_KEYS = {"lane_1","lane_2","lane_3","lane_4","lane_5","lane_6","detect_y","touch_x","touch_y"};
    private static final int[] COORD_DEFAULTS = {778,1100,1440,1780,2100,2440,1210,230,-1};
    private static final String[] GAME_COORD_KEYS = {"run_x","run_y","extra_x","extra_y","search_start_x","search_start_y","search_end_x","search_end_y","dead_zone","view_gain_milli"};
    private static final int[] GAME_COORD_DEFAULTS = {1066,194,1231,503,960,360,660,360,50,300};
    private TextView miniDot;
    private TextView toggleButton;
    private TextView statusText;
    private WindowManager.LayoutParams overlayParams;
    private boolean expanded = false;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_SHOW : intent.getAction();
        if (ACTION_START_ENGINE.equals(action)) {
            ensureForeground("准备启动");
            if (overlay == null) showOverlay();
            String mode = intent == null ? MODE_GAME : intent.getStringExtra(EXTRA_MODE);
            startEngine(mode == null ? MODE_GAME : mode);
        } else if (ACTION_STOP_ENGINE.equals(action)) {
            stopEngine();
        } else if (ACTION_CLOSE.equals(action)) {
            closePanel();
        } else {
            // Opening the app's feature card must never start Python directly.
            // It only selects the mode and displays the floating controller.
            String requestedMode = intent == null ? null : intent.getStringExtra(EXTRA_MODE);
            if (MODE_MUSIC.equals(requestedMode) || MODE_GAME.equals(requestedMode)) {
                selectedMode = requestedMode;
            }
            ensureForeground("控制面板已就绪");
            showOverlay();
            updateStatus("悬浮窗已打开", MODE_MUSIC.equals(selectedMode)
                    ? "音游辅助待命，点击绿色按钮才会启动脚本"
                    : "游戏挂机待命，点击绿色按钮才会启动脚本");
        }
        return START_STICKY;
    }

    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
    }

    private synchronized void startEngine(String mode) {
        if (!MODE_MUSIC.equals(mode)) mode = MODE_GAME;
        if (engineTaskRunning) {
            if (mode.equals(selectedMode) && active) {
                updateStatus("正在运行", "当前功能已经启动");
            } else {
                pendingMode = mode;
                active = false;
                updateStatus("正在切换功能", "先停止当前任务并释放所有触点");
            }
            return;
        }
        selectedMode = mode;
        if (!Settings.canDrawOverlays(this)) {
            updateStatus("缺少悬浮窗权限", "请返回应用授予权限");
            return;
        }
        closeRequested = false;
        active = true;
        engineTaskRunning = true;
        updateStatus("正在初始化", MODE_MUSIC.equals(selectedMode)
                ? "申请 Root 并初始化六轨颜色检测与多点触控"
                : "申请 Root 并初始化中文 OCR");
        worker.execute(this::initializeAndLoop);
    }

    private void stopEngine() {
        pendingMode = null;
        active = false;
        updateStatus("正在暂停", "等待当前识别帧结束");
        if (!engineTaskRunning) updateStatus("已停止", "点击启动可重新识别当前场景");
    }

    private void closePanel() {
        pendingMode = null;
        closeRequested = true;
        active = false;
        updateStatus("正在关闭", "正在停止挂机引擎");
        if (!engineTaskRunning) finishClose();
    }

    private void initializeAndLoop() {
        boolean failed = false;
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            host = new RootHost(this, getCacheDir(), getExternalFilesDir("logs"));
            String rootInfo = host.checkRoot();
            host.log("Root 授权成功：" + rootInfo);
            if (MODE_GAME.equals(selectedMode)) {
                try {
                    String a11y = host.enableVerificationAccessibilityWithRoot();
                    host.log("Root 已尝试启用验证页面无障碍监听：" + a11y);
                } catch (Exception accessibilityError) {
                    host.log("Root 自动启用无障碍失败：" + accessibilityError.getMessage());
                    updateStatus("无障碍自动启用失败", accessibilityError.getMessage());
                }
            }
            updateStatus("Root 已授权", MODE_MUSIC.equals(selectedMode)
                    ? "正在检测触摸设备与六轨采样点" : "正在初始化中文 OCR");

            String moduleName = MODE_MUSIC.equals(selectedMode) ? "python.music_bot" : "python.bot";
            String className = MODE_MUSIC.equals(selectedMode) ? "MusicBot" : "GameBot";
            PyObject module = Python.getInstance().getModule(moduleName);
            engine = module.callAttr(className, host);
            engine.callAttr("start");
            if (MODE_MUSIC.equals(selectedMode)) {
                // Give the real-time rhythm loop display-class scheduling priority.
                // This changes scheduling only; all game and touch coordinates stay fixed.
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY);
            }
            updateStatus(MODE_MUSIC.equals(selectedMode) ? "音游运行中" : "识别中",
                    MODE_MUSIC.equals(selectedMode) ? "正在检测六条轨道" : "正在读取当前画面文字");

            long lastUiUpdate = 0;
            while (active) {
                engine.callAttr("step");
                int interval = safePythonInt(engine.get("loop_interval_ms"),
                        MODE_MUSIC.equals(selectedMode) ? 5 : 300);
                long now = System.currentTimeMillis();
                if (!MODE_MUSIC.equals(selectedMode) || now - lastUiUpdate >= 500) {
                    String state = safePythonString(engine.get("state"), "运行中");
                    String diagnostic = safePythonString(engine.get("diagnostic"), "等待识别");
                    updateStatus(state, diagnostic);
                    lastUiUpdate = now;
                }
                if (active && !MODE_MUSIC.equals(selectedMode)) {
                    Thread.sleep(Math.max(1, Math.min(interval, 1000)));
                } else if (active) {
                    // Music mode is paced by the Root frame stream; do not add a fixed 5 ms sleep.
                    Thread.yield();
                }
            }
        } catch (Exception e) {
            android.util.Log.e("RFG-Service", "挂机引擎异常", e);
            failed = true;
            String detail = e.getMessage() == null ? e.toString() : e.getMessage();
            updateStatus("运行异常", detail);
            active = false;
        } finally {
            try { if (engine != null) engine.callAttr("stop"); }
            catch (Exception ignored) {}
            try { if (host != null) host.close(); }
            catch (Exception ignored) {}
            host = null;
            engine = null;
            engineTaskRunning = false;
            if (closeRequested) {
                main.post(this::finishClose);
            } else if (pendingMode != null) {
                final String next = pendingMode;
                pendingMode = null;
                main.post(() -> startEngine(next));
            } else if (!failed) {
                updateStatus("已停止", "点击启动可重新运行当前功能");
            }
        }
    }

    /** Called by the accessibility service when a visible identity-verification prompt appears. */
    public static void onVerificationPromptDetected() {
        BotService service = instance;
        if (service == null || !MODE_GAME.equals(service.selectedMode)) return;
        service.main.post(() -> {
            if (service.active || service.engineTaskRunning) {
                service.active = false;
                service.updateStatus("等待人工验证", "检测到账号验证页面；已暂停挂机并释放触点，请本人完成验证");
            }
        });
    }

    private int safePythonInt(PyObject value, int fallback) {
        try { return value == null ? fallback : value.toInt(); }
        catch (Exception e) { return fallback; }
    }

    private String safePythonString(PyObject value, String fallback) {
        try {
            if (value == null) return fallback;
            String s = value.toJava(String.class);
            return s == null ? fallback : s;
        } catch (Exception e) {
            return fallback;
        }
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return;

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.HORIZONTAL);
        overlay.setGravity(Gravity.CENTER_VERTICAL);
        overlay.setPadding(dp(3), dp(3), dp(4), dp(3));
        overlay.setBackground(roundBg(0xE6202020, dp(18)));

        miniDot = new TextView(this);
        miniDot.setText("●");
        miniDot.setTextSize(17);
        miniDot.setTextColor(0xFF9E9E9E);
        miniDot.setGravity(Gravity.CENTER);
        overlay.addView(miniDot, new LinearLayout.LayoutParams(dp(29), dp(29)));

        expandedPanel = new LinearLayout(this);
        expandedPanel.setOrientation(LinearLayout.HORIZONTAL);
        expandedPanel.setGravity(Gravity.CENTER_VERTICAL);
        expandedPanel.setPadding(dp(2), 0, 0, 0);

        toggleButton = makeCircleButton("▶", 0xFF238B50, 32);
        toggleButton.setContentDescription(MODE_MUSIC.equals(selectedMode) ? "启动音游辅助" : "启动游戏挂机");
        toggleButton.setOnClickListener(v -> {
            if (active || engineTaskRunning) stopEngine();
            else startEngine(selectedMode);
        });
        expandedPanel.addView(toggleButton);

        statusText = new TextView(this);
        statusText.setText("待命");
        statusText.setTextColor(0xFFFFFFFF);
        statusText.setTextSize(10);
        statusText.setMaxWidth(dp(190));
        statusText.setMaxLines(3);
        statusText.setPadding(dp(5), 0, dp(5), 0);
        expandedPanel.addView(statusText, new LinearLayout.LayoutParams(dp(150), -2));

        TextView settings = makeCircleButton("坐", 0xFF365D91, 32);
        settings.setContentDescription("打开坐标设置子菜单");
        expandedPanel.addView(settings);
        coordinateMenuButton = settings;

        TextView collapse = makeCircleButton("⌄", 0xFF555555, 32);
        collapse.setContentDescription("收起控制栏");
        collapse.setOnClickListener(v -> setExpanded(false));
        expandedPanel.addView(collapse);

        TextView close = makeCircleButton("×", 0xFF8B3434, 32);
        close.setContentDescription("关闭悬浮窗");
        close.setOnClickListener(v -> closePanel());
        expandedPanel.addView(close);

        overlay.addView(expandedPanel);

        // Coordinate settings open in a separate, compact floating window.
        coordinatePanel = new LinearLayout(this); // retained as a compatibility reference only
        coordinateMenuButton = settings;
        settings.setOnClickListener(v -> toggleCoordinateWindow());

        setExpanded(false);


        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.x = dp(12);
        overlayParams.y = dp(120);

        attachDragAndClick(miniDot);
        try {
            windowManager.addView(overlay, overlayParams);
            updateDot();
        } catch (Exception e) {
            android.util.Log.e("RFG-Service", "悬浮窗创建失败", e);
            overlay = null;
            expandedPanel = null;
            miniDot = null;
            toggleButton = null;
        statusText = null;
        }
    }

    private void attachDragAndClick(View target) {
        final int[] startPos = new int[2];
        final float[] startTouch = new float[2];
        final boolean[] moved = new boolean[1];
        target.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startPos[0] = overlayParams.x;
                    startPos[1] = overlayParams.y;
                    startTouch[0] = event.getRawX();
                    startTouch[1] = event.getRawY();
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (event.getRawX() - startTouch[0]);
                    int dy = (int) (event.getRawY() - startTouch[1]);
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved[0] = true;
                    if (moved[0]) {
                        overlayParams.x = startPos[0] + dx;
                        overlayParams.y = startPos[1] + dy;
                        try { windowManager.updateViewLayout(overlay, overlayParams); }
                        catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) setExpanded(!expanded);
                    return true;
            }
            return true;
        });
    }

    private void setExpanded(boolean value) {
        expanded = value;
        if (!value) closeCoordinateWindow();
        if (expandedPanel != null) expandedPanel.setVisibility(value ? View.VISIBLE : View.GONE);
        if (overlay != null && overlayParams != null) {
            overlay.requestLayout();
            try { windowManager.updateViewLayout(overlay, overlayParams); }
            catch (Exception ignored) {}
        }
    }


    private void toggleCoordinateWindow() {
        if (coordinateWindow != null) closeCoordinateWindow();
        else showCoordinateWindow();
    }

    private void showCoordinateWindow() {
        if (coordinateWindow != null || !Settings.canDrawOverlays(this)) return;
        if (MODE_GAME.equals(selectedMode)) { showGameCoordinateWindow(); return; }
        android.content.SharedPreferences prefs = getSharedPreferences("music_coordinates", MODE_PRIVATE);
        coordinateValues.clear(); coordinateValueViews.clear();
        for (int i = 0; i < COORD_KEYS.length; i++) coordinateValues.put(COORD_KEYS[i], prefs.getInt(COORD_KEYS[i], COORD_DEFAULTS[i]));
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(11), dp(9), dp(11), dp(9));
        card.setBackground(roundBg(0xF21A202A, dp(16)));
        card.setElevation(dp(10));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("坐标设置"); title.setTextColor(0xFFF2F6FC);
        title.setTextSize(14); title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(32), 1));
        TextView close = makeCircleButton("×", 0xFF465365, 27);
        close.setOnClickListener(v -> closeCoordinateWindow());
        header.addView(close);
        card.addView(header);

        // The content is independently scrollable; the floating card stays within the screen.
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(2), 0, dp(4));

        content.addView(smallSection("六轨检测坐标"));
        String[] laneDefaults = {"778", "1100", "1440", "1780", "2100", "2440"};
        for (int i = 1; i <= 6; i++) {
            final int laneIndex = i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView lane = new TextView(this);
            lane.setText(String.format(java.util.Locale.US, "%02d  第 %d 轨", i, i));
            lane.setTextColor(0xFFE5EBF4); lane.setTextSize(11);
            row.addView(lane, new LinearLayout.LayoutParams(0, dp(34), 1));
            TextView value = new TextView(this);
            value.setText("X=" + coordinateValues.get("lane_" + i)); value.setTextColor(0xFF8FA3BC); value.setTextSize(9);
            coordinateValueViews.put("lane_" + i, value);
            row.addView(value, new LinearLayout.LayoutParams(dp(57), dp(30)));
            TextView capture = smallAction("记录");
            capture.setContentDescription("记录第" + laneIndex + "轨检测坐标");
            capture.setOnClickListener(v -> beginCoordinateCapture("lane_" + laneIndex,
                    "第 " + laneIndex + " 轨检测 X"));
            row.addView(capture, new LinearLayout.LayoutParams(dp(48), dp(28)));
            content.addView(row);
            if (i < 6) content.addView(separator());
        }

        content.addView(smallSection("其他坐标"));
        String[][] extras = {{"检测线 Y", "detect_y"},
                {"触摸 X", "touch_x"}, {"触摸 Y", "touch_y"}};
        for (String[] item : extras) {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = new TextView(this); label.setText(item[0]); label.setTextColor(0xFFCAD4E2); label.setTextSize(10);
            row.addView(label, new LinearLayout.LayoutParams(0, dp(32), 1));
            TextView value = new TextView(this); value.setText("touch_y".equals(item[1]) && coordinateValues.get(item[1]) < 0 ? "跟随轨道 X" : String.valueOf(coordinateValues.get(item[1]))); value.setTextColor(0xFF8FA3BC); value.setTextSize(9);
            coordinateValueViews.put(item[1], value);
            row.addView(value, new LinearLayout.LayoutParams(dp(75), dp(30)));
            TextView action = smallAction("记录");
            action.setOnClickListener(v -> beginCoordinateCapture(item[1], item[0]));
            row.addView(action, new LinearLayout.LayoutParams(dp(48), dp(27)));
            content.addView(row);
        }
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(7), 0, dp(3));
        TextView save = smallAction("保存参数");
        save.setOnClickListener(v -> {
            android.content.SharedPreferences.Editor editor = getSharedPreferences("music_coordinates", MODE_PRIVATE).edit();
            for (String key : COORD_KEYS) editor.putInt(key, coordinateValues.get(key));
            editor.apply(); updateStatus("坐标已保存", "下次启动音游脚本时使用这些坐标");
        });
        footer.addView(save, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView reset = smallAction("恢复默认");
        reset.setOnClickListener(v -> {
            pendingCoordinateKey = null;
            if (coordinateCapture != null) { coordinateCapture.close(); coordinateCapture = null; }
            for (int i = 0; i < COORD_KEYS.length; i++) coordinateValues.put(COORD_KEYS[i], COORD_DEFAULTS[i]);
            refreshCoordinateValues();
            android.content.SharedPreferences.Editor editor = getSharedPreferences("music_coordinates", MODE_PRIVATE).edit();
            for (String key : COORD_KEYS) editor.putInt(key, coordinateValues.get(key));
            editor.apply();
            updateStatus("恢复默认", "默认坐标已恢复并保存");
        });
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(0, dp(30), 1);
        resetLp.leftMargin = dp(6);
        footer.addView(reset, resetLp);
        content.addView(footer);
        scroll.addView(content);
        card.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        coordinateWindow = card;
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int maxHeight = Math.min(dp(560), (int) (metrics.heightPixels * 0.76f));
        coordinateWindowParams = new WindowManager.LayoutParams(
                dp(270), maxHeight,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        coordinateWindowParams.gravity = Gravity.TOP | Gravity.LEFT;
        coordinateWindowParams.x = overlayParams != null ? overlayParams.x + dp(48) : dp(18);
        coordinateWindowParams.y = overlayParams != null ? overlayParams.y + dp(48) : dp(160);
        attachCoordinateWindowDrag(header);
        try { windowManager.addView(coordinateWindow, coordinateWindowParams); }
        catch (Exception e) { coordinateWindow = null; android.util.Log.e("RFG-Service", "坐标窗口创建失败", e); }
    }

    private void showGameCoordinateWindow() {
        android.content.SharedPreferences prefs = getSharedPreferences("game_coordinates", MODE_PRIVATE);
        coordinateValues.clear(); coordinateValueViews.clear();
        for (int i = 0; i < GAME_COORD_KEYS.length; i++)
            coordinateValues.put(GAME_COORD_KEYS[i], prefs.getInt(GAME_COORD_KEYS[i], GAME_COORD_DEFAULTS[i]));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(11), dp(9), dp(11), dp(9));
        card.setBackground(roundBg(0xF21A202A, dp(16)));
        card.setElevation(dp(10));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("游戏挂机坐标"); title.setTextColor(0xFFF2F6FC);
        title.setTextSize(14); title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(32), 1));
        TextView close = makeCircleButton("×", 0xFF465365, 27);
        close.setOnClickListener(v -> closeCoordinateWindow()); header.addView(close);
        card.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false); scroll.setVerticalScrollBarEnabled(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(2), 0, dp(4));
        content.addView(smallSection("按钮位置（1280 × 720）"));
        addGameCoordinatePairRow(content, "奔跑按钮", "run_x", "run_y");
        content.addView(separator());
        addGameCoordinatePairRow(content, "额外点击按钮", "extra_x", "extra_y");
        content.addView(smallSection("搜索视角滑动"));
        addGameCoordinatePairRow(content, "滑动起点", "search_start_x", "search_start_y");
        addGameCoordinatePairRow(content, "滑动终点", "search_end_x", "search_end_y");
        content.addView(smallSection("视角修正参数"));
        addGameTuningRow(content, "死区（像素）", "dead_zone", 0, 200, 5);
        addGameTuningRow(content, "修正比例", "view_gain_milli", 0, 1000, 50);

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(7), 0, dp(3));
        TextView save = smallAction("保存参数");
        save.setOnClickListener(v -> {
            android.content.SharedPreferences.Editor editor = getSharedPreferences("game_coordinates", MODE_PRIVATE).edit();
            for (String key : GAME_COORD_KEYS) editor.putInt(key, coordinateValues.get(key));
            editor.apply(); updateStatus("挂机坐标已保存", "下次启动游戏挂机脚本时使用这些参数");
        });
        footer.addView(save, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView reset = smallAction("恢复默认");
        reset.setOnClickListener(v -> {
            cancelCoordinateCapture();
            for (int i = 0; i < GAME_COORD_KEYS.length; i++) coordinateValues.put(GAME_COORD_KEYS[i], GAME_COORD_DEFAULTS[i]);
            refreshGameCoordinateValues();
            android.content.SharedPreferences.Editor editor = getSharedPreferences("game_coordinates", MODE_PRIVATE).edit();
            for (String key : GAME_COORD_KEYS) editor.putInt(key, coordinateValues.get(key));
            editor.apply(); updateStatus("恢复默认", "游戏挂机默认参数已恢复并保存");
        });
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(0, dp(30), 1);
        resetLp.leftMargin = dp(6); footer.addView(reset, resetLp);
        content.addView(footer); scroll.addView(content);
        card.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        coordinateWindow = card;
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int maxHeight = Math.min(dp(560), (int) (metrics.heightPixels * 0.76f));
        coordinateWindowParams = new WindowManager.LayoutParams(dp(270), maxHeight,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        coordinateWindowParams.gravity = Gravity.TOP | Gravity.LEFT;
        coordinateWindowParams.x = overlayParams != null ? overlayParams.x + dp(48) : dp(18);
        coordinateWindowParams.y = overlayParams != null ? overlayParams.y + dp(48) : dp(160);
        attachCoordinateWindowDrag(header);
        try { windowManager.addView(coordinateWindow, coordinateWindowParams); }
        catch (Exception e) { coordinateWindow = null; android.util.Log.e("RFG-Service", "挂机坐标窗口创建失败", e); }
    }

    private void addGameCoordinatePairRow(LinearLayout parent, String labelText, String xKey, String yKey) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(2));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(0xFFE5EBF4);
        label.setTextSize(10);
        labels.addView(label);
        TextView value = new TextView(this);
        value.setText(formatGameCoordinatePair(xKey, yKey));
        value.setTextColor(0xFF8FA3BC);
        value.setTextSize(9);
        coordinateValueViews.put(xKey, value);
        labels.addView(value);
        row.addView(labels, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView record = smallAction("记录 X/Y");
        record.setOnClickListener(v -> beginGameCoordinateCapture(xKey, yKey, labelText));
        row.addView(record, new LinearLayout.LayoutParams(dp(68), dp(28)));
        parent.addView(row);
    }

    private String formatGameCoordinatePair(String xKey, String yKey) {
        return "X=" + coordinateValues.get(xKey) + "   Y=" + coordinateValues.get(yKey);
    }

    private void addGameTuningRow(LinearLayout parent, String labelText, String key, int min, int max, int step) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this); label.setText(labelText); label.setTextColor(0xFFCAD4E2); label.setTextSize(10);
        row.addView(label, new LinearLayout.LayoutParams(0, dp(31), 1));
        TextView value = new TextView(this); value.setText(formatGameTuning(key, coordinateValues.get(key)));
        value.setTextColor(0xFF8FA3BC); value.setTextSize(9); coordinateValueViews.put(key, value);
        row.addView(value, new LinearLayout.LayoutParams(dp(55), dp(28)));
        TextView minus = smallAction("−");
        minus.setOnClickListener(v -> changeGameTuning(key, Math.max(min, coordinateValues.get(key) - step)));
        row.addView(minus, new LinearLayout.LayoutParams(dp(30), dp(27)));
        TextView plus = smallAction("+");
        plus.setOnClickListener(v -> changeGameTuning(key, Math.min(max, coordinateValues.get(key) + step)));
        LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(30), dp(27)); plusLp.leftMargin = dp(4); row.addView(plus, plusLp);
        parent.addView(row);
    }

    private String formatGameTuning(String key, int value) {
        return "view_gain_milli".equals(key) ? String.format(java.util.Locale.US, "%.2f", value / 1000.0f) : String.valueOf(value);
    }

    private void changeGameTuning(String key, int value) {
        coordinateValues.put(key, value);
        TextView view = coordinateValueViews.get(key);
        if (view != null) view.setText(formatGameTuning(key, value));
    }

    private void refreshGameCoordinateValues() {
        String[][] pairs = {{"run_x", "run_y"}, {"extra_x", "extra_y"},
                {"search_start_x", "search_start_y"}, {"search_end_x", "search_end_y"}};
        for (String[] pair : pairs) {
            TextView view = coordinateValueViews.get(pair[0]);
            if (view != null) view.setText(formatGameCoordinatePair(pair[0], pair[1]));
        }
        for (String key : new String[]{"dead_zone", "view_gain_milli"}) {
            TextView view = coordinateValueViews.get(key);
            if (view != null) view.setText(formatGameTuning(key, coordinateValues.get(key)));
        }
    }

    private void cancelCoordinateCapture() {
        pendingCoordinateKey = null;
        if (coordinateCapture != null) { coordinateCapture.close(); coordinateCapture = null; }
    }

    private void beginGameCoordinateCapture(String xKey, String yKey, String label) {
        if (engineTaskRunning || active) {
            updateStatus("暂不能记录", "请先停止脚本，再记录坐标，避免采集到脚本注入的触点");
            return;
        }
        if (coordinateCapture != null) coordinateCapture.close();
        pendingCoordinateKey = xKey;
        updateStatus("等待触摸", "请在游戏画面点一下" + label + "，一次同时记录 X/Y");
        coordinateCapture = new RootTouchCapture();
        coordinateCapture.start(new RootTouchCapture.Callback() {
            @Override public void onCaptured(int rawX, int rawY, int minX, int maxX, int minY, int maxY) {
                int portraitX = scaleRaw(rawX, minX, maxX, 1440);
                int portraitY = scaleRaw(rawY, minY, maxY, 3200);
                // GameBot reference space is landscape 1280x720; derive both axes from this one touch.
                int landscapeX = scaleRaw(portraitY, 0, 3199, 1280);
                int landscapeY = 719 - scaleRaw(portraitX, 0, 1439, 720);
                main.post(() -> {
                    if (!xKey.equals(pendingCoordinateKey)) return;
                    coordinateValues.put(xKey, landscapeX);
                    coordinateValues.put(yKey, landscapeY);
                    refreshGameCoordinateValues();
                    pendingCoordinateKey = null;
                    coordinateCapture = null;
                    updateStatus("坐标已记录", label + "：X=" + landscapeX + "，Y=" + landscapeY + "；点击保存参数以持久化");
                });
            }
            @Override public void onError(String message) {
                main.post(() -> { if (xKey.equals(pendingCoordinateKey)) { pendingCoordinateKey=null; coordinateCapture=null; updateStatus("记录失败", message); } });
            }
        });
    }

    private void beginCoordinateCapture(String key, String label) {
        if (engineTaskRunning || active) {
            updateStatus("暂不能记录", "请先停止脚本，再记录坐标，避免采集到脚本注入的触点");
            return;
        }
        if (coordinateCapture != null) coordinateCapture.close();
        pendingCoordinateKey = key;
        updateStatus("等待触摸", "请在游戏画面点一下，正在记录" + label);
        coordinateCapture = new RootTouchCapture();
        coordinateCapture.start(new RootTouchCapture.Callback() {
            @Override public void onCaptured(int rawX, int rawY, int minX, int maxX, int minY, int maxY) {
                int portraitX = scaleRaw(rawX, minX, maxX, 1440);
                int portraitY = scaleRaw(rawY, minY, maxY, 3200);
                final int value;
                if (GAME_COORD_KEYS.length > 0 && java.util.Arrays.asList(GAME_COORD_KEYS).contains(key)) {
                    // GameBot uses landscape 1280x720 reference coordinates.
                    int landscapeX = scaleRaw(portraitY, 0, 3199, 1280);
                    int landscapeY = 719 - scaleRaw(portraitX, 0, 1439, 720);
                    value = key.endsWith("_x") ? landscapeX : landscapeY;
                } else if (key.startsWith("lane_")) value = portraitY;
                else if ("detect_y".equals(key)) value = Math.max(0, Math.min(1439, 1440 - portraitX));
                else if ("touch_x".equals(key)) value = portraitX;
                else value = portraitY;
                main.post(() -> {
                    if (!key.equals(pendingCoordinateKey)) return;
                    coordinateValues.put(key, value);
                    refreshCoordinateValues();
                    pendingCoordinateKey = null;
                    coordinateCapture = null;
                    updateStatus("坐标已记录", label + " = " + value + "；点击保存参数以持久化");
                });
            }
            @Override public void onError(String message) {
                main.post(() -> { if (key.equals(pendingCoordinateKey)) { pendingCoordinateKey=null; coordinateCapture=null; updateStatus("记录失败", message); } });
            }
        });
    }

    private int scaleRaw(int raw, int min, int max, int size) {
        if (max <= min) return 0;
        return Math.max(0, Math.min(size - 1, Math.round((raw - min) * (size - 1f) / (max - min))));
    }

    private void refreshCoordinateValues() {
        for (String key : COORD_KEYS) {
            TextView view = coordinateValueViews.get(key);
            if (view != null) view.setText(key.startsWith("lane_") ? "X=" + coordinateValues.get(key) : ("touch_y".equals(key) && coordinateValues.get(key) < 0 ? "跟随轨道 X" : String.valueOf(coordinateValues.get(key))));
        }
    }

    private void attachCoordinateWindowDrag(View handle) {
        final int[] start = new int[2];
        final float[] touch = new float[2];
        handle.setOnTouchListener((v, event) -> {
            if (coordinateWindowParams == null || coordinateWindow == null) return false;
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                start[0] = coordinateWindowParams.x; start[1] = coordinateWindowParams.y;
                touch[0] = event.getRawX(); touch[1] = event.getRawY(); return true;
            } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
                coordinateWindowParams.x = start[0] + (int) (event.getRawX() - touch[0]);
                coordinateWindowParams.y = start[1] + (int) (event.getRawY() - touch[1]);
                try { windowManager.updateViewLayout(coordinateWindow, coordinateWindowParams); } catch (Exception ignored) {}
                return true;
            }
            return event.getAction() == MotionEvent.ACTION_UP;
        });
    }

    private void closeCoordinateWindow() {
        cancelCoordinateCapture();
        if (coordinateWindow != null) {
            try { windowManager.removeView(coordinateWindow); } catch (Exception ignored) {}
        }
        coordinateWindow = null; coordinateWindowParams = null;
    }

    private TextView smallSection(String value) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(0xFF8FBFFF);
        t.setTextSize(10); t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(7), 0, dp(2)); return t;
    }
    private TextView smallAction(String value) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(0xFFD9E9FF);
        t.setTextSize(10); t.setGravity(Gravity.CENTER); t.setBackground(roundBg(0xFF29496B, dp(8)));
        return t;
    }
    private View separator() {
        View v = new View(this); v.setBackgroundColor(0x263D4A5B);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1))); return v;
    }

    private TextView makeCircleButton(String label, int color, int sizeDp) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(0xFFFFFFFF);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER);
        view.setPadding(0, 0, 0, 0);
        view.setMinWidth(0);
        view.setMinHeight(0);
        view.setIncludeFontPadding(false);
        view.setBackground(circleBg(color));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        lp.setMargins(dp(2), 0, dp(2), 0);
        view.setLayoutParams(lp);
        return view;
    }

    private GradientDrawable circleBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setShape(GradientDrawable.OVAL);
        return bg;
    }

    private GradientDrawable roundBg(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        return bg;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateStatus(String state, String diagnostic) {
        main.post(() -> {
            if (toggleButton != null) {
                boolean running = active || engineTaskRunning;
                toggleButton.setText(running ? "Ⅱ" : "▶");
                String taskName = MODE_MUSIC.equals(selectedMode) ? "音游辅助" : "游戏挂机";
                toggleButton.setContentDescription(running ? "暂停" + taskName : "启动" + taskName);
                toggleButton.setBackground(circleBg(running ? 0xFFB83232 : 0xFF238B50));
            }
            updateDot();
            if (statusText != null) statusText.setText(state + "\n" + diagnostic);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(state + " · " + diagnostic));
        });
    }

    private void updateDot() {
        if (miniDot != null) miniDot.setTextColor(active || engineTaskRunning ? 0xFF35D06F : 0xFF9E9E9E);
    }

    private void finishClose() {
        removeOverlayNow();
        stopForeground(true);
        stopSelf();
    }

    private void removeOverlayNow() {
        closeCoordinateWindow();
        if (overlay != null) {
            try { windowManager.removeView(overlay); }
            catch (Exception ignored) {}
        }
        overlay = null;
        expandedPanel = null;
        closeCoordinateWindow();
        coordinatePanel = null;
        coordinateMenuButton = null;
        coordinateProgressText = null;
        coordinateValueViews.clear();
        miniDot = null;
        toggleButton = null;
        statusText = null;
    }

    private Notification buildNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("RedFinger GameBot · " + (MODE_MUSIC.equals(selectedMode) ? "音游辅助" : "游戏挂机"))
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "挂机控制面板", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        active = false;
        removeOverlayNow();
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
