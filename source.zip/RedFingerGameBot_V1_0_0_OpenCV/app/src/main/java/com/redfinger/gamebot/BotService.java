package com.redfinger.gamebot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.pm.ServiceInfo;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BotService extends Service {
    public static final String ACTION_SHOW = "com.redfinger.gamebot.SHOW";
    public static final String ACTION_START_ENGINE = "com.redfinger.gamebot.START_ENGINE";
    public static final String ACTION_STOP_ENGINE = "com.redfinger.gamebot.STOP_ENGINE";
    public static final String ACTION_CLOSE = "com.redfinger.gamebot.CLOSE";
    public static final String ACTION_START = ACTION_SHOW;
    public static final String ACTION_STOP = ACTION_CLOSE;
    public static final String EXTRA_MODE = "engine_mode";
    public static final String EXTRA_PROJECTION_RESULT = "projection_result";
    public static final String EXTRA_PROJECTION_DATA = "projection_data";
    public static final String MODE_GAME = "game";
    public static final String MODE_MUSIC = "music";

    private static final String CHANNEL = "rfgb_service";
    private static final int NOTIFICATION_ID = 601;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private volatile boolean active = false;
    private volatile boolean engineTaskRunning = false;
    private volatile boolean closeRequested = false;
    private volatile String selectedMode = MODE_GAME;
    private volatile String pendingMode = null;
    private int pendingProjectionResultCode;
    private Intent pendingProjectionPermissionData;
    private RootHost host;
    private MediaProjection mediaProjection;
    private int projectionResultCode;
    private Intent projectionPermissionData;
    private PyObject engine;
    private WindowManager windowManager;

    private LinearLayout overlay;
    private LinearLayout expandedPanel;
    private TextView miniDot;
    private TextView toggleButton;
    private TextView statusText;
    private WindowManager.LayoutParams overlayParams;
    private boolean expanded = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_SHOW : intent.getAction();
        if (ACTION_START_ENGINE.equals(action)) {
            ensureForeground("准备启动");
            if (overlay == null) showOverlay();
            String mode = intent == null ? MODE_GAME : intent.getStringExtra(EXTRA_MODE);
            projectionResultCode = intent == null ? 0 : intent.getIntExtra(EXTRA_PROJECTION_RESULT, 0);
            projectionPermissionData = intent == null ? null : intent.getParcelableExtra(EXTRA_PROJECTION_DATA);
            startEngine(mode == null ? MODE_GAME : mode, projectionResultCode, projectionPermissionData);
        } else if (ACTION_STOP_ENGINE.equals(action)) {
            stopEngine();
        } else if (ACTION_CLOSE.equals(action)) {
            closePanel();
        } else {
            ensureForeground("控制面板已就绪");
            showOverlay();
            updateStatus("已停止", "点击绿色启动按钮开始识别");
        }
        return START_STICKY;
    }

    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
    }

    private synchronized void startEngine(String mode, int resultCode, Intent permissionData) {
        if (!MODE_MUSIC.equals(mode)) mode = MODE_GAME;
        if (engineTaskRunning) {
            if (mode.equals(selectedMode) && active) {
                updateStatus("正在运行", "当前功能已经启动");
            } else {
                pendingMode = mode;
                pendingProjectionResultCode = resultCode;
                pendingProjectionPermissionData = permissionData;
                active = false;
                updateStatus("正在切换功能", "先停止当前任务并释放所有触点");
            }
            return;
        }
        selectedMode = mode;
        projectionResultCode = resultCode;
        projectionPermissionData = permissionData;
        if (MODE_MUSIC.equals(mode) && (resultCode == 0 || permissionData == null)) {
            updateStatus("需要屏幕录制授权", "请回到应用主页点击启动音游，重新确认系统屏幕录制权限");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            updateStatus("缺少悬浮窗权限", "请返回应用授予权限");
            return;
        }
        closeRequested = false;
        active = true;
        engineTaskRunning = true;
        updateStatus("正在初始化", MODE_MUSIC.equals(selectedMode)
                ? "申请 Root 并初始化六轨颜色检测与多点触控"
                : "申请 Root 并初始化中文 OCR");
        worker.execute(this::initializeAndLoop);
    }

    private void stopEngine() {
        pendingMode = null;
        pendingProjectionResultCode = 0;
        pendingProjectionPermissionData = null;
        active = false;
        updateStatus("正在暂停", "等待当前识别帧结束");
        if (!engineTaskRunning) updateStatus("已停止", "点击启动可重新识别当前场景");
    }

    private void closePanel() {
        pendingMode = null;
        pendingProjectionResultCode = 0;
        pendingProjectionPermissionData = null;
        closeRequested = true;
        active = false;
        updateStatus("正在关闭", "正在停止挂机引擎");
        if (!engineTaskRunning) finishClose();
    }

    private void initializeAndLoop() {
        boolean failed = false;
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            if (MODE_MUSIC.equals(selectedMode)) {
                promoteForegroundForProjection();
                MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                mediaProjection = manager.getMediaProjection(projectionResultCode, projectionPermissionData);
                if (mediaProjection == null) throw new IllegalStateException("Android 未返回有效的屏幕录制会话，请重新授权");
            }
            host = new RootHost(getCacheDir(), getExternalFilesDir("logs"), mediaProjection,
                    getResources().getDisplayMetrics().densityDpi);
            String rootInfo = host.checkRoot();
            host.log("Root 授权成功：" + rootInfo);
            updateStatus("Root 已授权", MODE_MUSIC.equals(selectedMode)
                    ? "正在检测触摸设备与六轨采样点" : "正在初始化中文 OCR");

            String moduleName = MODE_MUSIC.equals(selectedMode) ? "python.music_bot" : "python.bot";
            String className = MODE_MUSIC.equals(selectedMode) ? "MusicBot" : "GameBot";
            PyObject module = Python.getInstance().getModule(moduleName);
            engine = module.callAttr(className, host);
            engine.callAttr("start");
            if (MODE_MUSIC.equals(selectedMode)) {
                // Give the real-time rhythm loop display-class scheduling priority.
                // This changes scheduling only; all game and touch coordinates stay fixed.
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY);
            }
            updateStatus(MODE_MUSIC.equals(selectedMode) ? "音游运行中" : "识别中",
                    MODE_MUSIC.equals(selectedMode) ? "正在检测六条轨道" : "正在读取当前画面文字");

            long lastUiUpdate = 0;
            while (active) {
                engine.callAttr("step");
                int interval = safePythonInt(engine.get("loop_interval_ms"),
                        MODE_MUSIC.equals(selectedMode) ? 5 : 300);
                long now = System.currentTimeMillis();
                if (!MODE_MUSIC.equals(selectedMode) || now - lastUiUpdate >= 500) {
                    String state = safePythonString(engine.get("state"), "运行中");
                    String diagnostic = safePythonString(engine.get("diagnostic"), "等待识别");
                    updateStatus(state, diagnostic);
                    lastUiUpdate = now;
                }
                if (active && !MODE_MUSIC.equals(selectedMode)) {
                    Thread.sleep(Math.max(1, Math.min(interval, 1000)));
                } else if (active) {
                    // Music mode is paced by the Root frame stream; do not add a fixed 5 ms sleep.
                    Thread.yield();
                }
            }
        } catch (Exception e) {
            android.util.Log.e("RFG-Service", "挂机引擎异常", e);
            failed = true;
            String detail = e.getMessage() == null ? e.toString() : e.getMessage();
            updateStatus("运行异常", detail);
            active = false;
        } finally {
            try { if (engine != null) engine.callAttr("stop"); }
            catch (Exception ignored) {}
            try { if (host != null) host.close(); }
            catch (Exception ignored) {}
            host = null;
            if (mediaProjection != null) {
                try { mediaProjection.stop(); } catch (Exception ignored) {}
                mediaProjection = null;
            }
            projectionPermissionData = null;
            projectionResultCode = 0;
            engine = null;
            engineTaskRunning = false;
            if (closeRequested) {
                main.post(this::finishClose);
            } else if (pendingMode != null) {
                final String next = pendingMode;
                final int nextProjectionCode = pendingProjectionResultCode;
                final Intent nextProjectionData = pendingProjectionPermissionData;
                pendingMode = null;
                pendingProjectionResultCode = 0;
                pendingProjectionPermissionData = null;
                main.post(() -> startEngine(next, nextProjectionCode, nextProjectionData));
            } else if (!failed) {
                updateStatus("已停止", "点击启动可重新运行当前功能");
            }
        }
    }

    private void promoteForegroundForProjection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, buildNotification("正在采集屏幕画面"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        }
    }

    private int safePythonInt(PyObject value, int fallback) {
        try { return value == null ? fallback : value.toInt(); }
        catch (Exception e) { return fallback; }
    }

    private String safePythonString(PyObject value, String fallback) {
        try {
            if (value == null) return fallback;
            String s = value.toJava(String.class);
            return s == null ? fallback : s;
        } catch (Exception e) {
            return fallback;
        }
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return;

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.HORIZONTAL);
        overlay.setGravity(Gravity.CENTER_VERTICAL);
        overlay.setPadding(dp(3), dp(3), dp(4), dp(3));
        overlay.setBackground(roundBg(0xE6202020, dp(18)));

        miniDot = new TextView(this);
        miniDot.setText("●");
        miniDot.setTextSize(17);
        miniDot.setTextColor(0xFF9E9E9E);
        miniDot.setGravity(Gravity.CENTER);
        overlay.addView(miniDot, new LinearLayout.LayoutParams(dp(29), dp(29)));

        expandedPanel = new LinearLayout(this);
        expandedPanel.setOrientation(LinearLayout.HORIZONTAL);
        expandedPanel.setGravity(Gravity.CENTER_VERTICAL);
        expandedPanel.setPadding(dp(2), 0, 0, 0);

        toggleButton = makeCircleButton("▶", 0xFF238B50, 32);
        toggleButton.setContentDescription("启动挂机");
        toggleButton.setOnClickListener(v -> {
            if (active || engineTaskRunning) stopEngine();
            else if (MODE_MUSIC.equals(selectedMode)) {
                updateStatus("需要重新授权", "请回到应用主页重新启动音游并确认屏幕录制权限");
            } else startEngine(selectedMode, 0, null);
        });
        expandedPanel.addView(toggleButton);

        statusText = new TextView(this);
        statusText.setText("待命");
        statusText.setTextColor(0xFFFFFFFF);
        statusText.setTextSize(10);
        statusText.setMaxWidth(dp(190));
        statusText.setMaxLines(3);
        statusText.setPadding(dp(5), 0, dp(5), 0);
        expandedPanel.addView(statusText, new LinearLayout.LayoutParams(dp(150), -2));

        TextView collapse = makeCircleButton("⌄", 0xFF555555, 32);
        collapse.setContentDescription("收起控制栏");
        collapse.setOnClickListener(v -> setExpanded(false));
        expandedPanel.addView(collapse);

        TextView close = makeCircleButton("×", 0xFF8B3434, 32);
        close.setContentDescription("关闭悬浮窗");
        close.setOnClickListener(v -> closePanel());
        expandedPanel.addView(close);

        overlay.addView(expandedPanel);
        setExpanded(false);

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.x = dp(12);
        overlayParams.y = dp(120);

        attachDragAndClick(miniDot);
        try {
            windowManager.addView(overlay, overlayParams);
            updateDot();
        } catch (Exception e) {
            android.util.Log.e("RFG-Service", "悬浮窗创建失败", e);
            overlay = null;
            expandedPanel = null;
            miniDot = null;
            toggleButton = null;
        statusText = null;
        }
    }

    private void attachDragAndClick(View target) {
        final int[] startPos = new int[2];
        final float[] startTouch = new float[2];
        final boolean[] moved = new boolean[1];
        target.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startPos[0] = overlayParams.x;
                    startPos[1] = overlayParams.y;
                    startTouch[0] = event.getRawX();
                    startTouch[1] = event.getRawY();
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (event.getRawX() - startTouch[0]);
                    int dy = (int) (event.getRawY() - startTouch[1]);
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved[0] = true;
                    if (moved[0]) {
                        overlayParams.x = startPos[0] + dx;
                        overlayParams.y = startPos[1] + dy;
                        try { windowManager.updateViewLayout(overlay, overlayParams); }
                        catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) setExpanded(!expanded);
                    return true;
            }
            return true;
        });
    }

    private void setExpanded(boolean value) {
        expanded = value;
        if (expandedPanel != null) expandedPanel.setVisibility(value ? View.VISIBLE : View.GONE);
        if (overlay != null && overlayParams != null) {
            overlay.requestLayout();
            try { windowManager.updateViewLayout(overlay, overlayParams); }
            catch (Exception ignored) {}
        }
    }

    private TextView makeCircleButton(String label, int color, int sizeDp) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(0xFFFFFFFF);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER);
        view.setPadding(0, 0, 0, 0);
        view.setMinWidth(0);
        view.setMinHeight(0);
        view.setIncludeFontPadding(false);
        view.setBackground(circleBg(color));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        lp.setMargins(dp(2), 0, dp(2), 0);
        view.setLayoutParams(lp);
        return view;
    }

    private GradientDrawable circleBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setShape(GradientDrawable.OVAL);
        return bg;
    }

    private GradientDrawable roundBg(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        return bg;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateStatus(String state, String diagnostic) {
        main.post(() -> {
            if (toggleButton != null) {
                boolean running = active || engineTaskRunning;
                toggleButton.setText(running ? "Ⅱ" : "▶");
                String taskName = MODE_MUSIC.equals(selectedMode) ? "音游辅助" : "游戏挂机";
                toggleButton.setContentDescription(running ? "暂停" + taskName : "启动" + taskName);
                toggleButton.setBackground(circleBg(running ? 0xFFB83232 : 0xFF238B50));
            }
            updateDot();
            if (statusText != null) statusText.setText(state + "\n" + diagnostic);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(state + " · " + diagnostic));
        });
    }

    private void updateDot() {
        if (miniDot != null) miniDot.setTextColor(active || engineTaskRunning ? 0xFF35D06F : 0xFF9E9E9E);
    }

    private void finishClose() {
        removeOverlayNow();
        stopForeground(true);
        stopSelf();
    }

    private void removeOverlayNow() {
        if (overlay != null) {
            try { windowManager.removeView(overlay); }
            catch (Exception ignored) {}
        }
        overlay = null;
        expandedPanel = null;
        miniDot = null;
        toggleButton = null;
        statusText = null;
    }

    private Notification buildNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("RedFinger GameBot · " + (MODE_MUSIC.equals(selectedMode) ? "音游辅助" : "游戏挂机"))
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "挂机控制面板", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        active = false;
        removeOverlayNow();
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
