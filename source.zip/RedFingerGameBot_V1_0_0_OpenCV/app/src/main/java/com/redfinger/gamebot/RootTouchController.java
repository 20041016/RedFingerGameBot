package com.redfinger.gamebot;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Root-only type-B multitouch injector using sendevent. Device support must be verified per handset. */
public final class RootTouchController implements AutoCloseable {
    private static final String TAG = "RFG-Touch";
    private static final int EV_SYN = 0, EV_KEY = 1, EV_ABS = 3;
    private static final int SYN_REPORT = 0, BTN_TOOL_FINGER = 325, BTN_TOUCH = 330;
    private static final int ABS_MT_SLOT = 0x2f;
    private static final int ABS_MT_POSITION_X = 0x35, ABS_MT_POSITION_Y = 0x36;
    private static final int ABS_MT_TRACKING_ID = 0x39;
    private static final Pattern DEVICE = Pattern.compile("add device \\d+: (\\S+)");
    // getevent -lp output varies by Android build: some print numeric codes (0035),
    // others print symbolic names (ABS_MT_POSITION_X). Accept both formats.
    private static final Pattern ABS_LINE = Pattern.compile(
            "(0035|0036|002f|0039|ABS_MT_POSITION_X|ABS_MT_POSITION_Y|ABS_MT_SLOT|ABS_MT_TRACKING_ID)\\s*:\\s*value\\s+(-?\\d+),\\s*min\\s+(-?\\d+),\\s*max\\s+(-?\\d+)",
            Pattern.CASE_INSENSITIVE);

    private final String suPath;
    private final int logicalWidth, logicalHeight;
    private String eventPath;
    private int minX, maxX, minY, maxY, maxSlot = 9;
    private Process shell;
    private OutputStream shellIn;
    private int nextTrackingId = 100;
    private final int[] trackingIds = new int[10];

    public RootTouchController(String suPath, int logicalWidth, int logicalHeight) {
        this.suPath = suPath;
        this.logicalWidth = logicalWidth;
        this.logicalHeight = logicalHeight;
        for (int i = 0; i < trackingIds.length; i++) trackingIds[i] = -1;
    }

    public synchronized String initialize() throws Exception {
        String listing = run("getevent -lp");
        parseDevice(listing);
        shell = new ProcessBuilder(suPath).redirectErrorStream(true).start();
        shellIn = shell.getOutputStream();
        // Drain shell output so a rejected sendevent cannot fill the pipe.
        Thread drain = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(shell.getInputStream()))) {
                while (r.readLine() != null) { /* drain */ }
            } catch (Exception ignored) {}
        }, "rfg-root-touch-output");
        drain.setDaemon(true);
        drain.start();
        write("id");
        return eventPath + " X[" + minX + "," + maxX + "] Y[" + minY + "," + maxY + "] slots=" + (maxSlot + 1);
    }

    private void parseDevice(String listing) {
        String current = null;
        boolean hasX = false, hasY = false, hasSlot = false, hasTracking = false;
        int lx = 0, hx = 0, ly = 0, hy = 0, slots = 9;
        String[] lines = listing.split("\\r?\\n");
        for (String line : lines) {
            Matcher dm = DEVICE.matcher(line.trim());
            if (dm.find()) {
                if (current != null && hasX && hasY && hasSlot && hasTracking && slots >= 5) {
                    eventPath = current; minX = lx; maxX = hx; minY = ly; maxY = hy; maxSlot = slots;
                    return;
                }
                current = dm.group(1);
                hasX = hasY = hasSlot = hasTracking = false;
                continue;
            }
            Matcher am = ABS_LINE.matcher(line.trim());
            if (!am.find()) continue;
            String code = am.group(1).toUpperCase(Locale.ROOT);
            int min = Integer.parseInt(am.group(3)), max = Integer.parseInt(am.group(4));
            if ("0035".equals(code) || "ABS_MT_POSITION_X".equals(code)) { hasX = true; lx = min; hx = max; }
            else if ("0036".equals(code) || "ABS_MT_POSITION_Y".equals(code)) { hasY = true; ly = min; hy = max; }
            else if ("002F".equals(code) || "ABS_MT_SLOT".equals(code)) { hasSlot = true; slots = Math.max(0, max); }
            else if ("0039".equals(code) || "ABS_MT_TRACKING_ID".equals(code)) hasTracking = true;
        }
        if (current != null && hasX && hasY && hasSlot && hasTracking && slots >= 5) {
            eventPath = current; minX = lx; maxX = hx; minY = ly; maxY = hy; maxSlot = slots; return;
        }
        String preview = listing == null ? "(getevent 无输出)" : listing.trim();
        if (preview.length() > 1800) preview = preview.substring(0, 1800) + "\n...(已截断)";
        throw new IllegalStateException("未找到支持 Type-B 多点触控的设备节点。\n已尝试解析 getevent -lp，但当前格式或能力字段未匹配。\n输出片段：\n" + preview);
    }

    public synchronized void down(int x, int y, int pointerId) throws Exception {
        ensureReady(pointerId);
        int rawX = scale(x, logicalWidth, minX, maxX);
        int rawY = scale(y, logicalHeight, minY, maxY);
        boolean firstFinger = activeCount() == 0 && trackingIds[pointerId] < 0;
        if (trackingIds[pointerId] < 0) {
            trackingIds[pointerId] = nextTrackingId;
            nextTrackingId = nextTrackingId >= 65535 ? 1 : nextTrackingId + 1;
        }
        StringBuilder batch = new StringBuilder(192);
        appendAbs(batch, ABS_MT_SLOT, pointerId);
        appendAbs(batch, ABS_MT_TRACKING_ID, trackingIds[pointerId]);
        appendAbs(batch, ABS_MT_POSITION_X, rawX);
        appendAbs(batch, ABS_MT_POSITION_Y, rawY);
        if (firstFinger) {
            appendKey(batch, BTN_TOUCH, 1);
            appendKey(batch, BTN_TOOL_FINGER, 1);
        }
        appendSync(batch);
        writeBatch(batch);
    }

    public synchronized void up(int pointerId) throws Exception {
        ensureReady(pointerId);
        if (trackingIds[pointerId] < 0) return;
        StringBuilder batch = new StringBuilder(128);
        appendAbs(batch, ABS_MT_SLOT, pointerId);
        appendAbs(batch, ABS_MT_TRACKING_ID, -1);
        if (activeCount() == 1) {
            // Global touch state is cleared only when the final finger is released.
            appendKey(batch, BTN_TOUCH, 0);
            appendKey(batch, BTN_TOOL_FINGER, 0);
        }
        appendSync(batch);
        writeBatch(batch);
        trackingIds[pointerId] = -1;
    }

    public synchronized void releaseAll() {
        if (shell == null || shellIn == null) return;
        boolean hadTouches = activeCount() > 0;
        try {
            StringBuilder batch = new StringBuilder(512);
            for (int i = 0; i < trackingIds.length; i++) {
                if (trackingIds[i] >= 0) {
                    appendAbs(batch, ABS_MT_SLOT, i);
                    appendAbs(batch, ABS_MT_TRACKING_ID, -1);
                    trackingIds[i] = -1;
                }
            }
            if (hadTouches) {
                appendKey(batch, BTN_TOUCH, 0);
                appendKey(batch, BTN_TOOL_FINGER, 0);
                appendSync(batch);
            }
            if (batch.length() > 0) writeBatch(batch);
        } catch (Exception e) {
            Log.w(TAG, "释放触点失败", e);
        }
    }

    private int activeCount() {
        int count = 0;
        for (int trackingId : trackingIds) if (trackingId >= 0) count++;
        return count;
    }

    private int scale(int value, int logicalSize, int min, int max) {
        int clamped = Math.max(0, Math.min(logicalSize - 1, value));
        return min + Math.round((max - min) * (clamped / (float) Math.max(1, logicalSize - 1)));
    }

    private void ensureReady(int pointerId) {
        if (shell == null || !shellAlive()) throw new IllegalStateException("Root 多点触控会话未初始化或已退出");
        if (pointerId < 0 || pointerId > maxSlot || pointerId >= trackingIds.length)
            throw new IllegalArgumentException("触点 ID 超出设备支持范围：" + pointerId);
    }

    private boolean shellAlive() {
        try { shell.exitValue(); return false; }
        catch (IllegalThreadStateException stillRunning) { return true; }
    }

    private void appendAbs(StringBuilder batch, int code, int value) {
        batch.append("sendevent ").append(eventPath).append(' ').append(EV_ABS).append(' ')
                .append(code).append(' ').append(value).append('\n');
    }
    private void appendKey(StringBuilder batch, int code, int value) {
        batch.append("sendevent ").append(eventPath).append(' ').append(EV_KEY).append(' ')
                .append(code).append(' ').append(value).append('\n');
    }
    private void appendSync(StringBuilder batch) {
        batch.append("sendevent ").append(eventPath).append(' ').append(EV_SYN).append(' ')
                .append(SYN_REPORT).append(" 0\n");
    }
    private void writeBatch(StringBuilder batch) throws Exception {
        shellIn.write(batch.toString().getBytes("UTF-8"));
        shellIn.flush();
    }
    private void write(String command) throws Exception {
        shellIn.write((command + "\n").getBytes("UTF-8"));
        shellIn.flush();
    }

    private String run(String command) throws Exception {
        Process p = new ProcessBuilder(suPath, "-c", command).redirectErrorStream(true).start();
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line; while ((line = r.readLine()) != null) b.append(line).append('\n');
        }
        int code = p.waitFor();
        if (code != 0) throw new IllegalStateException("Root 命令失败：" + b);
        return b.toString();
    }

    @Override public synchronized void close() {
        releaseAll();
        if (shellIn != null) try { shellIn.write("exit\n".getBytes("UTF-8")); shellIn.flush(); } catch (Exception ignored) {}
        if (shell != null) shell.destroy();
        shell = null; shellIn = null;
    }
}
