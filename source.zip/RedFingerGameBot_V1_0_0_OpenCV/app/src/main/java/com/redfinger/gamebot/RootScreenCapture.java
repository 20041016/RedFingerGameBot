package com.redfinger.gamebot;

import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

import java.nio.ByteBuffer;

/** MediaProjection + ImageReader continuous frame capture. No per-frame shell or PNG work. */
final class RootScreenCapture implements AutoCloseable {
    private static final String TAG = "RFG-ScreenCapture";
    // Keep the existing half-resolution stream and coordinate mapping unchanged.
    static final int STREAM_WIDTH = 1600;
    static final int STREAM_HEIGHT = 720;

    private final Object frameLock = new Object();
    private final MediaProjection projection;
    private final int densityDpi;
    private HandlerThread imageThread;
    private Handler imageHandler;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private Image pendingImage;
    private long frameSerial;
    private long consumedSerial;
    private volatile boolean projectionStopped;
    private byte[] rgbaBuffer = new byte[STREAM_WIDTH * STREAM_HEIGHT * 4];

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            projectionStopped = true;
            synchronized (frameLock) { frameLock.notifyAll(); }
        }
    };

    RootScreenCapture(MediaProjection projection, int densityDpi) {
        if (projection == null) throw new IllegalArgumentException("缺少屏幕录制授权");
        this.projection = projection;
        this.densityDpi = Math.max(1, densityDpi);
    }

    synchronized RawFrame captureRaw() throws Exception {
        ensureStream();
        Image image;
        synchronized (frameLock) {
            long deadline = android.os.SystemClock.elapsedRealtime() + 700;
            while (frameSerial <= consumedSerial && !projectionStopped) {
                long remain = deadline - android.os.SystemClock.elapsedRealtime();
                if (remain <= 0) throw new IllegalStateException("等待 MediaProjection 新画面超时");
                frameLock.wait(remain);
            }
            if (projectionStopped) throw new IllegalStateException("系统屏幕录制已停止，请重新启动音游并授予屏幕录制权限");
            image = pendingImage;
            pendingImage = null;
            consumedSerial = frameSerial;
        }
        if (image == null) throw new IllegalStateException("MediaProjection 未提供有效画面");
        try {
            copyRgba(image, rgbaBuffer);
            return new RawFrame(STREAM_WIDTH, STREAM_HEIGHT, rgbaBuffer, image.getTimestamp());
        } finally {
            image.close();
        }
    }

    private void ensureStream() {
        if (virtualDisplay != null) return;
        imageThread = new HandlerThread("rfg-mediaprojection-frames", android.os.Process.THREAD_PRIORITY_DISPLAY);
        imageThread.start();
        imageHandler = new Handler(imageThread.getLooper());
        imageReader = ImageReader.newInstance(STREAM_WIDTH, STREAM_HEIGHT,
                android.graphics.PixelFormat.RGBA_8888, 3);
        imageReader.setOnImageAvailableListener(reader -> {
            Image latest = null;
            try { latest = reader.acquireLatestImage(); }
            catch (IllegalStateException e) { Log.w(TAG, "acquireLatestImage failed", e); }
            synchronized (frameLock) {
                if (latest != null) {
                    if (pendingImage != null) pendingImage.close();
                    pendingImage = latest;
                    frameSerial++;
                }
                frameLock.notifyAll();
            }
        }, imageHandler);
        projection.registerCallback(projectionCallback, imageHandler);
        virtualDisplay = projection.createVirtualDisplay("RedFingerMusicCapture",
                STREAM_WIDTH, STREAM_HEIGHT, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, imageHandler);
        if (virtualDisplay == null) throw new IllegalStateException("创建屏幕采集 VirtualDisplay 失败");
        Log.i(TAG, "MediaProjection ImageReader started: " + STREAM_WIDTH + "x" + STREAM_HEIGHT);
    }

    private static void copyRgba(Image image, byte[] out) {
        if (image.getWidth() != STREAM_WIDTH || image.getHeight() != STREAM_HEIGHT)
            throw new IllegalStateException("屏幕帧尺寸异常：" + image.getWidth() + "x" + image.getHeight());
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer src = plane.getBuffer().duplicate();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int base = src.position();
        int rowBytes = STREAM_WIDTH * 4;
        if (pixelStride == 4 && rowStride == rowBytes && src.remaining() >= out.length) {
            src.get(out, 0, out.length);
            return;
        }
        int required = (STREAM_HEIGHT - 1) * rowStride + (STREAM_WIDTH - 1) * pixelStride + 4;
        if (src.limit() - base < required) throw new IllegalStateException("屏幕帧缓冲区长度不足");
        byte[] row = new byte[rowStride];
        int dst = 0;
        for (int y = 0; y < STREAM_HEIGHT; y++) {
            src.position(base + y * rowStride);
            src.get(row, 0, rowStride);
            for (int x = 0; x < STREAM_WIDTH; x++) {
                int p = x * pixelStride;
                out[dst++] = row[p];
                out[dst++] = row[p + 1];
                out[dst++] = row[p + 2];
                out[dst++] = row[p + 3];
            }
        }
    }

    @Override public synchronized void close() {
        synchronized (frameLock) {
            if (pendingImage != null) { pendingImage.close(); pendingImage = null; }
            frameLock.notifyAll();
        }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        if (projection != null) {
            try { projection.unregisterCallback(projectionCallback); } catch (Exception ignored) { }
        }
        if (imageThread != null) { imageThread.quitSafely(); imageThread = null; }
        imageHandler = null;
    }

    static final class RawFrame {
        final int width, height;
        final byte[] rgba;
        final long timestampNs;
        RawFrame(int width, int height, byte[] rgba, long timestampNs) {
            this.width = width; this.height = height; this.rgba = rgba; this.timestampNs = timestampNs;
        }
    }
}
