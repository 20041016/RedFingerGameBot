package com.redfinger.gamebot;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Persistent Root shell for PNG frames. No MediaProjection, accessibility, or temp PNG files. */
final class RootScreenCapture implements AutoCloseable {
    private static final String TAG = "RFG-ScreenCapture";
    private static final byte[] PNG_SIGNATURE = new byte[] {
            (byte) 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a
    };
    private static final byte[] END_MARKER = "\n__RFG_CAPTURE_DONE__\n".getBytes(StandardCharsets.US_ASCII);
    private static final int MAX_PNG_BYTES = 48 * 1024 * 1024;

    private final String suPath;
    private Process shell;
    private BufferedInputStream stdout;
    private OutputStream stdin;

    RootScreenCapture(String suPath) {
        this.suPath = suPath;
    }

    synchronized byte[] capturePng() throws Exception {
        ensureShell();
        stdin.write("screencap -p; printf '\\n__RFG_CAPTURE_DONE__\\n'\n".getBytes(StandardCharsets.US_ASCII));
        stdin.flush();

        ByteArrayOutputStream png = new ByteArrayOutputStream(1024 * 1024);
        byte[] signature = new byte[PNG_SIGNATURE.length];
        readFully(stdout, signature);
        if (!equalsBytes(signature, PNG_SIGNATURE)) {
            close(); // discard the desynchronized shell stream before the next attempt
            throw new IllegalStateException("Root screencap 未返回有效 PNG 数据");
        }
        png.write(signature);

        boolean ended = false;
        while (!ended) {
            byte[] chunkHeader = new byte[8];
            readFully(stdout, chunkHeader);
            long length = ((long) (chunkHeader[0] & 0xff) << 24)
                    | ((long) (chunkHeader[1] & 0xff) << 16)
                    | ((long) (chunkHeader[2] & 0xff) << 8)
                    | (long) (chunkHeader[3] & 0xff);
            if (length > MAX_PNG_BYTES || png.size() + length + 12L > MAX_PNG_BYTES) {
                close();
                throw new IllegalStateException("截图 PNG 数据异常过大：" + length);
            }
            png.write(chunkHeader);
            copyExactly(stdout, png, (int) length + 4); // chunk data + CRC
            ended = chunkHeader[4] == 'I' && chunkHeader[5] == 'E'
                    && chunkHeader[6] == 'N' && chunkHeader[7] == 'D';
        }
        consumeEndMarker();
        return png.toByteArray();
    }

    private void ensureShell() throws Exception {
        if (shell != null) {
            try { shell.exitValue(); }
            catch (IllegalThreadStateException alive) { return; }
            close();
        }
        shell = new ProcessBuilder(suPath).redirectErrorStream(false).start();
        stdout = new BufferedInputStream(shell.getInputStream(), 64 * 1024);
        stdin = new BufferedOutputStream(shell.getOutputStream(), 8 * 1024);
        Process processForDrain = shell;
        Thread stderrDrainer = new Thread(() -> {
            try (InputStream err = processForDrain.getErrorStream()) {
                byte[] buffer = new byte[2048];
                while (err.read(buffer) >= 0) { /* drain root shell diagnostics */ }
            } catch (Exception e) {
                Log.d(TAG, "stderr drain ended", e);
            }
        }, "rfg-screencap-stderr");
        stderrDrainer.setDaemon(true);
        stderrDrainer.start();
    }

    private void consumeEndMarker() throws Exception {
        byte[] window = new byte[END_MARKER.length];
        int count = 0;
        while (true) {
            int value = stdout.read();
            if (value < 0) throw new IllegalStateException("Root 截图会话提前结束");
            if (count < window.length) {
                window[count++] = (byte) value;
            } else {
                System.arraycopy(window, 1, window, 0, window.length - 1);
                window[window.length - 1] = (byte) value;
            }
            if (count == window.length && equalsBytes(window, END_MARKER)) return;
        }
    }

    private static void readFully(InputStream in, byte[] data) throws Exception {
        int offset = 0;
        while (offset < data.length) {
            int n = in.read(data, offset, data.length - offset);
            if (n < 0) throw new IllegalStateException("Root 截图数据不完整");
            offset += n;
        }
    }

    private static void copyExactly(InputStream in, ByteArrayOutputStream out, int length) throws Exception {
        byte[] buffer = new byte[16 * 1024];
        int remaining = length;
        while (remaining > 0) {
            int n = in.read(buffer, 0, Math.min(buffer.length, remaining));
            if (n < 0) throw new IllegalStateException("Root PNG 图像块数据不完整");
            out.write(buffer, 0, n);
            remaining -= n;
        }
    }

    private static boolean equalsBytes(byte[] a, byte[] b) {
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++) if (a[i] != b[i]) return false;
        return true;
    }

    @Override public synchronized void close() {
        if (stdin != null) {
            try { stdin.write("exit\n".getBytes(StandardCharsets.US_ASCII)); stdin.flush(); }
            catch (Exception ignored) {}
        }
        if (shell != null) shell.destroy();
        shell = null;
        stdout = null;
        stdin = null;
    }
}
