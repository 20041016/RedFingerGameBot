package com.redfinger.gamebot;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/** Persistent Root shell that streams raw RGBA screencap frames (no PNG encode or temp files). */
final class RootScreenCapture implements AutoCloseable {
    private static final String TAG = "RFG-ScreenCapture";
    private static final byte[] END_MARKER = "\n__RFG_RAW_DONE__\n".getBytes(StandardCharsets.US_ASCII);
    private static final long MAX_FRAME_BYTES = 64L * 1024L * 1024L;

    private final String suPath;
    private Process shell;
    private BufferedInputStream stdout;
    private OutputStream stdin;

    RootScreenCapture(String suPath) { this.suPath = suPath; }

    synchronized RawFrame captureRaw() throws Exception {
        ensureShell();
        // Without -p Android screencap writes a 3x uint32 header followed by raw pixels.
        stdin.write("screencap; printf '\\n__RFG_RAW_DONE__\\n'\n".getBytes(StandardCharsets.US_ASCII));
        stdin.flush();

        byte[] header = new byte[16];
        readFully(stdout, header);
        ByteBuffer h = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
        int width = h.getInt();
        int height = h.getInt();
        int format = h.getInt();
        int dataspace = h.getInt(); // reserved/color-space word emitted by current Android screencap
        if (width <= 0 || height <= 0 || (long) width * height * 4L > MAX_FRAME_BYTES
                || (format != 1 && format != 2)) {
            close();
            throw new IllegalStateException("Root 原始截图格式不受支持：" + width + "x" + height
                    + " format=" + format + "（需要 RGBA_8888/RGBX_8888）");
        }
        int byteCount = Math.multiplyExact(Math.multiplyExact(width, height), 4);
        byte[] pixels = new byte[byteCount];
        readFully(stdout, pixels);
        consumeEndMarker();
        return new RawFrame(width, height, format, dataspace, pixels);
    }

    private void ensureShell() throws Exception {
        if (shell != null) {
            try { shell.exitValue(); }
            catch (IllegalThreadStateException alive) { return; }
            close();
        }
        shell = new ProcessBuilder(suPath).redirectErrorStream(false).start();
        stdout = new BufferedInputStream(shell.getInputStream(), 256 * 1024);
        stdin = new BufferedOutputStream(shell.getOutputStream(), 8 * 1024);
        Process processForDrain = shell;
        Thread stderrDrainer = new Thread(() -> {
            try (InputStream err = processForDrain.getErrorStream()) {
                byte[] buffer = new byte[2048];
                while (err.read(buffer) >= 0) { /* drain diagnostics */ }
            } catch (Exception e) { Log.d(TAG, "stderr drain ended", e); }
        }, "rfg-screencap-stderr");
        stderrDrainer.setDaemon(true);
        stderrDrainer.start();
    }

    private void consumeEndMarker() throws Exception {
        byte[] window = new byte[END_MARKER.length];
        int count = 0;
        while (true) {
            int value = stdout.read();
            if (value < 0) throw new IllegalStateException("Root 原始截图会话提前结束");
            if (count < window.length) window[count++] = (byte) value;
            else {
                System.arraycopy(window, 1, window, 0, window.length - 1);
                window[window.length - 1] = (byte) value;
            }
            if (count == window.length && equalsBytes(window, END_MARKER)) return;
        }
    }

    private static void readFully(InputStream in, byte[] data) throws Exception {
        int offset = 0;
        while (offset < data.length) {
            int n = in.read(data, offset, data.length - offset);
            if (n < 0) throw new IllegalStateException("Root 原始截图数据不完整：" + offset + "/" + data.length);
            offset += n;
        }
    }

    private static boolean equalsBytes(byte[] a, byte[] b) {
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++) if (a[i] != b[i]) return false;
        return true;
    }

    @Override public synchronized void close() {
        if (stdin != null) {
            try { stdin.write("exit\n".getBytes(StandardCharsets.US_ASCII)); stdin.flush(); }
            catch (Exception ignored) { }
        }
        if (shell != null) shell.destroy();
        shell = null; stdout = null; stdin = null;
    }

    static final class RawFrame {
        final int width, height, format, dataspace;
        final byte[] rgba;
        RawFrame(int width, int height, int format, int dataspace, byte[] rgba) {
            this.width = width; this.height = height; this.format = format; this.dataspace = dataspace; this.rgba = rgba;
        }
    }
}
