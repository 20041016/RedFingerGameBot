package com.redfinger.gamebot;

import android.util.Log;

import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.List;

/** Samples the six lane points from streamed RGB888 frames. */
final class OpenCvFrameProcessor {
    private static final String TAG = "RFG-OpenCV";
    private static volatile boolean loaded;
    private Mat rgbFrame;
    private int allocatedWidth, allocatedHeight;

    static synchronized void ensureLoaded() {
        if (loaded) return;
        if (!OpenCVLoader.initLocal()) {
            throw new IllegalStateException("OpenCV 原生库加载失败，请检查 APK 是否包含当前 CPU 架构的 so 文件");
        }
        loaded = true;
        Log.i(TAG, "OpenCV native library loaded");
    }

    synchronized Sample sampleBlue(RootScreenCapture.RawFrame frame, int[] xs, int y) {
        ensureLoaded();
        if (y < 0 || y >= frame.height) {
            throw new IllegalArgumentException("检测 Y 坐标超出截图范围：" + y + "，截图高度=" + frame.height);
        }
        if (rgbFrame == null || allocatedWidth != frame.width || allocatedHeight != frame.height) {
            if (rgbFrame != null) rgbFrame.release();
            rgbFrame = new Mat(frame.height, frame.width, CvType.CV_8UC3);
            allocatedWidth = frame.width;
            allocatedHeight = frame.height;
        }
        long start = android.os.SystemClock.elapsedRealtimeNanos();
        int copied = rgbFrame.put(0, 0, frame.rgb);
        long uploadMs = (android.os.SystemClock.elapsedRealtimeNanos() - start) / 1_000_000L;
        if (copied < frame.rgb.length) {
            throw new IllegalStateException("OpenCV RGB 帧写入不完整：" + copied + "/" + frame.rgb.length);
        }
        int[] blue = new int[xs.length];
        byte[] rgb = new byte[3];
        for (int i = 0; i < xs.length; i++) {
            int x = xs[i];
            if (x < 0 || x >= frame.width) {
                throw new IllegalArgumentException("检测 X 坐标超出截图范围：" + x + "，截图宽度=" + frame.width);
            }
            if (rgbFrame.get(y, x, rgb) < 3) {
                throw new IllegalStateException("OpenCV 读取像素失败：(" + x + "," + y + ")");
            }
            // AOSP FrameOutput reduces RGBA to packed RGB888.
            blue[i] = rgb[2] & 0xff;
        }
        return new Sample(frame.width, frame.height, blue, uploadMs);
    }

    // Tap-note head signature (RGB). Hold-note heads are paired with their orange vertical body.
    private static final Scalar NOTE_LO = new Scalar(238, 226, 120);
    private static final Scalar NOTE_HI = new Scalar(255, 255, 185);

    /**
     * Detect tap and hold notes in each lane. Output tuples are
     * [lane, headY, tailY, type], where type=0 is tap (tailY=-1), type=1 is hold.
     * Coordinates are in streamed-frame pixels; RootHost scales them back to source space.
     */
    synchronized int[] detectMusicNotes(int[] laneXs, int halfWidth, int top, int bottom) {
        if (rgbFrame == null) return new int[0];
        final int w = allocatedWidth, h = allocatedHeight;
        top = Math.max(0, Math.min(h - 2, top));
        bottom = Math.max(top + 1, Math.min(h, bottom));
        List<Integer> out = new ArrayList<>();
        Mat hsv = new Mat();
        Imgproc.cvtColor(rgbFrame, hsv, Imgproc.COLOR_RGB2HSV);
        try {
            for (int lane = 0; lane < laneXs.length; lane++) {
                int x0 = Math.max(0, laneXs[lane] - halfWidth);
                int x1 = Math.min(w, laneXs[lane] + halfWidth);
                if (x1 - x0 < 4) continue;
                Mat strip = rgbFrame.submat(top, bottom, x0, x1);
                Mat hsvStrip = hsv.submat(top, bottom, x0, x1);
                Mat yellow = new Mat();
                Mat orange = new Mat();
                Mat yellowRows = new Mat();
                Mat orangeRows = new Mat();
                try {
                    Core.inRange(strip, NOTE_LO, NOTE_HI, yellow);
                    // A strong orange core finds the straight body; a broader mask follows its
                    // faded ends. The separate head-colour check rejects red overlay buttons and
                    // warm background decorations which otherwise resemble vertical bars.
                    Core.inRange(hsvStrip, new Scalar(0, 70, 90), new Scalar(22, 255, 255), orange);
                    Mat strongOrange = new Mat();
                    Mat strongRows = new Mat();
                    try {
                        Core.inRange(hsvStrip, new Scalar(0, 130, 120), new Scalar(22, 255, 255), strongOrange);
                        Core.reduce(yellow, yellowRows, 1, Core.REDUCE_SUM, CvType.CV_32S);
                        Core.reduce(orange, orangeRows, 1, Core.REDUCE_SUM, CvType.CV_32S);
                        Core.reduce(strongOrange, strongRows, 1, Core.REDUCE_SUM, CvType.CV_32S);
                        int[] ySums = new int[yellowRows.rows()];
                        int[] oSums = new int[orangeRows.rows()];
                        int[] strongSums = new int[strongRows.rows()];
                        yellowRows.get(0, 0, ySums);
                        orangeRows.get(0, 0, oSums);
                        strongRows.get(0, 0, strongSums);

                        List<int[]> heads = collectRuns(ySums, 6 * 255, 8);
                        List<int[]> bars = collectRuns(strongSums, 8 * 255, 10);
                        boolean[] headUsed = new boolean[heads.size()];
                        for (int[] bar : bars) {
                            int headY = top + bar[1] + 50; // stream-space offset to flower centre
                            if (headY >= bottom) continue;
                            int headRow = headY - top;
                            int from = Math.max(0, headRow - 18);
                            int to = Math.min(oSums.length - 1, headRow + 18);
                            int headPixels = 0, headRows = 0, headShapeRows = 0;
                            for (int r = from; r <= to; r++) {
                                int rowPixels = oSums[r] / 255;
                                headPixels += rowPixels;
                                if (rowPixels >= 4) headRows++;
                                // A real flower head narrows at its upper/lower edges. A flat,
                                // full-width bar continuing below a false candidate does not.
                                if (rowPixels >= 4 && rowPixels <= (x1 - x0 - 5)) headShapeRows++;
                            }
                            if (headPixels < 80 || headRows < 5 || headShapeRows < 4) continue;

                            // Extend the strong core to the faded top edge. If an overlay hides
                            // the real tail, this edge will remain stationary until it emerges;
                            // Python tracking validates tail motion before scheduling release.
                            int tailRow = bar[0];
                            while (tailRow > 0 && oSums[tailRow - 1] >= 5 * 255) tailRow--;
                            int tailY = top + tailRow;
                            int best = -1;
                            int bestDistance = Integer.MAX_VALUE;
                            for (int i = 0; i < heads.size(); i++) {
                                if (headUsed[i]) continue;
                                int center = top + (heads.get(i)[0] + heads.get(i)[1]) / 2;
                                int d = Math.abs(center - headY);
                                if (d < bestDistance && d <= 90) { best = i; bestDistance = d; }
                            }
                            if (best >= 0) {
                                headUsed[best] = true;
                                headY = top + (heads.get(best)[0] + heads.get(best)[1]) / 2;
                            }
                            out.add(lane); out.add(headY); out.add(tailY); out.add(1);
                        }
                        for (int i = 0; i < heads.size(); i++) {
                            if (headUsed[i]) continue;
                            int headY = top + (heads.get(i)[0] + heads.get(i)[1]) / 2;
                            out.add(lane); out.add(headY); out.add(-1); out.add(0);
                        }
                    } finally {
                        strongOrange.release(); strongRows.release();
                    }
                } finally {
                    strip.release(); hsvStrip.release(); yellow.release(); orange.release();
                    yellowRows.release(); orangeRows.release();
                }
            }
        } finally {
            hsv.release();
        }
        int[] flat = new int[out.size()];
        for (int i = 0; i < flat.length; i++) flat[i] = out.get(i);
        return flat;
    }

    private static List<int[]> collectRuns(int[] sums, int minSum, int minRun) {
        List<int[]> runs = new ArrayList<>();
        for (int y = 0; y < sums.length; ) {
            if (sums[y] >= minSum) {
                int start = y;
                while (y < sums.length && sums[y] >= minSum) y++;
                if (y - start >= minRun) runs.add(new int[]{start, y - 1});
            } else y++;
        }
        return runs;
    }

    synchronized void release() {
        if (rgbFrame != null) { rgbFrame.release(); rgbFrame = null; }
        allocatedWidth = allocatedHeight = 0;
    }

    static final class Sample {
        final int width, height;
        final int[] blue;
        final long decodeMs;
        Sample(int width, int height, int[] blue, long decodeMs) {
            this.width = width; this.height = height; this.blue = blue; this.decodeMs = decodeMs;
        }
    }
}
