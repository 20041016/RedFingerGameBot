package com.redfinger.gamebot;

import android.util.Log;

import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;


/** Samples the six lane points from streamed RGB888 frames. */
final class OpenCvFrameProcessor {
    private static final String TAG = "RFG-OpenCV";
    private static volatile boolean loaded;
    private Mat rgbFrame;
    private int allocatedWidth, allocatedHeight;

    static synchronized void ensureLoaded() {
        if (loaded) return;
        if (!OpenCVLoader.initLocal()) {
            throw new IllegalStateException("OpenCV 原生库加载失败，请检查 APK 是否包含当前 CPU 架构的 so 文件");
        }
        loaded = true;
        Log.i(TAG, "OpenCV native library loaded");
    }

    synchronized Sample sampleBlue(RootScreenCapture.RawFrame frame, int[] xs, int y) {
        ensureLoaded();
        if (y < 0 || y >= frame.height) {
            throw new IllegalArgumentException("检测 Y 坐标超出截图范围：" + y + "，截图高度=" + frame.height);
        }
        if (rgbFrame == null || allocatedWidth != frame.width || allocatedHeight != frame.height) {
            if (rgbFrame != null) rgbFrame.release();
            rgbFrame = new Mat(frame.height, frame.width, CvType.CV_8UC3);
            allocatedWidth = frame.width;
            allocatedHeight = frame.height;
        }
        long start = android.os.SystemClock.elapsedRealtimeNanos();
        int copied = rgbFrame.put(0, 0, frame.rgb);
        long uploadMs = (android.os.SystemClock.elapsedRealtimeNanos() - start) / 1_000_000L;
        if (copied < frame.rgb.length) {
            throw new IllegalStateException("OpenCV RGB 帧写入不完整：" + copied + "/" + frame.rgb.length);
        }
        int[] blue = new int[xs.length];
        byte[] rgb = new byte[3];
        for (int i = 0; i < xs.length; i++) {
            int x = xs[i];
            if (x < 0 || x >= frame.width) {
                throw new IllegalArgumentException("检测 X 坐标超出截图范围：" + x + "，截图宽度=" + frame.width);
            }
            if (rgbFrame.get(y, x, rgb) < 3) {
                throw new IllegalStateException("OpenCV 读取像素失败：(" + x + "," + y + ")");
            }
            // AOSP FrameOutput reduces RGBA to packed RGB888.
            blue[i] = rgb[2] & 0xff;
        }
        return new Sample(frame.width, frame.height, blue, uploadMs);
    }

    // Pale-yellow note-centre signature measured from the game's screenshots (RGB order).
    // Background oranges, judge circles, hit effects and text never satisfy all three bounds.
    private static final Scalar NOTE_LO = new Scalar(238, 226, 120);
    private static final Scalar NOTE_HI = new Scalar(255, 255, 185);

    /**
     * Find note centres inside each lane's vertical strip of the frame last passed to sampleBlue().
     * All arguments are in the streamed frame's pixel space. Returns a flat array
     * [lane, centreY, runLength, lane, centreY, runLength, ...].
     */


    synchronized void release() {
        if (rgbFrame != null) { rgbFrame.release(); rgbFrame = null; }
        allocatedWidth = allocatedHeight = 0;
    }

    static final class Sample {
        final int width, height;
        final int[] blue;
        final long decodeMs;
        Sample(int width, int height, int[] blue, long decodeMs) {
            this.width = width; this.height = height; this.blue = blue; this.decodeMs = decodeMs;
        }
    }
}
