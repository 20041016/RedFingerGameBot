package com.redfinger.gamebot;

import android.util.Log;

import org.opencv.android.OpenCVLoader;
import org.opencv.core.CvType;
import org.opencv.core.Mat;

/** Samples the six lane points from streamed RGB888 frames. */
final class OpenCvFrameProcessor {
    private static final String TAG = "RFG-OpenCV";
    private static volatile boolean loaded;
    private Mat rgbFrame;
    private int allocatedWidth, allocatedHeight;

    static synchronized void ensureLoaded() {
        if (loaded) return;
        if (!OpenCVLoader.initLocal()) {
            throw new IllegalStateException("OpenCV 原生库加载失败，请检查 APK 是否包含当前 CPU 架构的 so 文件");
        }
        loaded = true;
        Log.i(TAG, "OpenCV native library loaded");
    }

    synchronized Sample sampleBlue(RootScreenCapture.RawFrame frame, int[] xs, int pressY, int releaseY) {
        ensureLoaded();
        if (pressY < 0 || pressY >= frame.height || releaseY < 0 || releaseY >= frame.height) {
            throw new IllegalArgumentException("提前/释放检测 Y 坐标超出截图范围：" + pressY + "/" + releaseY + "，截图高度=" + frame.height);
        }
        if (rgbFrame == null || allocatedWidth != frame.width || allocatedHeight != frame.height) {
            if (rgbFrame != null) rgbFrame.release();
            rgbFrame = new Mat(frame.height, frame.width, CvType.CV_8UC3);
            allocatedWidth = frame.width;
            allocatedHeight = frame.height;
        }
        long start = android.os.SystemClock.elapsedRealtimeNanos();
        int copied = rgbFrame.put(0, 0, frame.rgb);
        long uploadMs = (android.os.SystemClock.elapsedRealtimeNanos() - start) / 1_000_000L;
        if (copied < frame.rgb.length) {
            throw new IllegalStateException("OpenCV RGB 帧写入不完整：" + copied + "/" + frame.rgb.length);
        }
        int[] pressBlue = new int[xs.length];
        int[] releaseBlue = new int[xs.length];
        byte[] rgb = new byte[3];
        for (int i = 0; i < xs.length; i++) {
            int x = xs[i];
            if (x < 0 || x >= frame.width) {
                throw new IllegalArgumentException("检测 X 坐标超出截图范围：" + x + "，截图宽度=" + frame.width);
            }
            if (rgbFrame.get(pressY, x, rgb) < 3) {
                throw new IllegalStateException("OpenCV 提前采样失败：(" + x + "," + pressY + ")");
            }
            // AOSP FrameOutput reduces RGBA to packed RGB888.
            pressBlue[i] = rgb[2] & 0xff;
            if (rgbFrame.get(releaseY, x, rgb) < 3) {
                throw new IllegalStateException("OpenCV 释放采样失败：(" + x + "," + releaseY + ")");
            }
            releaseBlue[i] = rgb[2] & 0xff;
        }
        return new Sample(frame.width, frame.height, pressBlue, releaseBlue, uploadMs);
    }

    synchronized void release() {
        if (rgbFrame != null) { rgbFrame.release(); rgbFrame = null; }
        allocatedWidth = allocatedHeight = 0;
    }

    static final class Sample {
        final int width, height;
        final int[] pressBlue, releaseBlue;
        final long decodeMs;
        Sample(int width, int height, int[] pressBlue, int[] releaseBlue, long decodeMs) {
            this.width = width; this.height = height; this.pressBlue = pressBlue;
            this.releaseBlue = releaseBlue; this.decodeMs = decodeMs;
        }
    }
}
