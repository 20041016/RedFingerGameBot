package com.redfinger.gamebot;

import android.util.Log;

import org.opencv.android.OpenCVLoader;
import org.opencv.core.CvType;
import org.opencv.core.Mat;

/** OpenCV sampler for raw RGBA screencap frames; deliberately skips PNG/JPEG decoding. */
final class OpenCvFrameProcessor {
    private static final String TAG = "RFG-OpenCV";
    private static volatile boolean loaded;
    private Mat rgbaFrame;
    private int allocatedWidth, allocatedHeight;

    static synchronized void ensureLoaded() {
        if (loaded) return;
        if (!OpenCVLoader.initLocal()) {
            throw new IllegalStateException("OpenCV 原生库加载失败，请检查 APK 是否包含当前 CPU 架构的 so 文件");
        }
        loaded = true;
        Log.i(TAG, "OpenCV native library loaded");
    }

    synchronized Sample sampleBlue(RootScreenCapture.RawFrame frame, int[] xs, int y) {
        ensureLoaded();
        if (frame.format != 1 && frame.format != 2) {
            throw new IllegalArgumentException("不支持的原始像素格式：" + frame.format);
        }
        if (y < 0 || y >= frame.height) {
            throw new IllegalArgumentException("检测 Y 坐标超出截图范围：" + y + "，截图高度=" + frame.height);
        }
        if (rgbaFrame == null || allocatedWidth != frame.width || allocatedHeight != frame.height) {
            if (rgbaFrame != null) rgbaFrame.release();
            rgbaFrame = new Mat(frame.height, frame.width, CvType.CV_8UC4);
            allocatedWidth = frame.width;
            allocatedHeight = frame.height;
        }
        long start = android.os.SystemClock.elapsedRealtimeNanos();
        int copied = rgbaFrame.put(0, 0, frame.rgba);
        long uploadMs = (android.os.SystemClock.elapsedRealtimeNanos() - start) / 1_000_000L;
        if (copied < frame.rgba.length) {
            throw new IllegalStateException("OpenCV 原始帧写入不完整：" + copied + "/" + frame.rgba.length);
        }
        int[] blue = new int[xs.length];
        byte[] rgba = new byte[4];
        for (int i = 0; i < xs.length; i++) {
            int x = xs[i];
            if (x < 0 || x >= frame.width) {
                throw new IllegalArgumentException("检测 X 坐标超出截图范围：" + x + "，截图宽度=" + frame.width);
            }
            if (rgbaFrame.get(y, x, rgba) < 4) {
                throw new IllegalStateException("OpenCV 读取像素失败：(" + x + "," + y + ")");
            }
            // Android raw screencap format 1/2 is RGBA/RGBX; blue is byte index 2.
            blue[i] = rgba[2] & 0xff;
        }
        return new Sample(frame.width, frame.height, blue, uploadMs);
    }

    synchronized void release() {
        if (rgbaFrame != null) { rgbaFrame.release(); rgbaFrame = null; }
        allocatedWidth = allocatedHeight = 0;
    }

    static final class Sample {
        final int width, height;
        final int[] blue;
        final long decodeMs;
        Sample(int width, int height, int[] blue, long decodeMs) {
            this.width = width; this.height = height; this.blue = blue; this.decodeMs = decodeMs;
        }
    }
}
