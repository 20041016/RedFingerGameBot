package com.redfinger.gamebot;

import android.util.Log;

import org.opencv.android.OpenCVLoader;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

/** Native OpenCV PNG decoder and exact-pixel sampler for the six rhythm lanes. */
final class OpenCvFrameProcessor {
    private static final String TAG = "RFG-OpenCV";
    private static volatile boolean loaded;

    static synchronized void ensureLoaded() {
        if (loaded) return;
        if (!OpenCVLoader.initLocal()) {
            throw new IllegalStateException("OpenCV 原生库加载失败，请检查 APK 是否包含当前 CPU 架构的 so 文件");
        }
        loaded = true;
        Log.i(TAG, "OpenCV native library loaded");
    }

    Sample sampleBlue(byte[] png, int[] xs, int y) {
        ensureLoaded();
        long decodeStart = android.os.SystemClock.elapsedRealtimeNanos();
        MatOfByte encoded = new MatOfByte();
        Mat image = null;
        try {
            encoded.fromArray(png);
            image = Imgcodecs.imdecode(encoded, Imgcodecs.IMREAD_COLOR);
            long decodeMs = (android.os.SystemClock.elapsedRealtimeNanos() - decodeStart) / 1_000_000L;
            if (image.empty()) throw new IllegalStateException("OpenCV 无法解码 Root 截图 PNG");
            if (y < 0 || y >= image.rows()) {
                throw new IllegalArgumentException("音游检测 Y 坐标超出截图范围：" + y + "，截图高度=" + image.rows());
            }
            int[] blue = new int[xs.length];
            byte[] bgr = new byte[3];
            for (int i = 0; i < xs.length; i++) {
                int x = xs[i];
                if (x < 0 || x >= image.cols()) {
                    throw new IllegalArgumentException("音游检测 X 坐标超出截图范围：" + x + "，截图宽度=" + image.cols());
                }
                if (image.get(y, x, bgr) < 3) {
                    throw new IllegalStateException("OpenCV 读取像素失败：(" + x + "," + y + ")");
                }
                // OpenCV IMREAD_COLOR is BGR; channel 0 is the same blue component
                // previously returned by Android Color.blue(Bitmap.getPixel()).
                blue[i] = bgr[0] & 0xff;
            }
            return new Sample(image.cols(), image.rows(), blue, decodeMs);
        } finally {
            if (image != null) image.release();
            encoded.release();
        }
    }

    static final class Sample {
        final int width;
        final int height;
        final int[] blue;
        final long decodeMs;
        Sample(int width, int height, int[] blue, long decodeMs) {
            this.width = width;
            this.height = height;
            this.blue = blue;
            this.decodeMs = decodeMs;
        }
    }
}
