package com.redfinger.gamebot;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.Log;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Root + screenshot + Chinese OCR adapter. Call only from a worker thread. */
public class RootHost {
    private static final String TAG = "RFG-RootHost";
    private final TextRecognizer recognizer =
            TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
    private final File screenshotFile;
    private final File logDirectory;
    private final String suPath;
    private RootTouchController touchController;
    private RootScreenCapture screenCapture;
    private final OpenCvFrameProcessor openCvFrameProcessor = new OpenCvFrameProcessor();

    public RootHost(File cacheDir, File externalLogDirectory) {
        screenshotFile = new File(cacheDir, "rfgb_frame.png");
        logDirectory = externalLogDirectory != null
                ? externalLogDirectory : new File(cacheDir, "logs");
        suPath = resolveSuPath();
    }

    /** Append OCR diagnostics only when the Python engine reports 5 seconds without scene keywords. */
    public synchronized String saveOcrLog(String content) throws Exception {
        if (!logDirectory.exists() && !logDirectory.mkdirs()) {
            throw new IllegalStateException("无法创建 OCR 日志目录：" + logDirectory);
        }
        File file = new File(logDirectory, "ocr_unrecognized.log");
        try (FileOutputStream out = new FileOutputStream(file, true)) {
            out.write((content + "\n\n").getBytes("UTF-8"));
            out.flush();
        }
        Log.i(TAG, "OCR 识别诊断已保存：" + file.getAbsolutePath());
        return file.getAbsolutePath();
    }

    private String resolveSuPath() {
        String[] candidates = {
                "/data/.mci/su", "/system/xbin/su", "/system/bin/su", "su"
        };
        for (String candidate : candidates) {
            if ("su".equals(candidate)) return candidate;
            File f = new File(candidate);
            if (f.exists() && f.canExecute()) return candidate;
        }
        return "su";
    }

    /** Verifies the APK process, not the terminal app, actually received uid 0. */
    public String checkRoot() throws Exception {
        String result = runRoot("id");
        if (!result.contains("uid=0") && !result.contains("uid = 0")) {
            throw new SecurityException("Root 未授权给本 APK：" + result);
        }
        return result.trim();
    }

    public Map<String, Object> capture() throws Exception {
        runRoot("screencap -p " + shellQuote(screenshotFile.getAbsolutePath()));
        Bitmap bitmap = BitmapFactory.decodeFile(screenshotFile.getAbsolutePath());
        if (bitmap == null) {
            throw new IllegalStateException("截图解码失败，文件不存在或不可读：" +
                    screenshotFile.getAbsolutePath());
        }
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            CountDownLatch latch = new CountDownLatch(1);
            AtomicReference<Text> result = new AtomicReference<>();
            AtomicReference<Exception> error = new AtomicReference<>();
            recognizer.process(image)
                    .addOnSuccessListener(result::set)
                    .addOnFailureListener(e -> error.set(new Exception(e)))
                    .addOnCompleteListener(task -> latch.countDown());

            if (!latch.await(10, TimeUnit.SECONDS)) {
                throw new IllegalStateException("中文 OCR 超时");
            }
            if (error.get() != null) throw error.get();

            List<Map<String, Object>> items = new ArrayList<>();
            Text recognized = result.get();
            if (recognized != null) {
                for (Text.TextBlock block : recognized.getTextBlocks()) {
                    Rect r = block.getBoundingBox();
                    if (r == null) continue;
                    Map<String, Object> item = new HashMap<>();
                    item.put("text", block.getText());
                    item.put("left", r.left);
                    item.put("top", r.top);
                    item.put("right", r.right);
                    item.put("bottom", r.bottom);
                    items.add(item);
                }
            }
            Map<String, Object> frame = new HashMap<>();
            frame.put("width", bitmap.getWidth());
            frame.put("height", bitmap.getHeight());
            frame.put("texts", items);
            return frame;
        } finally {
            bitmap.recycle();
        }
    }


    /** Capture raw RGBA bytes through a persistent Root shell and sample six pixels with native OpenCV. */
    public synchronized Map<String, Object> captureBlueValues(int[] xs, int y) throws Exception {
        long captureStart = android.os.SystemClock.elapsedRealtimeNanos();
        if (screenCapture == null) screenCapture = new RootScreenCapture(suPath);
        RootScreenCapture.RawFrame frame = screenCapture.captureRaw();
        long captureMs = (android.os.SystemClock.elapsedRealtimeNanos() - captureStart) / 1_000_000L;
        // The stream is half-resolution (3200x1440 -> 1600x720); scale the
        // original Auto.js lane sample coordinates to the streamed frame.
        int[] scaledXs = new int[xs.length];
        for (int i = 0; i < xs.length; i++) scaledXs[i] = Math.round(xs[i] * 0.5f);
        int scaledY = Math.round(y * 0.5f);
        OpenCvFrameProcessor.Sample sample = openCvFrameProcessor.sampleBlue(frame, scaledXs, scaledY);
        Map<String, Object> result = new HashMap<>();
        result.put("width", sample.width);
        result.put("height", sample.height);
        result.put("blue", sample.blue);
        result.put("captureMs", captureMs);
        result.put("decodeMs", sample.decodeMs);
        result.put("captureMode", "screenrecord-raw-rgb");
        return result;
    }

    /** Initialize raw Root multitouch. Logical touch coordinates use portrait screen dimensions. */
    public synchronized String initializeMultiTouch(int logicalWidth, int logicalHeight) throws Exception {
        if (touchController != null) touchController.close();
        touchController = new RootTouchController(suPath, logicalWidth, logicalHeight);
        try { return touchController.initialize(); }
        catch (Exception e) { touchController.close(); touchController = null; throw e; }
    }

    public synchronized void touchDown(int x, int y, int pointerId) throws Exception {
        if (touchController == null) throw new IllegalStateException("Root 多点触控尚未初始化");
        touchController.down(x, y, pointerId);
    }

    public synchronized void touchUp(int pointerId) throws Exception {
        if (touchController != null) touchController.up(pointerId);
    }

    /** Update six lane contacts atomically with one Root pipe write. */
    public synchronized long updateTouches(int[] states, int[] xs, int[] ys) throws Exception {
        if (touchController == null) throw new IllegalStateException("Root 多点触控尚未初始化");
        return touchController.updateTouches(states, xs, ys);
    }

    public synchronized void releaseAllTouches() {
        if (touchController != null) touchController.releaseAll();
    }

    public void tap(int x, int y) throws Exception {
        runRoot("input tap " + x + " " + y);
    }

    public void swipe(int x1, int y1, int x2, int y2, int durationMs) throws Exception {
        runRoot("input swipe " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + durationMs);
    }

    public void log(String message) {
        Log.i(TAG, message);
    }

    public void close() {
        releaseAllTouches();
        if (touchController != null) { touchController.close(); touchController = null; }
        if (screenCapture != null) { screenCapture.close(); screenCapture = null; }
        openCvFrameProcessor.release();
        recognizer.close();
        //noinspection ResultOfMethodCallIgnored
        screenshotFile.delete();
    }

    private String runRoot(String command) throws Exception {
        Process process = new ProcessBuilder(suPath, "-c", command)
                .redirectErrorStream(true).start();
        byte[] output = readAll(process.getInputStream());
        int code = process.waitFor();
        String result = new String(output, "UTF-8");
        if (code != 0) {
            throw new IllegalStateException("Root 命令失败(" + code + "): " + result);
        }
        return result;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }
}
