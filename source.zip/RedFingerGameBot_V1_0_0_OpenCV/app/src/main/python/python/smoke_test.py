# -*- coding: utf-8 -*-
"""AlbumBot 离线冒烟测试。

用 FakeGame/FakeHost/FakeMusic 模拟游戏页面流转，验证状态机：
  - 目录页 →（coord_next_song）→ 难度选择页
  - 补难度优先级（传说 > 大师 > 困难 > 普通）
  - 开始演奏 → 黑盒演奏 → 结算判断 → 达标继续 / 未达标重试
  - 目标已完成的歌曲直接（coord_difficulty_done_return）返回目录并计数
  - 12 首完成后停止并发完成告警

运行：python3 smoke_test.py
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CANDIDATE_PKG_DIRS = [
    os.environ.get("REDFINGER_PY_DIR", ""),
    os.path.join(HERE, "..", ".openclaw", "tmp", "touch_heat_extracted",
                 "RedFingerGameBot_V1_0_0_OpenCV", "app", "src", "main",
                 "python", "python"),
]
for cand in CANDIDATE_PKG_DIRS:
    if cand and os.path.isfile(os.path.join(cand, "frame.py")):
        sys.path.insert(0, os.path.abspath(cand))
        break
else:
    raise SystemExit("找不到 RedFinger python 包目录（含 frame.py），"
                     "请设置环境变量 REDFINGER_PY_DIR")
sys.path.insert(0, HERE)

import album_bot  # noqa: E402
from album_bot import AlbumBot, S_DONE  # noqa: E402

DIFFS = ("传说", "大师", "困难", "普通")
DIFF_POS = {"传说": (250, 150), "大师": (250, 230), "困难": (250, 310), "普通": (250, 390)}
BADGE_POS = {"传说": (550, 150), "大师": (550, 230), "困难": (550, 310), "普通": (550, 390)}
# 与 BADGE_POS 对应的难度锚点（配置里的 DIFFICULTY_ANCHORS）；故意不完全重合，
# 验证「按最近锚点映射」而非精确匹配。
TEST_ANCHORS = {"普通": (520, 385), "困难": (520, 305), "大师": (520, 225), "传说": (520, 145)}
START_POS = (900, 600)
CONTINUE_POS = (400, 600)
RETRY_POS = (650, 600)
SELECT_SONG_POS = (850, 600)   # 结算页「选择曲目」按钮
ENTRY_POS = (640, 400)   # 「前往演奏」按钮
DIALOG_DISMISS_POS = (640, 300)   # 异常弹窗「知道了」按钮
PLAY_TICKS = 3          # 每次演奏需要多少个黑盒 step 后进入结算
TICK_MS = 10            # 每次驱动 step() 推进的虚拟毫秒


def make_frame(texts):
    """texts: [(text, x, y)] -> Frame.from_host 可消费的原始数据。"""
    items = []
    for text, x, y in texts:
        items.append({"text": text,
                      "bounds": {"left": x - 40, "top": y - 20,
                                 "right": x + 40, "bottom": y + 20}})
    return {"width": 1280, "height": 720, "texts": items}


class FakeGame:
    """最小游戏模型：目录页/难度页/演奏/结算 四个页面。

    目录页带「千音雅集」目录门词。可模拟两种门缺失场景：
      - show_gate_at_start=False：启动画面无门词（启动检查应直接停止）
      - gate_block_captures=N：回到目录后前 N 次截图无门词（应等待不点击）
    tap() 内置不变量：目录页门词未出现时点击即抛错。
    """

    def __init__(self, cfg, plan=None, pre_done=None,
                 show_gate_at_start=True, gate_block_captures=0,
                 direct_to_difficulty=False, retry_delay_captures=0,
                 dialog_on_return=False):
        self.cfg = cfg
        self.plan = plan or {}          # (song, diff) -> [每次尝试的完成率]
        self.pre_done = pre_done or set()
        self.attempt_idx = {}
        self.page = "catalog"
        self.song = 0
        self.badges = {}                # diff -> 是否大音天籁
        self.selected = None
        self.show_start = False
        self.play_ticks_left = 0
        self.result_rate = None
        self.play_sessions = 0
        self.tap_count = 0
        self.capture_count = 0
        self.show_gate_at_start = show_gate_at_start
        self.gate_block_captures = gate_block_captures
        self.gate_wait_captures = 0
        self.gate_hidden_now = not show_gate_at_start
        self.direct_to_difficulty = direct_to_difficulty
        self.show_entry_button = not direct_to_difficulty
        self.next_song_clicks = 0
        self.visited_difficulty = False
        self.retry_delay_captures = retry_delay_captures  # 点再次演奏后旧结算页停留帧数
        self.pending_retry = False
        self.dialog_on_return = dialog_on_return  # 返回目录时弹网络异常窗
        self.dialog_active = False
        self.dialog_handled = False
        if self.show_entry_button:
            # 统一布局：目录页上已选中第 1 首，单曲流程从点「前往演奏」开始
            self.enter_song()

    # ---------------- 页面切换 ----------------

    def enter_song(self):
        self.song += 1
        self.badges = {d: ((self.song, d) in self.pre_done) for d in DIFFS}
        self.selected = None
        self.show_start = False

    def begin_play(self):
        self.page = "playing"
        self.play_ticks_left = PLAY_TICKS
        self.show_start = False
        self.play_sessions += 1

    def tick_play(self):
        if self.page != "playing":
            return
        self.play_ticks_left -= 1
        if self.play_ticks_left <= 0:
            self.page = "settlement"
            self.result_rate = self._next_result()

    def _next_result(self):
        key = (self.song, self.selected)
        seq = self.plan.get(key, [100.0])
        idx = self.attempt_idx.get(key, 0)
        self.attempt_idx[key] = idx + 1
        return seq[min(idx, len(seq) - 1)]

    # ---------------- 输入 ----------------

    def tap(self, x, y):
        self.tap_count += 1
        if self.page == "catalog":
            if self.dialog_active and self._near(x, y, DIALOG_DISMISS_POS):
                self.dialog_active = False
                self.dialog_handled = True
                return
            if self._near(x, y, self.cfg.COORD_NEXT_SONG):
                assert not self.gate_hidden_now, "不变量被破坏：门词未出现时点击了 coord_next_song"
                self.next_song_clicks += 1
                self.enter_song()
                if self.direct_to_difficulty:
                    self.page = "difficulty"
                return
            if self.show_entry_button and self._near(x, y, ENTRY_POS):
                self.page = "difficulty"
            return
        if self.page == "difficulty":
            if self._near(x, y, self.cfg.COORD_DIFFICULTY_DONE_RETURN):
                self.page = "catalog"
                return
            for d in DIFFS:
                if self._near(x, y, DIFF_POS[d]):
                    self.selected = d
                    self.show_start = True
                    return
            if self.show_start and self._near(x, y, START_POS):
                self.begin_play()
            return
        if self.page == "settlement":
            if self._near(x, y, SELECT_SONG_POS):
                self.badges[self.selected] = (self.result_rate >= 100.0)
                self.page = "catalog"
            elif self._near(x, y, CONTINUE_POS):
                self.badges[self.selected] = (self.result_rate >= 100.0)
                self.page = "difficulty"
            elif self._near(x, y, RETRY_POS):
                if self.retry_delay_captures > 0:
                    self.pending_retry = True   # 旧结算页短暂停留，延迟进入演奏
                else:
                    self.begin_play()

    def press_back(self):
        pass

    @staticmethod
    def _near(x, y, pos, tol=25):
        return abs(x - pos[0]) <= tol and abs(y - pos[1]) <= tol

    # ---------------- 截图 ----------------

    def frame(self):
        self.capture_count += 1
        if self.page == "catalog":
            gate_ok = True
            if not self.show_gate_at_start:
                gate_ok = False
            if self.visited_difficulty and self.gate_block_captures > 0:
                self.gate_block_captures -= 1
                self.gate_wait_captures += 1
                gate_ok = False
            self.gate_hidden_now = not gate_ok
            if (self.dialog_on_return and self.visited_difficulty
                    and self.gate_block_captures > 0 and not self.dialog_handled):
                self.dialog_active = True
            texts = [("专辑", 200, 100), ("曲目列表", 200, 200)]
            if self.dialog_active:
                texts.append(("网络异常", 300, 300))
                texts.append(("知道了", DIALOG_DISMISS_POS[0], DIALOG_DISMISS_POS[1]))
            if self.show_entry_button:
                texts.append(("前往演奏", ENTRY_POS[0], ENTRY_POS[1]))
            if gate_ok:
                texts.append(("千音雅集", 600, 100))
            return make_frame(texts)
        if self.page == "difficulty":
            self.visited_difficulty = True
            texts = [("难度选择", 200, 60)]
            for i, d in enumerate(DIFFS):
                x, y = DIFF_POS[d]
                texts.append((d, x, y))
                if self.badges.get(d):
                    bx, by = BADGE_POS[d]
                    texts.append(("大音天籁", bx, by))
            if self.show_start:
                texts.append(("开始演奏", START_POS[0], START_POS[1]))
            return make_frame(texts)
        if self.page == "playing":
            return make_frame([])
        # settlement
        if self.pending_retry and self.retry_delay_captures > 0:
            self.retry_delay_captures -= 1
            if self.retry_delay_captures <= 0:
                self.pending_retry = False
                self.begin_play()
        return make_frame([
            ("演奏完成率", 300, 200),
            ("%.1f%%" % self.result_rate, 550, 200),
            ("再次演奏", RETRY_POS[0], RETRY_POS[1]),
            ("选择曲目", SELECT_SONG_POS[0], SELECT_SONG_POS[1]),
        ])


class FakeHost:
    def __init__(self, game):
        self.game = game
        self.logs = []

    def capture(self):
        return self.game.frame()

    def tap(self, x, y):
        self.game.tap(x, y)

    def pressBack(self):
        self.game.press_back()

    def log(self, msg):
        self.logs.append(msg)


class FakeMusic:
    """黑盒演奏模块替身：只暴露 start/step/stop。"""

    def __init__(self, game, real_sleep_s=0.0):
        self.game = game
        self.real_sleep_s = real_sleep_s
        self.started = 0
        self.stopped = 0

    def start(self):
        self.started += 1

    def step(self):
        self.game.tick_play()
        if self.real_sleep_s:
            time.sleep(self.real_sleep_s)

    def stop(self):
        self.stopped += 1


class FakeAlerter:
    def __init__(self):
        self.sent = []

    def send(self, key, subject, body, force=False):
        self.sent.append((key, subject, force))
        return True


def run_case(name, completion_mode, plan, pre_done, expect_sessions,
             settle_mode="inline", real_sleep_s=0.0, game_kwargs=None,
             expect_stopped=False, expect_gate_waits=0, expect_final_status=None,
             expect_next_song_clicks=None, expect_alert_keys=()):
    cfg_overrides = {
        "COMPLETION_MODE": completion_mode,
        "SETTLE_CHECK_MODE": settle_mode,
        "DIFFICULTY_ANCHORS": TEST_ANCHORS,
        "POLL_INTERVAL_MS": 5,
        "SETTLE_CHECK_INTERVAL_MS": 20,
        "TARGET_WAIT_TIMEOUT_MS": 5000,
        "PLAY_CONFIRM_TIMEOUT_MS": 5000,
        "PLAY_TIMEOUT_MS": 20000,
        "RECOVERY_WAIT_TIMEOUT_MS": 5000,
        "UNKNOWN_PAGE_TIMEOUT_MS": 5000,
    }
    game = FakeGame(AlbumBot._load_config({**cfg_overrides,
                                            "COORD_NEXT_SONG": (640, 360),
                                            "COORD_DIFFICULTY_DONE_RETURN": (80, 60)}),
                    plan=plan, pre_done=pre_done, **(game_kwargs or {}))
    host = FakeHost(game)
    alerter = FakeAlerter()
    clock = {"ms": 0}
    bot = AlbumBot(host,
                   music_factory=lambda h: FakeMusic(game, real_sleep_s=real_sleep_s),
                   alerter=alerter,
                   overrides=cfg_overrides,
                   clock_ms=lambda: clock["ms"])
    bot.start()
    if expect_stopped:
        assert not bot.running, "[%s] 启动检查未通过时应直接停止" % name
        assert bot.state == "已停止", "[%s] 状态应为已停止，实际：%s" % (name, bot.state)
        assert game.tap_count == 0, "[%s] 启动检查未通过不应有任何点击" % name
        print("✅ %s 通过：启动检查未通过，直接停止，零点击" % name)
        return bot, game, host
    for i in range(300000):
        bot.step()
        clock["ms"] += TICK_MS
        if not bot.running:
            break
    else:
        raise AssertionError("[%s] 步数耗尽仍未结束，state=%s diag=%s"
                             % (name, bot.state, bot.diagnostic))

    assert bot.state == S_DONE, "[%s] 结束状态应为专辑完成，实际：%s（%s）" % (
        name, bot.state, bot.diagnostic)
    assert bot.songs_completed == 12, "[%s] 完成歌曲数应为 12，实际 %d" % (
        name, bot.songs_completed)
    assert game.play_sessions == expect_sessions, "[%s] 演奏场次应为 %d，实际 %d" % (
        name, expect_sessions, game.play_sessions)
    assert bot.total_retries == sum(max(0, len(v) - 1) for v in plan.values()), \
        "[%s] 重试次数与计划不符：%d" % (name, bot.total_retries)
    keys = [k for k, _, _ in alerter.sent]
    assert "album_done" in keys, "[%s] 应发出专辑完成告警" % name
    if expect_gate_waits:
        assert game.gate_wait_captures >= expect_gate_waits, \
            "[%s] 门词等待截图数应 >= %d，实际 %d" % (
                name, expect_gate_waits, game.gate_wait_captures)
    if expect_final_status is not None:
        assert bot.difficulty_status == expect_final_status, \
            "[%s] difficulty_status 应为 %s，实际 %s" % (
                name, expect_final_status, bot.difficulty_status)
    if expect_next_song_clicks is not None:
        assert game.next_song_clicks == expect_next_song_clicks, \
            "[%s] 「下一首」点击次数应为 %d，实际 %d" % (
                name, expect_next_song_clicks, game.next_song_clicks)
    sent_keys = {k for k, _, _ in alerter.sent}
    for want in expect_alert_keys:
        assert want in sent_keys, "[%s] 应发出 %s 告警，实际：%s" % (name, want, sent_keys)
    print("✅ %s 通过：演奏 %d 场，重试 %d 次，门词等待截图 %d 次，告警 %d 封"
          % (name, game.play_sessions, bot.total_retries,
             game.gate_wait_captures, len(alerter.sent)))
    return bot, game, host


def test_status_mapping():
    """difficulty_status 位置映射单测：大音天籁 → 最近难度锚点。"""
    from frame import Frame
    from coordinate import CoordinateMapper
    overrides = {
        "DIFFICULTY_ANCHORS": TEST_ANCHORS,
        "DIFFICULTY_MATCH_MAX_DIST": 80,
    }
    game = FakeGame(AlbumBot._load_config(overrides))
    bot = AlbumBot(FakeHost(game), overrides=overrides)
    bot.mapper = CoordinateMapper(1280, 720)
    frame = Frame.from_host(make_frame([
        ("大音天籁", 545, 152),   # 最近传说锚点 (520,145) → 传说
        ("大音天籁", 500, 395),   # 最近普通锚点 (520,385) → 普通
        ("大音天籁", 640, 200),   # 距最近锚点 > 80 → 忽略
    ]))
    status = bot._parse_difficulty_status(frame)
    expected = {"普通": True, "困难": False, "大师": False, "传说": True}
    assert status == expected, "位置映射结果错误：%s" % status
    assert bot._format_status(status) == \
        "difficulty_status = {普通: True, 困难: False, 大师: False, 传说: True}"
    print("✅ status_mapping 通过：%s" % bot._format_status(status))


def test_alert_actions():
    """异常邮件后动作【待确认】配置：continue / pause / stop；弹窗/加载失败告警。"""
    from frame import Frame
    from coordinate import CoordinateMapper

    for action, expect_state in (("continue", None), ("pause", "异常暂停"),
                                 ("stop", "已停止")):
        overrides = {"ON_ALERT_ACTION": action}
        game = FakeGame(AlbumBot._load_config(overrides))
        bot = AlbumBot(FakeHost(game), alerter=FakeAlerter(), overrides=overrides)
        bot.running = True
        bot._alert("network_error", "网络异常提醒", "x", abnormal=True)
        if expect_state is None:
            assert bot.running, "continue 不应中断运行"
        else:
            assert not bot.running and bot.state == expect_state, \
                "action=%s 应进入 %s，实际 %s" % (action, expect_state, bot.state)

    # 非异常告警（如单曲完成）不受 ON_ALERT_ACTION 影响
    overrides = {"ON_ALERT_ACTION": "stop"}
    game = FakeGame(AlbumBot._load_config(overrides))
    bot = AlbumBot(FakeHost(game), alerter=FakeAlerter(), overrides=overrides)
    bot.running = True
    bot._alert("song_done", "x", "y")
    assert bot.running, "非异常告警不应触发停止"

    # 弹窗 / 加载失败 → 对应告警键
    alerter = FakeAlerter()
    overrides = {"ON_ALERT_ACTION": "continue"}
    game = FakeGame(AlbumBot._load_config(overrides))
    bot = AlbumBot(FakeHost(game), alerter=alerter, overrides=overrides)
    bot.mapper = CoordinateMapper(1280, 720)
    bot.running = True
    assert bot._handle_exception_frame(
        Frame.from_host(make_frame([("加载失败", 200, 200)])), 0) is True
    assert bot._handle_exception_frame(
        Frame.from_host(make_frame([("知道了", 200, 200)])), 0) is True
    sent_keys = {k for k, _, _ in alerter.sent}
    assert "load_failure" in sent_keys and "popup" in sent_keys, sent_keys
    print("✅ alert_actions 通过：continue/pause/stop + load_failure/popup 告警")


def main():
    # 用例 1：legend_only 单曲逻辑。第 2 首传说首次 98% 重试；第 3 首传说已是大音天籁
    #         → 直接返回目录切歌。结算 100% 后点「选择曲目」回目录，不再回难度页，
    #         因此最后一次难度页识别结果为进入时的未完成态。
    run_case("legend_only", "legend_only",
             plan={(2, "传说"): [98.0, 100.0]},
             pre_done={(3, "传说")},
             expect_sessions=12,  # 10 首 ×1 + 第2首 ×2 + 第3首 ×0
             expect_final_status={"普通": False, "困难": False,
                                  "大师": False, "传说": False})

    # 用例 2：all_difficulties。12 首 × 4 难度，第 2 首大师重试 1 次，
    #         第 3 首传说/大师已完成 → 共 48 - 2 + 1 = 47 场。
    run_case("all_difficulties", "all_difficulties",
             plan={(2, "大师"): [98.0, 100.0]},
             pre_done={(3, "传说"), (3, "大师")},
             expect_sessions=47,
             expect_final_status={"普通": True, "困难": True,
                                  "大师": True, "传说": True})

    # 用例 3：目标全部已完成的歌曲不演奏、直接返回目录（断点续跑场景）。
    pre = {(s, "传说") for s in range(1, 13)}
    run_case("legend_only_resume", "legend_only",
             plan={}, pre_done=pre,
             expect_sessions=0,
             expect_final_status={"普通": False, "困难": False,
                                  "大师": False, "传说": True})

    # 用例 4：后台结算巡检线程（真实时间），验证不阻塞黑盒演奏节拍也能收尾。
    run_case("legend_only_bg_watcher", "legend_only",
             plan={}, pre_done=set(),
             expect_sessions=12,
             settle_mode="background", real_sleep_s=0.003)

    # 用例 5：启动画面无「千音雅集」→ 直接停止，零点击。
    run_case("startup_gate_fail", "legend_only",
             plan={}, pre_done=set(),
             expect_sessions=0,
             game_kwargs={"show_gate_at_start": False},
             expect_stopped=True)

    # 用例 6：回到目录后「千音雅集」延迟出现 → 等待期间不点击不报错，
    #         门词出现后才点 coord_next_song，全流程正常收尾。
    run_case("catalog_gate_wait", "legend_only",
             plan={}, pre_done=set(),
             expect_sessions=12,
             game_kwargs={"gate_block_captures": 4},
             expect_gate_waits=4)

    # 用例 7：点「下一首」直达难度选择页的布局（无需点「前往演奏」）。
    run_case("direct_difficulty_layout", "legend_only",
             plan={}, pre_done=set(),
             expect_sessions=12,
             game_kwargs={"direct_to_difficulty": True})

    # 用例 9：all_difficulties 单曲逻辑——四难度逐个补：
    #         每达 100% 点「选择曲目」返回当前曲目（不切下一首），等千音雅集后
    #         重点「前往演奏」回难度页继续；四难度全达成后才点下一首（11 次）。
    run_case("all_difficulties_reentry", "all_difficulties",
             plan={}, pre_done=set(),
             expect_sessions=48,   # 12 首 × 4 难度
             game_kwargs={"gate_block_captures": 2},
             expect_gate_waits=2,
             expect_next_song_clicks=11,
             expect_final_status={"普通": True, "困难": True,
                                  "大师": True, "传说": True})

    # 用例 10：重试后游戏短暂停留在旧结算页（陈旧帧）→ 不得误判为本局结果；
    #          点「再次演奏」后直接唤打歌模块，旧结算页消失后才承认新结算。
    run_case("settle_stale_retry", "legend_only",
             plan={(1, "传说"): [98.0, 100.0]},
             pre_done=set(),
             expect_sessions=13,   # 第 1 首 2 次 + 其余 11 首各 1 次
             game_kwargs={"retry_delay_captures": 2})

    # 用例 11：异常弹窗（网络异常）→ 发邮件提醒后继续运行（ON_ALERT_ACTION=continue），
    #          点掉弹窗、等「千音雅集」、正常切歌，12 首收尾。
    run_case("exception_email_continue", "legend_only",
             plan={}, pre_done=set(),
             expect_sessions=12,
             game_kwargs={"gate_block_captures": 4, "dialog_on_return": True},
             expect_gate_waits=4,
             expect_alert_keys=("network_error",))

    # 用例 8：difficulty_status 位置映射单测（大音天籁 → 最近难度锚点）。
    test_status_mapping()

    # 用例 12：异常邮件后动作配置 + 弹窗/加载失败告警单测。
    test_alert_actions()

    print("全部冒烟测试通过。")


if __name__ == "__main__":
    main()
