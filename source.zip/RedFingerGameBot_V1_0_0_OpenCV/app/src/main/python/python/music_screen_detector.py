"""Conservative OCR-based screen-state classifier for the rhythm-game workflow.

This module deliberately does not tap or swipe. It classifies only screens supported
by explicit UI text and requires repeated matching observations before confirming a
state. Unknown/transitioning screens remain UNKNOWN and must never trigger automation.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Mapping, Any


class ScreenState(str, Enum):
    SONG_LIST = "SONG_LIST"
    DIFFICULTY_SELECT = "DIFFICULTY_SELECT"
    RESULT = "RESULT"
    PLAYING = "PLAYING"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class ScreenObservation:
    state: ScreenState
    confidence: float
    evidence: tuple
    width: int = 0
    height: int = 0


def _text_items(frame: Mapping[str, Any]) -> list:
    items = frame.get("texts", []) if isinstance(frame, Mapping) else []
    result = []
    for item in items or []:
        if isinstance(item, Mapping):
            value = str(item.get("text", "")).strip()
            if value:
                result.append(value)
        elif item:
            result.append(str(item).strip())
    return result


class MusicScreenDetector:
    """Classify OCR frames and debounce state transitions.

    `PLAYING` is intentionally not inferred from an empty OCR result. The current
    supplied samples do not include a gameplay screenshot, so that state remains
    UNKNOWN until a future visual/lane-aware detector is calibrated.
    """

    def __init__(self, confirm_frames: int = 3):
        self.confirm_frames = max(1, int(confirm_frames))
        self._candidate = ScreenState.UNKNOWN
        self._candidate_count = 0
        self.current_state = ScreenState.UNKNOWN

    @staticmethod
    def classify(frame: Mapping[str, Any]) -> ScreenObservation:
        lines = _text_items(frame)
        joined = "".join(lines)
        width = int(frame.get("width", 0) or 0)
        height = int(frame.get("height", 0) or 0)

        # Result page has two distinctive action labels in the supplied screenshot.
        if "选择乐曲" in joined and "再次演奏" in joined:
            evidence = tuple(x for x in lines if "选择乐曲" in x or "再次演奏" in x)
            return ScreenObservation(ScreenState.RESULT, 0.99, evidence, width, height)

        # Difficulty page contains all/most difficulty labels plus the start action.
        difficulty_words = ("普通", "困难", "大师", "传说")
        found_difficulties = tuple(word for word in difficulty_words if word in joined)
        if "开始演奏" in joined and len(found_difficulties) >= 3:
            evidence = ("开始演奏",) + found_difficulties
            return ScreenObservation(ScreenState.DIFFICULTY_SELECT, 0.98, evidence, width, height)

        # Song list page contains its dedicated action and chart creation action.
        if "前往演奏" in joined and "创作曲谱" in joined:
            evidence = tuple(x for x in lines if "前往演奏" in x or "创作曲谱" in x)
            return ScreenObservation(ScreenState.SONG_LIST, 0.98, evidence, width, height)

        # No false positive: empty/ambiguous OCR is not treated as gameplay.
        return ScreenObservation(ScreenState.UNKNOWN, 0.0, tuple(lines[:8]), width, height)

    def observe(self, frame: Mapping[str, Any]) -> ScreenObservation:
        raw = self.classify(frame)
        if raw.state == ScreenState.UNKNOWN:
            self._candidate = ScreenState.UNKNOWN
            self._candidate_count = 0
            self.current_state = ScreenState.UNKNOWN
            return raw

        if raw.state == self._candidate:
            self._candidate_count += 1
        else:
            self._candidate = raw.state
            self._candidate_count = 1

        if self._candidate_count >= self.confirm_frames:
            self.current_state = raw.state
            return raw

        return ScreenObservation(
            ScreenState.UNKNOWN, raw.confidence,
            raw.evidence + (f"确认中:{self._candidate_count}/{self.confirm_frames}",),
            raw.width, raw.height
        )

    def reset(self):
        self._candidate = ScreenState.UNKNOWN
        self._candidate_count = 0
        self.current_state = ScreenState.UNKNOWN
