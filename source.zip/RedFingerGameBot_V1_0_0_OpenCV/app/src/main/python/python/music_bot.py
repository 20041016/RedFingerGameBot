"""Six-lane rhythm helper using the original judge-line colour trigger.
A lane is pressed when its judge-line pixel's blue value falls below the
threshold, and released after the minimum hold time when the pixel clears.
All coordinates are in the original 3200x1440 space.
"""
import time
from .frame import _map_get, _as_sequence
class MusicBot:
    DETECT_XS = [778, 1100, 1440, 1780, 2100, 2440]
    DETECT_Y = 1210
    TOUCH_X = 230
    BLUE_THRESHOLD = 220
    LOOP_INTERVAL_MS = 5
    LOGICAL_TOUCH_WIDTH = 1440
    LOGICAL_TOUCH_HEIGHT = 3200
    MIN_HOLD_MS = 70            # minimum press length for a tap
    REARM_MS = 90               # ignore a retrigger briefly after a release
    def __init__(self, host):
        self.host = host
        config = list(host.getMusicCoordinateConfig())
        if len(config) != 9:
            config = [778, 1100, 1440, 1780, 2100, 2440, 1210, 230, -1]
        self.detect_xs = [int(v) for v in config[:6]]
        self.detect_y = int(config[6])
        self.touch_x = int(config[7])
        self.touch_ys = list(self.detect_xs) if int(config[8]) < 0 else [int(config[8])] * 6
        self.running = False
        self.state = "音游待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = self.LOOP_INTERVAL_MS
        self.track_pressed = [False] * 6
        self.last_blue = [0] * 6
        self.frame_count = 0
        self.press_count = 0
        self.touch_device = "尚未初始化"
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.last_touch_ms = 0.0
        self.last_decision_to_write_ms = 0.0
        self.hold_until = [0.0] * 6
        self.rearm_until = [0.0] * 6
    def _load_tuning(self):
        """Read the minimum tap-hold duration from the floating settings window."""
        getter = getattr(self.host, "getMusicTuning", None)
        if not callable(getter):
            return
        try:
            values = [int(v) for v in getter()]
            if len(values) >= 1:
                self.MIN_HOLD_MS = max(20, min(400, values[0]))
        except Exception as exc:
            self._log("读取按住时间参数失败：" + str(exc))
    def start(self):
        self.stop()
        self.track_pressed = [False] * 6
        self.frame_count = 0
        self.press_count = 0
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.last_touch_ms = 0.0
        self.last_decision_to_write_ms = 0.0
        self.hold_until = [0.0] * 6
        self.rearm_until = [0.0] * 6
        self.diagnostic = "正在初始化 Root 多点触控"
        self.touch_device = str(self.host.initializeMultiTouch(
            self.LOGICAL_TOUCH_WIDTH, self.LOGICAL_TOUCH_HEIGHT))
        self.running = True
        self.state = "音游运行中"
        self.diagnostic = "六轨识别已启动；触控设备：" + self.touch_device
        self._log(self.diagnostic)
    # ------------------------------------------------------------------ frame capture
    def _capture(self):
        """Return judge-line blue values and frame timing."""
        result = self.host.captureBlueValues(self.detect_xs, self.detect_y)
        blue = [int(v) for v in _as_sequence(_map_get(result, "blue", []))]
        if len(blue) != 6:
            raise RuntimeError("颜色采样返回值数量不是六条轨道")
        return (blue, int(_map_get(result, "captureMs", 0)),
                int(_map_get(result, "decodeMs", 0)))
    @staticmethod
    def _now_ms():
        return time.perf_counter() * 1000.0
    # ------------------------------------------------------------------ main step
    def step(self):
        if not self.running:
            return
        try:
            loop_start = time.perf_counter()
            blue, self.last_capture_ms, self.last_decode_ms = self._capture()
            self.last_blue = blue
            self.frame_count += 1
            now = self._now_ms()
            desired = list(self.track_pressed)
            # 1) release: lane has been held long enough and the judge pixel is clear again.
            for lane in range(6):
                if desired[lane] and now >= self.hold_until[lane] \
                        and blue[lane] >= self.BLUE_THRESHOLD:
                    desired[lane] = False
                    self.rearm_until[lane] = now + self.REARM_MS
            # 2) original reactive colour trigger.
            now = self._now_ms()
            for lane in range(6):
                if not desired[lane] and blue[lane] < self.BLUE_THRESHOLD \
                        and now >= self.rearm_until[lane]:
                    desired[lane] = True
                    self.hold_until[lane] = max(self.hold_until[lane], now + self.MIN_HOLD_MS)
            changed = any(desired[i] != self.track_pressed[i] for i in range(6))
            if changed:
                touch_start = time.perf_counter()
                states = [1 if v else 0 for v in desired]
                java_ms = self.host.updateTouches(states, [self.touch_x] * 6, list(self.touch_ys))
                self.last_touch_ms = float(java_ms)
                self.last_decision_to_write_ms = (time.perf_counter() - touch_start) * 1000.0
                self.press_count += sum(1 for i in range(6)
                                        if desired[i] and not self.track_pressed[i])
                self.track_pressed = desired
            else:
                self.last_touch_ms = 0.0
                self.last_decision_to_write_ms = 0.0
            loop_ms = (time.perf_counter() - loop_start) * 1000.0
            self.total_loop_ms += loop_ms
            avg_ms = self.total_loop_ms / max(1, self.frame_count)
            self.last_fps = 1000.0 / max(0.1, avg_ms)
            mode = "反应模式"
            self.diagnostic = (
                "帧%d 触发%d %.1fFPS\n%s\n原始帧%dms CV%dms 循环%.1fms 写入%dms" %
                (self.frame_count, self.press_count, self.last_fps, mode,
                 self.last_capture_ms, self.last_decode_ms, loop_ms, int(self.last_touch_ms))
            )
        except Exception as exc:
            self._release_all()
            self.running = False
            self.state = "音游运行异常"
            self.diagnostic = str(exc)
            self._log("音游引擎异常：" + self.diagnostic)
            raise
    def stop(self):
        self.running = False
        self._release_all()
        self.state = "音游已停止"
    def _release_all(self):
        try:
            release = getattr(self.host, "releaseAllTouches", None)
            if callable(release):
                release()
            else:
                for i, pressed in enumerate(self.track_pressed):
                    if pressed:
                        self.host.touchUp(i)
        except Exception as exc:
            self._log("释放触点时发生异常：" + str(exc))
        self.track_pressed = [False] * 6
    def _log(self, message):
        try:
            self.host.log(message)
        except Exception:
            pass
