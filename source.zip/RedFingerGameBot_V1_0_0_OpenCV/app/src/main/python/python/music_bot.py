"""Six-lane rhythm helper: predictive note timing on top of the original colour sampling.

Original behaviour (still the fallback): press a lane while the judge-line pixel's blue < 220,
i.e. when a note's body first touches the judge point.

Predictive mode: the Java side also returns every note centre (pale-yellow signature) inside each
lane strip. Notes are tracked across frames, the constant fall speed is estimated, and each note's
arrival time at the judge line is averaged over many observations (no single-frame jitter).

Timing baseline: the script MEASURES when the old trigger would have fired (contact radius in
pixels, seen as the moment the judge pixel changes shortly before arrival) and reproduces exactly
that average timing. PRESS_OFFSET_MS (edited live in the floating settings window) moves the press
earlier (+) or later (-) relative to that baseline, so 0 behaves like the old logic and no absolute
latency has to be guessed.

All coordinates here are in the original 3200x1440 space.
"""
import time
from collections import deque

from .frame import _map_get, _as_sequence


class MusicBot:
    DETECT_XS = [778, 1100, 1440, 1780, 2100, 2440]
    DETECT_Y = 1210
    TOUCH_X = 230
    BLUE_THRESHOLD = 220
    LOOP_INTERVAL_MS = 5
    LOGICAL_TOUCH_WIDTH = 1440
    LOGICAL_TOUCH_HEIGHT = 3200

    # ---- predictive timing ----
    PREDICT_ENABLED = True
    PRESS_OFFSET_MS = 0         # live-editable: + earlier, - later, relative to the old trigger timing
    MIN_HOLD_MS = 70            # live-editable: minimum press length for a tap
    CAPTURE_AGE_MS = 8          # how old a frame already is when we receive it
    PROC_MS = 2                 # receive-frame -> touch-write time of the old (reactive) path
    HOLD_AFTER_ARRIVAL_MS = 60  # keep pressing this long past the predicted arrival
    REARM_MS = 90               # ignore the legacy colour trigger this long after a release
    NOTE_HALF_WIDTH = 60
    NOTE_SCAN_TOP = 120
    NOTE_SCAN_BOTTOM = 1290
    NEW_TRACK_MARGIN = 40       # do not start tracking notes this close to the judge line
    MAX_STEP_PX = 260           # max plausible move between two frames while speed is unknown
    TRACK_TIMEOUT_MS = 600
    OBS_KEEP = 16               # observations kept per note
    ARRIVAL_AVG = 8             # latest observations averaged (median) for the arrival time
    SPEED_BASELINE_MS = 120     # speed samples use at least this long a baseline (immune to frame jitter)
    SPEED_WINDOW = 150
    MIN_SPEED_SAMPLES = 10
    MIN_CAL_SAMPLES = 6         # contact-radius samples needed before predictive pressing starts
    TUNING_REFRESH_FRAMES = 30  # re-read the values edited in the floating settings window

    def __init__(self, host):
        self.host = host
        config = list(host.getMusicCoordinateConfig())
        if len(config) != 9:
            config = [778, 1100, 1440, 1780, 2100, 2440, 1210, 230, -1]
        self.detect_xs = [int(v) for v in config[:6]]
        self.detect_y = int(config[6])
        self.touch_x = int(config[7])
        self.touch_ys = list(self.detect_xs) if int(config[8]) < 0 else [int(config[8])] * 6
        self.running = False
        self.state = "音游待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = self.LOOP_INTERVAL_MS
        self.track_pressed = [False] * 6
        self.last_blue = [0] * 6
        self.frame_count = 0
        self.press_count = 0
        self.touch_device = "尚未初始化"
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.last_touch_ms = 0.0
        self.last_decision_to_write_ms = 0.0
        self._reset_prediction()

    def _reset_prediction(self):
        self.tracks = [[] for _ in range(6)]
        self.speed_samples = deque(maxlen=self.SPEED_WINDOW)
        self.speed = 0.0                            # px per ms (0 = unknown)
        self.radius_samples = deque(maxlen=60)      # contact radius in px (note edge -> centre)
        self.radius_px = None
        self.hold_until = [0.0] * 6
        self.rearm_until = [0.0] * 6
        self.prev_blue = [255] * 6
        self.predicted_presses = 0
        self.reactive_presses = 0
        self.jitter_ms = 0.0
        self.last_frame_t = None
        self.frame_period_ms = 16.7

    def _load_tuning(self):
        """PRESS_OFFSET_MS / MIN_HOLD_MS / PREDICT_ENABLED come from the floating settings window."""
        getter = getattr(self.host, "getMusicTuning", None)
        if not callable(getter):
            return
        try:
            values = [int(v) for v in getter()]
            if len(values) < 3:
                return
            self.PRESS_OFFSET_MS = max(-300, min(300, values[0]))
            self.MIN_HOLD_MS = max(20, min(400, values[1]))
            predict = bool(values[2])
            if predict != self.PREDICT_ENABLED:
                self.tracks = [[] for _ in range(6)]       # drop stale tracks when switching
            self.PREDICT_ENABLED = predict
        except Exception as exc:
            self._log("读取预判参数失败：" + str(exc))

    def start(self):
        self.stop()
        self._load_tuning()
        self.track_pressed = [False] * 6
        self.frame_count = 0
        self.press_count = 0
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.last_touch_ms = 0.0
        self.last_decision_to_write_ms = 0.0
        self._reset_prediction()
        self.diagnostic = "正在初始化 Root 多点触控"
        self.touch_device = str(self.host.initializeMultiTouch(
            self.LOGICAL_TOUCH_WIDTH, self.LOGICAL_TOUCH_HEIGHT))
        self.running = True
        self.state = "音游运行中"
        self.diagnostic = "六轨识别已启动；触控设备：" + self.touch_device
        self._log(self.diagnostic)

    # ------------------------------------------------------------------ frame capture
    def _capture(self):
        """Returns (blue[6], notes[(lane, y)], capture_ms, decode_ms)."""
        capture_notes = getattr(self.host, "captureNotes", None) if self.PREDICT_ENABLED else None
        if callable(capture_notes):
            result = capture_notes(self.detect_xs, self.detect_y, self.NOTE_HALF_WIDTH,
                                   self.NOTE_SCAN_TOP, self.NOTE_SCAN_BOTTOM)
            flat = [int(v) for v in _as_sequence(_map_get(result, "notes", []))]
            notes = [(flat[i], flat[i + 1]) for i in range(0, len(flat) - 2, 3)]
        else:
            result = self.host.captureBlueValues(self.detect_xs, self.detect_y)
            notes = []
        blue = [int(v) for v in _as_sequence(_map_get(result, "blue", []))]
        if len(blue) != 6:
            raise RuntimeError("颜色采样返回值数量不是六条轨道")
        return (blue, notes, int(_map_get(result, "captureMs", 0)),
                int(_map_get(result, "decodeMs", 0)))

    # ------------------------------------------------------------------ note tracking
    def _arrival(self, tr):
        """Arrival time at the judge line: median of the estimates from the latest observations."""
        if self.speed <= 0 or not tr["obs"]:
            return None
        ests = sorted(ti + (self.detect_y - yi) / self.speed
                      for ti, yi in tr["obs"][-self.ARRIVAL_AVG:])
        return ests[len(ests) // 2]

    def _update_tracks(self, notes, t):
        by_lane = [[] for _ in range(6)]
        for lane, y in notes:
            if 0 <= lane < 6:
                by_lane[lane].append(y)
        for lane in range(6):
            ys = sorted(by_lane[lane])
            tracks = self.tracks[lane]
            used = set()
            for tr in sorted(tracks, key=lambda r: -r["y"]):      # lowest (oldest) note first
                dt = t - tr["t"]
                if self.speed > 0:
                    pred = tr["y"] + self.speed * dt
                    tol = max(60.0, 0.5 * self.speed * dt)
                    cands = [(abs(y - pred), j) for j, y in enumerate(ys)
                             if j not in used and abs(y - pred) <= tol]
                else:
                    cands = [(y - tr["y"], j) for j, y in enumerate(ys)
                             if j not in used and -10 <= y - tr["y"] <= self.MAX_STEP_PX]
                if not cands:
                    continue
                _, j = min(cands)
                used.add(j)
                y = ys[j]
                tr["obs"].append((t, y))
                if len(tr["obs"]) > self.OBS_KEEP:
                    del tr["obs"][0]
                base = t - tr["first_t"]
                if base >= self.SPEED_BASELINE_MS and y > tr["first_y"]:
                    self.speed_samples.append((y - tr["first_y"]) / base)
                tr["y"], tr["t"] = y, t
            for j, y in enumerate(ys):
                if j not in used and y < self.detect_y - self.NEW_TRACK_MARGIN:
                    tracks.append({"y": y, "t": t, "first_y": y, "first_t": t,
                                   "obs": [(t, y)], "fired": False, "cal": False})
            self.tracks[lane] = [
                tr for tr in tracks
                if t - tr["t"] <= self.TRACK_TIMEOUT_MS
                and tr["y"] + self.speed * (t - tr["t"]) < self.detect_y + 150
            ]
        if len(self.speed_samples) >= self.MIN_SPEED_SAMPLES:
            ordered = sorted(self.speed_samples)
            self.speed = ordered[len(ordered) // 2]

    def _observe_edges(self, blue, t):
        """Measure the old trigger's contact radius: judge pixel changes shortly before arrival."""
        if self.speed <= 0:
            return
        for lane in range(6):
            if self.prev_blue[lane] >= self.BLUE_THRESHOLD > blue[lane]:
                best = None
                for tr in self.tracks[lane]:
                    if tr["fired"] or tr["cal"]:
                        continue
                    est = self._arrival(tr)
                    if est is None:
                        continue
                    d = est - t
                    if 5.0 <= d <= 160.0 and (best is None or d < best[0]):
                        best = (d, tr)
                if best:
                    best[1]["cal"] = True
                    self.radius_samples.append(best[0] * self.speed)
        if len(self.radius_samples) >= self.MIN_CAL_SAMPLES:
            ordered = sorted(self.radius_samples)
            self.radius_px = ordered[len(ordered) // 2]

    def _lead_ms(self):
        """How long before the predicted arrival to write the touch."""
        return (self.radius_px / self.speed - self.CAPTURE_AGE_MS - self.PROC_MS
                + self.PRESS_OFFSET_MS)

    def _update_jitter(self):
        stds = []
        for lane in range(6):
            for tr in self.tracks[lane]:
                obs = tr["obs"][-self.ARRIVAL_AVG:]
                if len(obs) >= 5 and self.speed > 0:
                    ests = [ti + (self.detect_y - yi) / self.speed for ti, yi in obs]
                    mean = sum(ests) / len(ests)
                    stds.append((sum((e - mean) ** 2 for e in ests) / len(ests)) ** 0.5)
        if stds:
            self.jitter_ms += 0.1 * (sum(stds) / len(stds) - self.jitter_ms)

    def _due_presses(self, now):
        """Notes whose press instant falls within the next frame: (press_at, arrival, lane, track)."""
        due = []
        if self.speed <= 0 or self.radius_px is None:
            return due
        lead = self._lead_ms()
        horizon = max(8.0, min(25.0, self.frame_period_ms))
        for lane in range(6):
            for tr in self.tracks[lane]:
                if tr["fired"]:
                    continue
                arrival = self._arrival(tr)
                if arrival is None:
                    continue
                press_at = arrival - lead
                if press_at <= now + horizon:
                    due.append((press_at, arrival, lane, tr))
        due.sort(key=lambda item: item[0])
        return due

    @staticmethod
    def _now_ms():
        return time.perf_counter() * 1000.0

    def _spin_until(self, target_ms):
        while True:
            remaining = target_ms - self._now_ms()
            if remaining <= 0:
                return
            if remaining > 2.0:
                time.sleep(0.001)

    # ------------------------------------------------------------------ main step
    def step(self):
        if not self.running:
            return
        try:
            loop_start = time.perf_counter()
            blue, notes, self.last_capture_ms, self.last_decode_ms = self._capture()
            t = self._now_ms() - self.CAPTURE_AGE_MS            # when the frame's content was true
            if self.last_frame_t is not None:
                period = t - self.last_frame_t
                if 4.0 <= period <= 100.0:
                    self.frame_period_ms += 0.1 * (period - self.frame_period_ms)
            self.last_frame_t = t
            self.last_blue = blue
            self.frame_count += 1
            if self.frame_count % self.TUNING_REFRESH_FRAMES == 0:
                self._load_tuning()

            now = self._now_ms()
            desired = list(self.track_pressed)

            if self.PREDICT_ENABLED:
                self._update_tracks(notes, t)
                self._observe_edges(blue, t)
                self._update_jitter()

            # 1) release: lane has been held long enough and the judge pixel is clear again.
            for lane in range(6):
                if desired[lane] and now >= self.hold_until[lane] \
                        and blue[lane] >= self.BLUE_THRESHOLD:
                    desired[lane] = False
                    self.rearm_until[lane] = now + self.REARM_MS

            # 2) predictive presses, timed precisely (never later than the frame allows).
            fired_lanes = []
            if self.PREDICT_ENABLED:
                for press_at, arrival, lane, tr in self._due_presses(now):
                    tr["fired"] = True
                    if desired[lane]:
                        self.hold_until[lane] = max(self.hold_until[lane],
                                                    arrival + self.HOLD_AFTER_ARRIVAL_MS)
                        continue
                    self.hold_until[lane] = max(press_at + self.MIN_HOLD_MS,
                                                arrival + self.HOLD_AFTER_ARRIVAL_MS)
                    desired[lane] = True
                    fired_lanes.append((press_at, lane))
                if fired_lanes:
                    self._spin_until(min(p for p, _ in fired_lanes))
                    self.predicted_presses += len(fired_lanes)

            # 3) legacy colour trigger: the baseline until calibrated, then covers misses and holds.
            now = self._now_ms()
            for lane in range(6):
                if not desired[lane] and blue[lane] < self.BLUE_THRESHOLD \
                        and now >= self.rearm_until[lane]:
                    desired[lane] = True
                    self.hold_until[lane] = max(self.hold_until[lane], now + self.MIN_HOLD_MS)
                    self.reactive_presses += 1
            self.prev_blue = blue

            changed = any(desired[i] != self.track_pressed[i] for i in range(6))
            if changed:
                touch_start = time.perf_counter()
                states = [1 if v else 0 for v in desired]
                java_ms = self.host.updateTouches(states, [self.touch_x] * 6, list(self.touch_ys))
                self.last_touch_ms = float(java_ms)
                self.last_decision_to_write_ms = (time.perf_counter() - touch_start) * 1000.0
                self.press_count += sum(1 for i in range(6)
                                        if desired[i] and not self.track_pressed[i])
                self.track_pressed = desired
            else:
                self.last_touch_ms = 0.0
                self.last_decision_to_write_ms = 0.0

            loop_ms = (time.perf_counter() - loop_start) * 1000.0
            self.total_loop_ms += loop_ms
            avg_ms = self.total_loop_ms / max(1, self.frame_count)
            self.last_fps = 1000.0 / max(0.1, avg_ms)
            if not self.PREDICT_ENABLED:
                mode = "反应模式"
            elif self.speed <= 0 or self.radius_px is None:
                mode = "校准中 速度%d/%d 基准%d/%d(沿用原逻辑)" % (
                    len(self.speed_samples), self.MIN_SPEED_SAMPLES,
                    len(self.radius_samples), self.MIN_CAL_SAMPLES)
            else:
                mode = "预判 速%.2f 基准提前%dms 偏移%+d 抖动±%.1f 预%d补%d" % (
                    self.speed, round(self.radius_px / self.speed), self.PRESS_OFFSET_MS,
                    self.jitter_ms, self.predicted_presses, self.reactive_presses)
            self.diagnostic = (
                "帧%d 触发%d %.1fFPS\n%s\n原始帧%dms CV%dms 循环%.1fms 写入%dms" %
                (self.frame_count, self.press_count, self.last_fps, mode,
                 self.last_capture_ms, self.last_decode_ms, loop_ms, int(self.last_touch_ms))
            )
        except Exception as exc:
            self._release_all()
            self.running = False
            self.state = "音游运行异常"
            self.diagnostic = str(exc)
            self._log("音游引擎异常：" + self.diagnostic)
            raise

    def stop(self):
        self.running = False
        self._release_all()
        self.state = "音游已停止"

    def _release_all(self):
        try:
            release = getattr(self.host, "releaseAllTouches", None)
            if callable(release):
                release()
            else:
                for i, pressed in enumerate(self.track_pressed):
                    if pressed:
                        self.host.touchUp(i)
        except Exception as exc:
            self._log("释放触点时发生异常：" + str(exc))
        self.track_pressed = [False] * 6

    def _log(self, message):
        try:
            self.host.log(message)
        except Exception:
            pass
