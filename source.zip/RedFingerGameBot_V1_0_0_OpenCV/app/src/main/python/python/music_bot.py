"""Six-lane rhythm helper: predictive note timing on top of the original colour sampling.

Original behaviour (kept as fallback): press a lane while the judge-line pixel's blue < 220.
That can only react after a note has already reached the line, so it is always one
pipeline-latency late.

Predictive mode: the Java side also returns every note centre (pale-yellow signature) inside
each lane strip. We track those notes across frames, estimate the constant fall speed, and
press so that the touch lands on the judge line exactly when the note arrives
(arrival time - PRESS_LEAD_MS). Notes that are hidden for a moment (e.g. behind the floating
controller) keep being extrapolated from their last sightings. Holds still work through the
colour test: once pressed we keep holding until the judge pixel clears.

All coordinates here are in the original 3200x1440 space.
"""
import time
from collections import deque

from .frame import _map_get, _as_sequence


class MusicBot:
    # Values from the supplied Auto.js script. Detection uses landscape screenshot
    # coordinates; touch coordinates intentionally use its portrait-axis mapping.
    DETECT_XS = [778, 1100, 1440, 1780, 2100, 2440]
    DETECT_Y = 1210
    TOUCH_X = 230
    BLUE_THRESHOLD = 220
    LOOP_INTERVAL_MS = 5
    LOGICAL_TOUCH_WIDTH = 1440
    LOGICAL_TOUCH_HEIGHT = 3200

    # ---- predictive timing (tune these) ----
    PREDICT_ENABLED = True
    PRESS_LEAD_MS = 40          # delay from our touch write until the game reacts (Root input pipeline +
                                # game input handling). Hits too late -> raise it; too early -> lower it
                                # (steps of ~10 ms). Negative values are allowed.
    CAPTURE_AGE_MS = 8          # how old a frame already is when we receive it (frame interval + pipe)
    MIN_HOLD_MS = 70            # minimum press length for a tap
    HOLD_AFTER_ARRIVAL_MS = 60  # keep pressing this long past the predicted arrival
    REARM_MS = 90               # ignore the legacy colour trigger this long after a release
    NOTE_HALF_WIDTH = 60        # lane strip half width
    NOTE_SCAN_TOP = 120         # notes spawn below this
    NOTE_SCAN_BOTTOM = 1290     # just below the judge line
    NEW_TRACK_MARGIN = 40       # do not start tracking notes this close to the judge line
    MAX_STEP_PX = 260           # max plausible move between two frames while speed is unknown
    TRACK_TIMEOUT_MS = 600      # drop a track that has not been seen for this long
    SPEED_WINDOW = 120          # number of speed samples kept (median is used)
    MIN_SPEED_SAMPLES = 8       # samples needed before predictive mode starts

    def __init__(self, host):
        self.host = host
        config = list(host.getMusicCoordinateConfig())
        if len(config) != 9:
            config = [778, 1100, 1440, 1780, 2100, 2440, 1210, 230, -1]
        self.detect_xs = [int(v) for v in config[:6]]
        self.detect_y = int(config[6])
        self.touch_x = int(config[7])
        self.touch_ys = list(self.detect_xs) if int(config[8]) < 0 else [int(config[8])] * 6
        self.running = False
        self.state = "音游待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = self.LOOP_INTERVAL_MS
        self.track_pressed = [False] * 6
        self.last_blue = [0] * 6
        self.frame_count = 0
        self.press_count = 0
        self.touch_device = "尚未初始化"
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.last_touch_ms = 0.0
        self.last_decision_to_write_ms = 0.0
        self._reset_prediction()

    def _reset_prediction(self):
        self.tracks = [[] for _ in range(6)]        # per lane: dicts {y, t, fired}
        self.speed_samples = deque(maxlen=self.SPEED_WINDOW)
        self.speed = 0.0                            # px per ms (0 = unknown)
        self.hold_until = [0.0] * 6
        self.rearm_until = [0.0] * 6
        self.predicted_presses = 0
        self.reactive_presses = 0
        self.last_frame_t = None
        self.frame_period_ms = 16.7

    def start(self):
        self.stop()
        self.track_pressed = [False] * 6
        self.frame_count = 0
        self.press_count = 0
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.last_touch_ms = 0.0
        self.last_decision_to_write_ms = 0.0
        self._reset_prediction()
        self.diagnostic = "正在初始化 Root 多点触控"
        self.touch_device = str(self.host.initializeMultiTouch(
            self.LOGICAL_TOUCH_WIDTH, self.LOGICAL_TOUCH_HEIGHT))
        self.running = True
        self.state = "音游运行中"
        self.diagnostic = "六轨识别已启动；触控设备：" + self.touch_device
        self._log(self.diagnostic)

    # ------------------------------------------------------------------ frame capture
    def _capture(self):
        """Returns (blue[6], notes[(lane, y)], capture_ms, decode_ms)."""
        capture_notes = getattr(self.host, "captureNotes", None) if self.PREDICT_ENABLED else None
        if callable(capture_notes):
            result = capture_notes(self.detect_xs, self.detect_y, self.NOTE_HALF_WIDTH,
                                   self.NOTE_SCAN_TOP, self.NOTE_SCAN_BOTTOM)
            flat = [int(v) for v in _as_sequence(_map_get(result, "notes", []))]
            notes = [(flat[i], flat[i + 1]) for i in range(0, len(flat) - 2, 3)]
        else:
            result = self.host.captureBlueValues(self.detect_xs, self.detect_y)
            notes = []
        blue = [int(v) for v in _as_sequence(_map_get(result, "blue", []))]
        if len(blue) != 6:
            raise RuntimeError("颜色采样返回值数量不是六条轨道")
        return (blue, notes, int(_map_get(result, "captureMs", 0)),
                int(_map_get(result, "decodeMs", 0)))

    # ------------------------------------------------------------------ note tracking
    def _update_tracks(self, notes, t):
        by_lane = [[] for _ in range(6)]
        for lane, y in notes:
            if 0 <= lane < 6:
                by_lane[lane].append(y)
        for lane in range(6):
            ys = sorted(by_lane[lane])
            tracks = self.tracks[lane]
            used = set()
            for tr in sorted(tracks, key=lambda r: -r["y"]):      # lowest (oldest) note first
                dt = t - tr["t"]
                if self.speed > 0:
                    pred = tr["y"] + self.speed * dt
                    tol = max(60.0, 0.5 * self.speed * dt)
                    cands = [(abs(y - pred), j) for j, y in enumerate(ys)
                             if j not in used and abs(y - pred) <= tol]
                else:
                    cands = [(y - tr["y"], j) for j, y in enumerate(ys)
                             if j not in used and -10 <= y - tr["y"] <= self.MAX_STEP_PX]
                if not cands:
                    continue
                _, j = min(cands)
                used.add(j)
                y = ys[j]
                if 6 <= dt <= 80 and y > tr["y"]:
                    self.speed_samples.append((y - tr["y"]) / dt)
                tr["y"], tr["t"] = y, t
            for j, y in enumerate(ys):
                if j not in used and y < self.detect_y - self.NEW_TRACK_MARGIN:
                    tracks.append({"y": y, "t": t, "fired": False})
            self.tracks[lane] = [
                tr for tr in tracks
                if t - tr["t"] <= self.TRACK_TIMEOUT_MS
                and tr["y"] + self.speed * (t - tr["t"]) < self.detect_y + 150
            ]
        if len(self.speed_samples) >= self.MIN_SPEED_SAMPLES:
            ordered = sorted(self.speed_samples)
            self.speed = ordered[len(ordered) // 2]

    def _due_presses(self, now):
        """Notes whose press instant falls within the next frame: (press_at, arrival, lane, track)."""
        due = []
        if self.speed <= 0:
            return due
        horizon = max(8.0, min(25.0, self.frame_period_ms))
        for lane in range(6):
            for tr in self.tracks[lane]:
                if tr["fired"]:
                    continue
                arrival = tr["t"] + (self.detect_y - tr["y"]) / self.speed
                press_at = arrival - self.PRESS_LEAD_MS
                if press_at <= now + horizon:
                    due.append((press_at, arrival, lane, tr))
        due.sort(key=lambda item: item[0])
        return due

    @staticmethod
    def _now_ms():
        return time.perf_counter() * 1000.0

    def _spin_until(self, target_ms):
        while True:
            remaining = target_ms - self._now_ms()
            if remaining <= 0:
                return
            if remaining > 2.0:
                time.sleep(0.001)

    # ------------------------------------------------------------------ main step
    def step(self):
        if not self.running:
            return
        try:
            loop_start = time.perf_counter()
            blue, notes, self.last_capture_ms, self.last_decode_ms = self._capture()
            t = self._now_ms() - self.CAPTURE_AGE_MS            # when the frame's content was true
            if self.last_frame_t is not None:
                period = t - self.last_frame_t
                if 4.0 <= period <= 100.0:
                    self.frame_period_ms += 0.1 * (period - self.frame_period_ms)
            self.last_frame_t = t
            self.last_blue = blue
            self.frame_count += 1

            now = self._now_ms()
            desired = list(self.track_pressed)

            if self.PREDICT_ENABLED:
                self._update_tracks(notes, t)

            # 1) release: lane has been held long enough and the judge pixel is clear again.
            for lane in range(6):
                if desired[lane] and now >= self.hold_until[lane] \
                        and blue[lane] >= self.BLUE_THRESHOLD:
                    desired[lane] = False
                    self.rearm_until[lane] = now + self.REARM_MS

            # 2) predictive presses, timed precisely (never later than the frame allows).
            fired_lanes = []
            if self.PREDICT_ENABLED:
                for press_at, arrival, lane, tr in self._due_presses(now):
                    tr["fired"] = True
                    if desired[lane]:
                        # already held (e.g. hold note); extend the hold through this arrival.
                        self.hold_until[lane] = max(self.hold_until[lane],
                                                    arrival + self.HOLD_AFTER_ARRIVAL_MS)
                        continue
                    self.hold_until[lane] = max(press_at + self.MIN_HOLD_MS,
                                                arrival + self.HOLD_AFTER_ARRIVAL_MS)
                    desired[lane] = True
                    fired_lanes.append((press_at, lane))
                if fired_lanes:
                    # Wait for the earliest press instant, then write all due lanes in one batch.
                    self._spin_until(min(p for p, _ in fired_lanes))
                    self.predicted_presses += len(fired_lanes)

            # 3) legacy colour trigger: covers missed detections and keeps holds pressed.
            now = self._now_ms()
            for lane in range(6):
                if not desired[lane] and blue[lane] < self.BLUE_THRESHOLD \
                        and now >= self.rearm_until[lane]:
                    desired[lane] = True
                    self.hold_until[lane] = max(self.hold_until[lane], now + self.MIN_HOLD_MS)
                    self.reactive_presses += 1

            changed = any(desired[i] != self.track_pressed[i] for i in range(6))
            if changed:
                touch_start = time.perf_counter()
                states = [1 if v else 0 for v in desired]
                java_ms = self.host.updateTouches(states, [self.touch_x] * 6, list(self.touch_ys))
                self.last_touch_ms = float(java_ms)
                self.last_decision_to_write_ms = (time.perf_counter() - touch_start) * 1000.0
                self.press_count += sum(1 for i in range(6)
                                        if desired[i] and not self.track_pressed[i])
                self.track_pressed = desired
            else:
                self.last_touch_ms = 0.0
                self.last_decision_to_write_ms = 0.0

            loop_ms = (time.perf_counter() - loop_start) * 1000.0
            self.total_loop_ms += loop_ms
            avg_ms = self.total_loop_ms / max(1, self.frame_count)
            self.last_fps = 1000.0 / max(0.1, avg_ms)
            if self.PREDICT_ENABLED:
                mode = ("预判 速度%.2fpx/ms 预%d 补%d" % (self.speed, self.predicted_presses,
                                                         self.reactive_presses)
                        if self.speed > 0 else "预判校准中(%d/%d)" % (
                            len(self.speed_samples), self.MIN_SPEED_SAMPLES))
            else:
                mode = "反应模式"
            self.diagnostic = (
                "帧%d 触发%d %.1fFPS\n%s\n原始帧%dms CV%dms 循环%.1fms 写入%dms" %
                (self.frame_count, self.press_count, self.last_fps, mode,
                 self.last_capture_ms, self.last_decode_ms, loop_ms, int(self.last_touch_ms))
            )
        except Exception as exc:
            self._release_all()
            self.running = False
            self.state = "音游运行异常"
            self.diagnostic = str(exc)
            self._log("音游引擎异常：" + self.diagnostic)
            raise

    def stop(self):
        self.running = False
        self._release_all()
        self.state = "音游已停止"

    def _release_all(self):
        try:
            release = getattr(self.host, "releaseAllTouches", None)
            if callable(release):
                release()
            else:
                for i, pressed in enumerate(self.track_pressed):
                    if pressed:
                        self.host.touchUp(i)
        except Exception as exc:
            self._log("释放触点时发生异常：" + str(exc))
        self.track_pressed = [False] * 6

    def _log(self, message):
        try:
            self.host.log(message)
        except Exception:
            pass
