"""Six-lane color-sampling rhythm helper using Root screenshots and raw multitouch."""
from .frame import _map_get, _as_sequence


class MusicBot:
    # Values from the supplied Auto.js script. Detection uses landscape screenshot
    # coordinates; touch coordinates intentionally use its portrait-axis mapping.
    DETECT_XS = [778, 1100, 1440, 1780, 2100, 2440]
    DETECT_Y = 1210
    TOUCH_X = 230
    BLUE_THRESHOLD = 220
    LOOP_INTERVAL_MS = 5
    LOGICAL_TOUCH_WIDTH = 1440
    LOGICAL_TOUCH_HEIGHT = 3200

    def __init__(self, host):
        self.host = host
        self.running = False
        self.state = "音游待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = self.LOOP_INTERVAL_MS
        self.track_pressed = [False] * 6
        self.last_blue = [0] * 6
        self.frame_count = 0
        self.press_count = 0
        self.touch_device = "尚未初始化"
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0

    def start(self):
        self.stop()
        self.track_pressed = [False] * 6
        self.frame_count = 0
        self.press_count = 0
        self.total_loop_ms = 0.0
        self.last_capture_ms = 0
        self.last_decode_ms = 0
        self.last_fps = 0.0
        self.diagnostic = "正在初始化 Root 多点触控"
        self.touch_device = str(self.host.initializeMultiTouch(
            self.LOGICAL_TOUCH_WIDTH, self.LOGICAL_TOUCH_HEIGHT))
        self.running = True
        self.state = "音游运行中"
        self.diagnostic = "六轨识别已启动；触控设备：" + self.touch_device
        self._log(self.diagnostic)

    def step(self):
        if not self.running:
            return
        try:
            import time
            loop_start = time.perf_counter()
            result = self.host.captureBlueValues(self.DETECT_XS, self.DETECT_Y)
            self.last_capture_ms = int(_map_get(result, "captureMs", 0))
            self.last_decode_ms = int(_map_get(result, "decodeMs", 0))
            blue = list(_as_sequence(_map_get(result, "blue", [])))
            if len(blue) != 6:
                raise RuntimeError("颜色采样返回值数量不是六条轨道")
            self.last_blue = [int(v) for v in blue]
            self.frame_count += 1
            for i, value in enumerate(self.last_blue):
                should_press = value < self.BLUE_THRESHOLD
                if should_press and not self.track_pressed[i]:
                    self.host.touchDown(self.TOUCH_X, self.DETECT_XS[i], i)
                    self.track_pressed[i] = True
                    self.press_count += 1
                elif not should_press and self.track_pressed[i]:
                    self.host.touchUp(i)
                    self.track_pressed[i] = False
            loop_ms = (time.perf_counter() - loop_start) * 1000.0
            self.total_loop_ms += loop_ms
            avg_ms = self.total_loop_ms / max(1, self.frame_count)
            self.last_fps = 1000.0 / max(0.1, avg_ms)
            self.diagnostic = (
                "帧%d 触发%d %.1fFPS\n原始帧%dms CV处理%dms 循环%.1fms\n蓝值:%s" %
                (self.frame_count, self.press_count, self.last_fps,
                 self.last_capture_ms, self.last_decode_ms, loop_ms,
                 "/".join(map(str, self.last_blue)))
            )
        except Exception as exc:
            self._release_all()
            self.running = False
            self.state = "音游运行异常"
            self.diagnostic = str(exc)
            self._log("音游引擎异常：" + self.diagnostic)
            raise

    def stop(self):
        self.running = False
        self._release_all()
        self.state = "音游已停止"

    def _release_all(self):
        try:
            release = getattr(self.host, "releaseAllTouches", None)
            if callable(release):
                release()
            else:
                for i, pressed in enumerate(self.track_pressed):
                    if pressed:
                        self.host.touchUp(i)
        except Exception as exc:
            self._log("释放触点时发生异常：" + str(exc))
        self.track_pressed = [False] * 6

    def _log(self, message):
        try:
            self.host.log(message)
        except Exception:
            pass
