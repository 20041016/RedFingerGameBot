# -*- coding: utf-8 -*-
"""专辑自动完成编排层（AlbumBot）。

职责：页面识别、完成判定、选难度、开始演奏、结算判断、重试、切下一首、异常邮件提醒。
音游演奏模块（MusicBot）作为黑盒调用，只使用 start()/step()/stop() 接口，不修改其内部逻辑。

核心纪律：**所有点击之后都进入「等待下一个目标出现」状态**，
通过 OCR 轮询确认目标页面/按钮出现后才继续，绝不做固定延时盲点。

主流程（completion_mode = legend_only 为例）：
    目录页 --点击 coord_next_song--> 难度选择页
      目标难度未完成 -> 点传说 -> 等「开始演奏」-> 点击 -> 等演奏画面
          -> 黑盒演奏 -> 检出结算页 -> 完成率>=100% ? 点继续回难度页 : 点重试再来
      目标难度已完成 -> songs_completed+1 -> 点击 coord_difficulty_done_return 回目录页
    12 首全部完成 -> 邮件通知 -> 停止

运行契约（与 BotService 既有调度兼容）：
    - step() 非阻塞、可重入节拍：由外层循环反复调用；
    - state / diagnostic / loop_interval_ms / running 供 UI 与调度读取；
    - loop_interval_ms：演奏中 0（由采集链路节拍驱动），等待目标时为轮询间隔。
"""
import math
import re
import threading
import time

try:
    from .frame import Frame
    from .coordinate import CoordinateMapper
    from .album_email import EmailAlerter
    from . import album_config as _config
except ImportError:  # 独立运行/冒烟测试：同目录平铺导入
    from frame import Frame
    from coordinate import CoordinateMapper
    from album_email import EmailAlerter
    import album_config as _config

# ----------------------------- 状态名 -----------------------------
S_DETECT = "识别页面"
S_CATALOG = "目录页"
S_PLAY_ENTRY = "前往演奏"
S_REENTRY = "返回当前曲目"
S_DIFFICULTY = "难度选择页"
S_READY = "准备开始演奏"
S_PLAYING = "演奏中"
S_SETTLE = "结算判断"
S_RECOVER = "异常恢复"
S_DONE = "专辑完成"
S_HALT = "需要人工介入"

PERCENT_RE = re.compile(r"(\d+(?:\.\d+)?)\s*%")

# 异常类告警键：发邮件后按 ON_ALERT_ACTION 决定 停止/暂停/继续
ABNORMAL_ALERT_KEYS = {
    "wait_timeout", "unknown_page", "play_timeout", "settle_unreadable",
    "settle_no_select_song", "settle_no_retry", "settle_no_action",
    "reentry_no_entry", "difficulty_missing", "engine_exception",
    "retry_exceeded", "network_error", "load_failure", "popup",
}


class _Consecutive:
    """谓词连续命中 N 帧才成立（用于「某元素已消失」这类缺席判定）。"""

    def __init__(self, pred, need):
        self.pred = pred
        self.need = max(1, int(need))
        self.hit = 0

    def __call__(self, frame):
        if self.pred(frame):
            self.hit += 1
        else:
            self.hit = 0
        return self.hit >= self.need


class _SettleWatcher(threading.Thread):
    """演奏期间后台 OCR 巡检：检测结算页出现，避免在主循环同步 OCR
    卡住黑盒演奏节拍（漏按键）。只读截图，不触碰演奏引擎内部。"""

    def __init__(self, host, interval_ms, is_settlement, log=None,
                 require_absent_first=False):
        super().__init__(daemon=True, name="album-settle-watcher")
        self.host = host
        self.interval_ms = max(10, int(interval_ms))
        self.is_settlement = is_settlement
        self._log = log or (lambda m: None)
        self._stop = threading.Event()
        self.settlement_seen = False
        self.captures = 0
        self.errors = 0
        self.require_absent_first = bool(require_absent_first)
        self.saw_absent = False

    def run(self):
        while not self._stop.wait(self.interval_ms / 1000.0):
            try:
                frame = Frame.from_host(self.host.capture())
                self.captures += 1
                if self.is_settlement(frame):
                    if self.require_absent_first and not self.saw_absent:
                        continue  # 重试后的陈旧结算页，等标记消失后再承认
                    self.settlement_seen = True
                    self._log("后台巡检检测到结算页")
                    return
                self.saw_absent = True
            except Exception as exc:
                self.errors += 1
                self._log("后台结算巡检异常（忽略并继续）：" + str(exc))

    def stop(self):
        self._stop.set()


class AlbumBot:
    """专辑自动完成状态机。"""

    def __init__(self, host, music_factory=None, alerter=None,
                 overrides=None, clock_ms=None):
        self.host = host
        self.cfg = self._load_config(overrides)
        self.clock_ms = clock_ms or (lambda: int(time.monotonic() * 1000))
        self._music_factory = music_factory or self._default_music_factory
        self.alerter = alerter or EmailAlerter(self.cfg, log=self._log)
        self.music = None

        # 调度/状态接口（BotService 兼容）
        self.running = False
        self.state = "待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)

        # 任务进度
        self.songs_completed = 0
        self.current_song = 0
        self.current_difficulty = None
        self.attempts = {}          # (song, difficulty) -> 尝试次数
        self.retry_streak = 0       # 连续失败次数
        self.total_retries = 0
        self.difficulty_status = None   # {难度: bool}，难度选择页识别结果
        self._current_counted = False   # 当前曲目是否已计完成（防重复计数）
        self._reentry_gate_seen_ms = None
        self._settle_gate_pending = False

        # 等待目标机制
        self.wait_pred = None
        self.wait_desc = ""
        self.wait_next = None
        self.wait_deadline = 0
        self.wait_action = None

        # 页面识别/异常
        self.unknown_since_ms = None
        self.recover_backs = 0
        self.alert_counts = {}

        self.mapper = None
        self.play_started_ms = 0
        self.next_settle_check = 0
        self.watcher = None

    # ================================================================
    # 生命周期
    # ================================================================

    def start(self):
        # 启动检查（仅此一次）：全屏识别目录门词。
        # 识别到 → 允许运行；未识别到 → 直接停止。
        gate = self.cfg.CATALOG_GATE_WORD
        try:
            frame = Frame.from_host(self.host.capture())
        except Exception as exc:
            self._log("启动检查截图失败：" + str(exc))
            frame = None
        if frame is None or not frame.has(gate):
            self.running = False
            self.state = "已停止"
            self.diagnostic = "启动检查未通过：未识别到「%s」，已停止" % gate
            self._log(self.diagnostic)
            return
        self._log("启动检查通过：已识别到「%s」" % gate)
        self.running = True
        self.state = S_DETECT
        self.diagnostic = "开始识别当前页面"
        self.songs_completed = 0
        self.current_song = 0
        self.current_difficulty = None
        self.attempts = {}
        self.retry_streak = 0
        self.total_retries = 0
        self.difficulty_status = None
        self._current_counted = False
        self._reentry_gate_seen_ms = None
        self.unknown_since_ms = None
        self.recover_backs = 0
        self._clear_wait()
        self._log("专辑挂机启动：mode=%s 歌曲数=%d 目标完成率=%.1f%%"
                  % (self.cfg.COMPLETION_MODE, self.cfg.ALBUM_SONG_COUNT,
                     self.cfg.TARGET_COMPLETION_RATE))

    def stop(self):
        self.running = False
        self._safe_music_stop()
        self.state = "已暂停"
        self.diagnostic = "已停止"
        self._log("专辑挂机已暂停")

    # ================================================================
    # 主节拍（非阻塞）
    # ================================================================

    def step(self):
        if not self.running:
            return
        try:
            if self.state == S_PLAYING:
                self._play_tick()
                return
            frame = Frame.from_host(self.host.capture())
            self.mapper = CoordinateMapper(frame.width, frame.height)
            now = self.clock_ms()
            if self.wait_pred is not None:
                self._wait_tick(frame, now)
                return
            self._decide(frame, now)
        except Exception as exc:
            self._on_exception(exc)

    # ================================================================
    # 等待目标机制：点击后唯一前进方式
    # ================================================================

    def _expect(self, next_state, pred, desc, timeout_ms, action=None):
        self.wait_pred = pred
        self.wait_desc = desc
        self.wait_next = next_state
        self.wait_action = action
        self.wait_deadline = self.clock_ms() + int(timeout_ms)
        self.state = "等待目标：" + desc
        self.diagnostic = "点击后等待目标出现：" + desc
        self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)

    def _clear_wait(self):
        self.wait_pred = None
        self.wait_desc = ""
        self.wait_next = None
        self.wait_action = None

    def _wait_tick(self, frame, now):
        if self.wait_pred(frame):
            desc, nxt, action = self.wait_desc, self.wait_next, self.wait_action
            self._clear_wait()
            self._log("等待目标已出现：" + desc)
            if action is not None:
                action()
            self.state = nxt
            if nxt != S_PLAYING:
                self.diagnostic = "目标已出现：" + desc
            return
        if now >= self.wait_deadline:
            desc = self.wait_desc
            self._clear_wait()
            self._alert("wait_timeout", "目标等待超时",
                        "等待「%s」超过 %d ms 未出现，进入异常恢复。当前进度：完成 %d/%d 首。"
                        % (desc, int(self.cfg.TARGET_WAIT_TIMEOUT_MS),
                           self.songs_completed, self.cfg.ALBUM_SONG_COUNT))
            self._goto_recover()

    def _goto_recover(self):
        self.state = S_RECOVER
        self.diagnostic = "异常恢复：准备按返回键重新识别页面"
        self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)

    # ================================================================
    # 页面识别
    # ================================================================

    def _detect_page(self, frame):
        # 判定优先级：结算页 > 难度选择页 > 目录页（关键词可能交叉）
        if self._any_word(frame, self.cfg.KEYWORDS_SETTLEMENT):
            return "settlement"
        if self._any_word(frame, self.cfg.KEYWORDS_DIFFICULTY):
            return "difficulty"
        if self._any_word(frame, self.cfg.KEYWORDS_CATALOG):
            return "catalog"
        return None

    @staticmethod
    def _any_word(frame, words):
        return any(frame.has(w) for w in words)

    def _is_settlement(self, frame):
        # 结算页判定依据：全屏识别「演奏完成率」
        return self._any_word(frame, self.cfg.KEYWORDS_SETTLEMENT)

    # ================================================================
    # 状态机分发
    # ================================================================

    def _decide(self, frame, now):
        if self.state == S_DETECT:
            self._decide_detect(frame, now)
        elif self.state == S_CATALOG:
            self._decide_catalog(frame, now)
        elif self.state == S_PLAY_ENTRY:
            self._decide_play_entry(frame, now)
        elif self.state == S_REENTRY:
            self._decide_reentry(frame, now)
        elif self.state == S_DIFFICULTY:
            self._decide_difficulty(frame, now)
        elif self.state == S_READY:
            self._decide_ready(frame, now)
        elif self.state == S_SETTLE:
            self._decide_settle(frame, now)
        elif self.state == S_RECOVER:
            self._decide_recover(frame, now)
        else:
            # S_DONE / S_HALT：保持现状
            self.loop_interval_ms = 1000

    # ---------------------------- 识别 ----------------------------

    def _decide_detect(self, frame, now):
        # 弹窗 / 网络异常 / 加载失败 → 异常邮件提醒（优先于页面路由）
        if self._handle_exception_frame(frame, now):
            return
        page = self._detect_page(frame)
        if page == "settlement":
            self.unknown_since_ms = None
            self._enter(S_SETTLE)
            return
        if page == "difficulty":
            self.unknown_since_ms = None
            self._enter(S_DIFFICULTY)
            return
        # 单曲流程入口页优先于目录页判定：页面上有「前往演奏」时先处理入口，
        # 防止把“返回当前曲目”的页面误判为目录页而误点「下一首」跳过当前曲目。
        if self._any_word(frame, self.cfg.PLAY_ENTRY_WORDS):
            self.unknown_since_ms = None
            self._enter(S_PLAY_ENTRY)
            return
        if page == "catalog":
            self.unknown_since_ms = None
            self._enter(S_CATALOG)
            return
        # 未知页面（其他非预期界面）：计时后邮件告警
        if self.unknown_since_ms is None:
            self.unknown_since_ms = now
            self.diagnostic = "未识别到已知页面，持续观察中"
            return
        if now - self.unknown_since_ms >= int(self.cfg.UNKNOWN_PAGE_TIMEOUT_MS):
            self.unknown_since_ms = None
            self._alert("unknown_page", "页面无法识别",
                        "连续 %d 秒未识别到目录页/难度选择页/结算页，进入异常恢复。"
                        % (int(self.cfg.UNKNOWN_PAGE_TIMEOUT_MS) // 1000))
            self._goto_recover()

    # ---------------------------- 目录页 ----------------------------

    def _decide_catalog(self, frame, now):
        if self.songs_completed >= int(self.cfg.ALBUM_SONG_COUNT):
            self._finish_album()
            return
        # 目录门检查：点击 coord_next_song 前必须全屏识别到目录门词。
        # 识别到 → 确认回到目录，点击下一首；未识别到 → 继续等待，不点击，不报错。
        gate = self.cfg.CATALOG_GATE_WORD
        if not frame.has(gate):
            # 未识别到「千音雅集」属于等待：不发邮件、不点击、不报错（暂定无限等待）。
            # 但弹窗/网络异常/加载失败属于异常，仍需邮件提醒。
            if self._handle_exception_frame(frame, now, allow_recover=False,
                                           next_state=S_CATALOG):
                return
            self.diagnostic = "等待「%s」确认目录（无限等待，不点击）" % gate
            self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)
            return
        self.current_song = self.songs_completed + 1
        self._current_counted = False
        x, y = self.cfg.COORD_NEXT_SONG
        self._tap_ref(x, y)
        self._log("目录页：点击「下一首」坐标 (%d, %d)，进入第 %d 首"
                  % (x, y, self.current_song))
        self._expect(S_PLAY_ENTRY,
                     lambda f: (self._any_word(f, self.cfg.PLAY_ENTRY_WORDS)
                                or self._detect_page(f) == "difficulty"),
                     "「前往演奏」按钮或难度选择页出现",
                     int(self.cfg.TARGET_WAIT_TIMEOUT_MS))

    # ---------------------------- 单曲流程入口：前往演奏 ----------------------------

    def _decide_play_entry(self, frame, now):
        # 单曲流程从点击「前往演奏」开始；点击后等待难度选择页出现。
        # 兼容布局：点「下一首」直达难度选择页时，无需再点「前往演奏」。
        if self._detect_page(frame) == "difficulty":
            self.unknown_since_ms = None
            self._enter(S_DIFFICULTY)
            return
        item = self._find_first(frame, self.cfg.PLAY_ENTRY_WORDS)
        if item is None:
            self._enter(S_DETECT)
            return
        self._tap_screen(item.center_x, item.center_y)
        self._log("第 %d 首单曲流程开始：点击「%s」"
                  % (self.current_song, self.cfg.PLAY_ENTRY_WORDS[0]))
        self._expect(S_DIFFICULTY,
                     lambda f: self._detect_page(f) == "difficulty",
                     "难度选择页出现",
                     int(self.cfg.TARGET_WAIT_TIMEOUT_MS))

    # ---------------------------- 返回当前曲目（all_difficulties 补难度循环） ----------------

    def _decide_reentry(self, frame, now):
        # all_difficulties 单曲循环：结算达标点「选择曲目」后，返回的仍是当前歌曲。
        #   1. 等待「千音雅集」（暂定无限等待，不点击，不报错）
        #   2. 点击「前往演奏」→ 等难度选择页 → 重新识别四个难度，继续补难度
        gate = self.cfg.CATALOG_GATE_WORD
        if not frame.has(gate):
            # 同目录门语义：未识别到「千音雅集」只等待不发邮件；异常类除外。
            if self._handle_exception_frame(frame, now, allow_recover=False,
                                           next_state=S_REENTRY):
                return
            self._reentry_gate_seen_ms = None
            self.diagnostic = "返回当前曲目：等待「%s」出现（无限等待，不点击）" % gate
            self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)
            return
        entry_word = self.cfg.PLAY_ENTRY_WORDS[0]
        item = self._find_first(frame, self.cfg.PLAY_ENTRY_WORDS)
        if item is None:
            if self._reentry_gate_seen_ms is None:
                self._reentry_gate_seen_ms = now
                self.diagnostic = "已识别「%s」，等待「%s」按钮出现" % (gate, entry_word)
            elif now - self._reentry_gate_seen_ms >= int(self.cfg.TARGET_WAIT_TIMEOUT_MS):
                self._reentry_gate_seen_ms = None
                self._alert("reentry_no_entry", "未找到「前往演奏」按钮",
                            "第 %d 首返回当前曲目后，「%s」已出现但未找到「%s」按钮，"
                            "进入异常恢复。" % (self.current_song, gate, entry_word))
                self._goto_recover()
            self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)
            return
        self._reentry_gate_seen_ms = None
        self._tap_screen(item.center_x, item.center_y)
        self._log("返回当前曲目：点击「%s」，回到难度选择页继续补难度" % entry_word)
        self._expect(S_DIFFICULTY,
                     lambda f: self._detect_page(f) == "difficulty",
                     "难度选择页出现",
                     int(self.cfg.TARGET_WAIT_TIMEOUT_MS))

    # ---------------------------- 难度选择页 ----------------------------

    def _decide_difficulty(self, frame, now):
        status = self._parse_difficulty_status(frame)
        if status != self.difficulty_status:
            self.difficulty_status = status
            self._log("难度状态识别：" + self._format_status(status))
        targets = self._target_difficulties()
        pending = [d for d in self.cfg.DIFFICULTY_PRIORITY
                   if d in targets and not status[d]]
        self.diagnostic = "第%d首 %s" % (self.current_song, self._format_status(status))

        if not pending:
            # 当前曲目全部完成（legend_only：传说已是大音天籁；
            # all_difficulties：四个难度全部达成）：
            #   1. 点击 coord_difficulty_done_return 返回目录
            #   2. 等待「千音雅集」（目录页处理，暂定无限等待）
            #   3. 点击 coord_next_song
            self._count_song("目标难度已达成（大音天籁）")
            x, y = self.cfg.COORD_DIFFICULTY_DONE_RETURN
            self._tap_ref(x, y)
            self._log("难度选择页：目标已完成，点击返回目录坐标 (%d, %d)，随后等待「%s」并点击下一首"
                      % (x, y, self.cfg.CATALOG_GATE_WORD))
            self._enter(S_CATALOG)  # 等待「千音雅集」后点击 coord_next_song
            return

        difficulty = pending[0]  # 补难度优先级：传说 > 大师 > 困难 > 普通
        item = self._find_difficulty_item(frame, difficulty)
        if item is None:
            self._alert("difficulty_missing", "目标难度未显示",
                        "第 %d 首难度选择页未找到「%s」入口，进入异常恢复。"
                        % (self.current_song, difficulty))
            self._goto_recover()
            return
        self.current_difficulty = difficulty
        self._tap_screen(item.center_x, item.center_y)
        self._log("第 %d 首：选择难度「%s」" % (self.current_song, difficulty))
        self._expect(S_READY,
                     lambda f: self._any_word(f, self.cfg.PLAY_START_WORDS),
                     "「开始演奏」按钮出现",
                     int(self.cfg.TARGET_WAIT_TIMEOUT_MS))

    # ---------------------------- 开始演奏 ----------------------------

    def _decide_ready(self, frame, now):
        item = self._find_first(frame, self.cfg.PLAY_START_WORDS)
        if item is None:
            # 目标按钮消失视为页面已推进，交回识别路由
            self._enter(S_DETECT)
            return
        self._tap_screen(item.center_x, item.center_y)
        key = (self.current_song, self.current_difficulty)
        self.attempts[key] = self.attempts.get(key, 0) + 1
        self._log("第 %d 首「%s」第 %d 次演奏开始"
                  % (self.current_song, self.current_difficulty, self.attempts[key]))
        self._expect(
            S_PLAYING,
            _Consecutive(lambda f: not self._any_word(f, self.cfg.PLAY_START_WORDS), 2),
            "演奏画面出现（开始按钮消失）",
            int(self.cfg.PLAY_CONFIRM_TIMEOUT_MS),
            action=self._start_music)

    def _start_music(self, fresh_settlement_required=False):
        """调用打歌模块（黑盒）。

        fresh_settlement_required=True（重试后直接调用）时，结算巡检先等
        「演奏完成率」消失一帧再承认新结算页，防止把点击前的陈旧结算页
        误判为本局结果。
        """
        self.music = self._music_factory(self.host)
        self.music.start()  # 黑盒：只调用公共接口
        self.play_started_ms = self.clock_ms()
        self.next_settle_check = self.play_started_ms + int(self.cfg.SETTLE_CHECK_INTERVAL_MS)
        self.state = S_PLAYING
        self.diagnostic = "黑盒演奏引擎已启动"
        self.loop_interval_ms = 0
        self._settle_gate_pending = bool(fresh_settlement_required)
        mode = str(getattr(self.cfg, "SETTLE_CHECK_MODE", "background"))
        if mode == "background":
            self.watcher = _SettleWatcher(
                self.host, int(self.cfg.SETTLE_CHECK_INTERVAL_MS),
                self._is_settlement, log=self._log,
                require_absent_first=self._settle_gate_pending)
            self.watcher.start()
        self._log("黑盒演奏引擎启动：%s（结算巡检=%s）" % (self.current_difficulty, mode))

    # ---------------------------- 演奏中（黑盒） ----------------------------

    def _play_tick(self):
        self.music.step()  # 黑盒步进
        now = self.clock_ms()
        self.diagnostic = "演奏中 第%d首 %s（第 %d 次尝试）" % (
            self.current_song, self.current_difficulty,
            self.attempts.get((self.current_song, self.current_difficulty), 1))
        if now - self.play_started_ms > int(self.cfg.PLAY_TIMEOUT_MS):
            self._safe_music_stop()
            self._alert("play_timeout", "演奏超时",
                        "第 %d 首「%s」演奏超过 %d 秒未出现结算，停止引擎并进入异常恢复。"
                        % (self.current_song, self.current_difficulty,
                           int(self.cfg.PLAY_TIMEOUT_MS) // 1000))
            self._goto_recover()
            return
        mode = str(getattr(self.cfg, "SETTLE_CHECK_MODE", "background"))
        if mode == "off":
            return
        if mode == "background":
            if self.watcher is not None and self.watcher.settlement_seen:
                self._safe_music_stop()
                self._enter(S_SETTLE)
                self.diagnostic = "检测到结算页，停止演奏引擎，进入结算判断"
            return
        # inline：主循环内同步巡检（OCR 期间演奏节拍会停顿，仅作兑底）
        check_interval = int(self.cfg.SETTLE_CHECK_INTERVAL_MS)
        if check_interval > 0 and now >= self.next_settle_check:
            self.next_settle_check = now + check_interval
            frame = Frame.from_host(self.host.capture())
            self.mapper = CoordinateMapper(frame.width, frame.height)
            if self._is_settlement(frame):
                if self._settle_gate_pending:
                    # 重试点击后的陈旧结算页，忽略；等标记消失一帧后再承认新结算
                    return
                self._safe_music_stop()
                self._enter(S_SETTLE)
                self.diagnostic = "检测到结算页，停止演奏引擎，进入结算判断"
            else:
                self._settle_gate_pending = False

    # ---------------------------- 结算判断 ----------------------------

    def _decide_settle(self, frame, now):
        """结算判断与重试循环（本层不含选曲/切歌）。"""
        verdict, rate = self._judge_settlement(frame)
        if verdict == "无法识别":
            self._alert("settle_unreadable", "演奏完成率无法识别",
                        "第 %d 首「%s」结算页未识别到「演奏完成率」数值，"
                        "按未达标处理并直接重试。"
                        % (self.current_song, self.current_difficulty))
            if not self.running:
                return
            verdict, rate = "重试", 0.0
        if verdict == "完成":
            self._log("结算判定：完成（演奏完成率 %.1f%%）" % rate)
            self.retry_streak = 0
            self._on_settlement_complete(frame, rate)  # 交给第 4/5 部分决定下一步
            return

        # 未达 100.0%：不查温度，直接点「再次演奏」→ 直接调用打歌模块
        # （不重新选曲、不重新选难度），打完再次等待「演奏完成率」。无限重试。
        key = (self.current_song, self.current_difficulty)
        self.total_retries += 1
        self.retry_streak += 1
        attempt = self.attempts.get(key, 1)
        self._log("结算判定：未达标（演奏完成率 %.1f%% < 100.0%%），直接重试"
                  "（第 %d 次尝试，连续未达标 %d）"
                  % (rate, attempt, self.retry_streak))
        max_retry = self.cfg.MAX_RETRY
        if max_retry is not None and attempt >= int(max_retry):
            self._alert("retry_exceeded", "重试次数超限，需要人工介入",
                        "第 %d 首「%s」已尝试 %d 次仍未达到 %.1f%%，停止挂机等待人工处理。"
                        % (self.current_song, self.current_difficulty,
                           attempt, self.cfg.TARGET_COMPLETION_RATE),
                        force=True)
            self.state = S_HALT
            self.diagnostic = "重试次数超限，需要人工介入"
            self.loop_interval_ms = 1000
            return
        every = int(self.cfg.RETRY_ALERT_EVERY)
        if every > 0 and self.retry_streak % every == 0:
            self._alert("retry_streak", "连续失败提醒",
                        "第 %d 首「%s」连续 %d 次未达标（最新演奏完成率 %.1f%%），"
                        "仍在自动重试。"
                        % (self.current_song, self.current_difficulty,
                           self.retry_streak, rate))
        retry_item = self._find_first(frame, self.cfg.SETTLEMENT_RETRY_WORDS)
        if retry_item is None:
            self._alert("settle_no_retry", "结算页缺少「再次演奏」按钮",
                        "第 %d 首「%s」结算未达标但未找到「%s」，进入异常恢复。"
                        % (self.current_song, self.current_difficulty,
                           self.cfg.SETTLEMENT_RETRY_WORDS[0]))
            self._goto_recover()
            return
        self._tap_screen(retry_item.center_x, retry_item.center_y)
        self._log("点击「%s」，直接调用打歌模块（不重新选曲、不重新选难度）"
                  % self.cfg.SETTLEMENT_RETRY_WORDS[0])
        self._start_music(fresh_settlement_required=True)

    def _on_settlement_complete(self, frame, rate):
        """结算判定「完成」后：交第 4/5 部分（选曲/切歌）决定下一步。"""
        item = self._find_first(frame, self.cfg.SETTLEMENT_SELECT_SONG_WORDS)
        if item is None:
            self._alert("settle_no_select_song", "结算页缺少「选择曲目」按钮",
                        "第 %d 首结算达标但未找到「%s」，进入异常恢复。"
                        % (self.current_song,
                           self.cfg.SETTLEMENT_SELECT_SONG_WORDS[0]))
            self._goto_recover()
            return
        self._tap_screen(item.center_x, item.center_y)
        if str(self.cfg.COMPLETION_MODE) == "legend_only":
            # 第 4 部分（legend_only）：点击「选择曲目」→ 等待「千音雅集」→ 点 coord_next_song
            self._count_song("结算 %.1f%% 达标" % rate)
            self._log("结算达标：点击「%s」，回目录等待「%s」并点击下一首"
                      % (self.cfg.SETTLEMENT_SELECT_SONG_WORDS[0],
                         self.cfg.CATALOG_GATE_WORD))
            self._enter(S_CATALOG)  # 等待「千音雅集」后点击 coord_next_song
        else:
            # 第 5 部分（all_difficulties）：点击「选择曲目」→ 返回当前曲目，不切下一首
            # → 等待「千音雅集」→ 重新点「前往演奏」→ 回难度页继续补难度
            self._log("结算达标：点击「%s」返回当前曲目（不切下一首），"
                      "等待「%s」后重新点「%s」"
                      % (self.cfg.SETTLEMENT_SELECT_SONG_WORDS[0],
                         self.cfg.CATALOG_GATE_WORD,
                         self.cfg.PLAY_ENTRY_WORDS[0]))
            self._enter(S_REENTRY)

    # ---------------------------- 异常恢复 ----------------------------

    def _decide_recover(self, frame, now):
        max_backs = int(self.cfg.RECOVERY_MAX_BACKS)
        if self.recover_backs < max_backs:
            self.recover_backs += 1
            self._press_back()
            self._log("异常恢复：按返回键（%d/%d）" % (self.recover_backs, max_backs))
        else:
            self.recover_backs = 0  # 无限重试：轮转等待一轮后继续尝试
        self._expect(S_DETECT,
                     lambda f: self._detect_page(f) is not None,
                     "任一已知页面出现",
                     int(self.cfg.RECOVERY_WAIT_TIMEOUT_MS),
                     action=lambda: setattr(self, "recover_backs", 0))

    # ================================================================
    # 解析
    # ================================================================

    def _target_difficulties(self):
        if self.cfg.COMPLETION_MODE == "all_difficulties":
            return tuple(self.cfg.DIFFICULTY_PRIORITY)
        return ("传说",)  # legend_only

    @staticmethod
    def _rate_done(rate):
        return rate is not None and rate >= 100.0 - 1e-6

    def _parse_difficulty_status(self, frame):
        """难度选择页全屏识别「大音天籁」，按屏幕位置映射到四个难度评级。

        返回 difficulty_status = {难度: bool}：屏幕上每个「大音天籁」映射到
        距离最近的难度锚点（超过 DIFFICULTY_MATCH_MAX_DIST 的忽略）。
        """
        word = self.cfg.DIFFICULTY_STATUS_WORD
        anchors = self.cfg.DIFFICULTY_ANCHORS
        max_dist = float(self.cfg.DIFFICULTY_MATCH_MAX_DIST)
        status = {d: False for d in self.cfg.DIFFICULTY_PRIORITY}
        for t in frame.texts:
            if word not in (t.text or ""):
                continue
            best_name, best_dist = None, None
            for name, (ax, ay) in anchors.items():
                sx, sy = self.mapper.to_screen(ax, ay)
                dist = math.hypot(t.center_x - sx, t.center_y - sy)
                if best_dist is None or dist < best_dist:
                    best_name, best_dist = name, dist
            if best_name is not None and best_dist <= max_dist:
                status[best_name] = True
            else:
                self._log("忽略位置不匹配的「%s」：(%.0f, %.0f)，最近锚点距离 %.0f"
                          % (word, t.center_x, t.center_y,
                             best_dist if best_dist is not None else -1))
        return status

    @staticmethod
    def _format_status(status):
        order = ("普通", "困难", "大师", "传说")
        return "difficulty_status = {" + ", ".join(
            "%s: %s" % (d, "True" if status.get(d) else "False") for d in order) + "}"

    def _find_difficulty_item(self, frame, name):
        for kw in self.cfg.DIFFICULTY_KEYWORDS.get(name, (name,)):
            item = frame.find(kw)
            if item is not None:
                return item
        return None

    def _rate_near(self, frame, item):
        best = None
        rx = int(self.cfg.RATE_SEARCH_RADIUS_X)
        ry = int(self.cfg.RATE_SEARCH_RADIUS_Y)
        for t in frame.texts:
            if t is item:
                continue
            dy = abs(t.center_y - item.center_y)
            dx = abs(t.center_x - item.center_x)
            if dy > ry or dx > rx:
                continue
            m = PERCENT_RE.search(t.text or "")
            if m:
                score = (dy, dx)
                if best is None or score < best[0]:
                    best = (score, float(m.group(1)))
        return best[1] if best else None

    def _parse_settlement_rate(self, frame):
        """全屏识别「演奏完成率」并读取数值；无法解析返回 None。"""
        marker = self._find_first(frame, self.cfg.SETTLEMENT_RATE_WORDS)
        if marker is None:
            return None
        rate = self._rate_near(frame, marker)
        if rate is None:
            rate = self._percent_fallback(frame)
        return rate

    def _judge_settlement(self, frame):
        """结算判断：全屏识别「演奏完成率」，目标完成率固定 100.0%。

        返回 (判定, 完成率)，判定 ∈ {"完成", "重试", "无法识别"}。
        达到 100.0% 返回「完成」，后续步骤交由第 4/5 部分（选曲/切歌）决定。
        """
        rate = self._parse_settlement_rate(frame)
        if rate is None:
            return "无法识别", None
        if rate >= float(self.cfg.TARGET_COMPLETION_RATE) - 1e-6:
            return "完成", rate
        return "重试", rate

    def _percent_fallback(self, frame):
        best = None
        for t in frame.texts:
            m = PERCENT_RE.search(t.text or "")
            if m and (best is None or float(m.group(1)) > best):
                best = float(m.group(1))
        return best

    @staticmethod
    def _find_first(frame, words):
        for w in words:
            item = frame.find(w)
            if item is not None:
                return item
        return None

    # ================================================================
    # 动作
    # ================================================================

    def _tap_screen(self, x, y):
        x = max(0, min(self.mapper.screen_width - 1, round(x)))
        y = max(0, min(self.mapper.screen_height - 1, round(y)))
        self.host.tap(x, y)

    def _tap_ref(self, x, y):
        self.mapper.tap(self.host, x, y)

    def _press_back(self):
        press = getattr(self.host, "pressBack", None)
        if callable(press):
            press()

    def _safe_music_stop(self):
        if self.watcher is not None:
            try:
                self.watcher.stop()
            except Exception:
                pass
            self.watcher = None
        if self.music is not None:
            try:
                self.music.stop()
            except Exception as exc:
                self._log("停止演奏引擎异常：" + str(exc))
        self.music = None

    @staticmethod
    def _default_music_factory(host):
        try:
            from .music_bot import MusicBot
        except ImportError:
            from music_bot import MusicBot
        return MusicBot(host)

    # ================================================================
    # 收尾与告警
    # ================================================================

    def _finish_album(self):
        self.state = S_DONE
        self.diagnostic = "专辑 %d 首全部完成" % self.cfg.ALBUM_SONG_COUNT
        self.running = False
        self._log("专辑完成：%d/%d 首" % (self.songs_completed, self.cfg.ALBUM_SONG_COUNT))
        self._alert("album_done", "专辑完成",
                    "全部 %d 首目标难度已完成，目标完成率 %.1f%%。\n累计重试次数：%d"
                    % (self.cfg.ALBUM_SONG_COUNT,
                       self.cfg.TARGET_COMPLETION_RATE, self.total_retries),
                    force=True)

    def _count_song(self, detail):
        """单曲完成计数（幂等：同一曲目重复进入不重复计数）。"""
        if self._current_counted:
            self._log("第 %d 首此前已计完成，跳过重复计数" % self.current_song)
            return
        self._current_counted = True
        self.songs_completed += 1
        self.retry_streak = 0
        self._log("第 %d 首%s，累计 %d/%d"
                  % (self.current_song, detail, self.songs_completed,
                     self.cfg.ALBUM_SONG_COUNT))
        self._alert("song_done", "单曲完成 %d/%d" % (self.songs_completed,
                                                    self.cfg.ALBUM_SONG_COUNT),
                    "第 %d 首%s。\n尝试统计：%s"
                    % (self.current_song, detail,
                       self._attempts_summary(self.current_song)),
                    force=False)

    def _on_exception(self, exc):
        self._safe_music_stop()
        self._clear_wait()
        self._log("专辑引擎异常：" + str(exc))
        self._alert("engine_exception", "引擎异常",
                    "状态 %s 异常：%s\n当前进度：%d/%d 首。进入异常恢复。"
                    % (self.state, str(exc), self.songs_completed,
                       self.cfg.ALBUM_SONG_COUNT))
        self._goto_recover()

    def _handle_exception_frame(self, frame, now, allow_recover=True, next_state=None):
        """弹窗 / 网络异常 / 加载失败 → 异常邮件提醒，并尽量点掉弹窗。

        返回 True 表示本帧已按异常处理。allow_recover=False（目录等待场景）：
        无弹窗按钮可点时不按返回键，继续等待。"""
        checks = (
            ("network_error", "网络异常", self.cfg.EXCEPTION_NETWORK_WORDS),
            ("load_failure", "加载失败", self.cfg.EXCEPTION_LOAD_WORDS),
            ("popup", "弹窗", self.cfg.POPUP_WORDS),
        )
        for key, label, words in checks:
            word = next((w for w in words if frame.has(w)), None)
            if word is None:
                continue
            self._alert(key, "%s提醒" % label,
                        "检测到%s「%s」（状态：%s），已发送异常提醒。"
                        % (label, word, self.state), abnormal=True)
            if not self.running:
                return True
            dismiss = self._find_first(frame, self.cfg.POPUP_WORDS)
            if dismiss is not None:
                self._tap_screen(dismiss.center_x, dismiss.center_y)
                self._log("%s弹窗兜底点击：%s" % (label, dismiss.text))
                self._expect(next_state or S_DETECT,
                             _Consecutive(lambda f, w=dismiss.text: not f.has(w), 2),
                             "弹窗「%s」消失" % dismiss.text,
                             int(self.cfg.TARGET_WAIT_TIMEOUT_MS))
            elif allow_recover:
                self._goto_recover()
            return True
        return False

    def _alert(self, key, subject, body, force=False, abnormal=False):
        self.alert_counts[key] = self.alert_counts.get(key, 0) + 1
        try:
            self.alerter.send(key, subject, body, force=force)
        except Exception as exc:
            self._log("告警发送异常：" + str(exc))
        if abnormal or key in ABNORMAL_ALERT_KEYS:
            self._apply_alert_action(subject)

    def _apply_alert_action(self, subject):
        """异常邮件后的动作【待确认】：continue / pause / stop。"""
        action = str(getattr(self.cfg, "ON_ALERT_ACTION", "continue")).lower()
        if action == "stop":
            self._safe_music_stop()
            self.running = False
            self.state = "已停止"
            self.diagnostic = "异常告警后停止：" + subject
            self._log("ON_ALERT_ACTION=stop：" + subject)
        elif action == "pause":
            self._safe_music_stop()
            self.running = False
            self.state = "异常暂停"
            self.diagnostic = "异常告警后暂停，等待人工重启：" + subject
            self._log("ON_ALERT_ACTION=pause：" + subject)
        else:
            self._log("ON_ALERT_ACTION=continue：保持当前流程继续")

    def _attempts_summary(self, song):
        parts = []
        for d in self.cfg.DIFFICULTY_PRIORITY:
            n = self.attempts.get((song, d))
            if n:
                parts.append("%s×%d" % (d, n))
        return "，".join(parts) if parts else "无需补难度"

    def _enter(self, state):
        if self.state != state:
            self.state = state
            self._log("状态：" + state)
        self.loop_interval_ms = int(self.cfg.POLL_INTERVAL_MS)

    def _log(self, msg):
        logger = getattr(self.host, "log", None)
        if callable(logger):
            logger(msg)

    # ================================================================
    # 配置装载
    # ================================================================

    @staticmethod
    def _load_config(overrides):
        from types import SimpleNamespace
        values = {}
        for name in dir(_config):
            if name.isupper():
                values[name] = getattr(_config, name)
        if overrides:
            values.update(overrides)
        return SimpleNamespace(**values)
