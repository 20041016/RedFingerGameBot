"""千音雅集专辑补分自动化（对应《音游专辑自动脚本需求规格》）。

职责：页面识别、完成判定、选难度、开始演奏、结算判断、重试、切下一首、异常邮件提醒。
打歌部分作为黑盒调用已有打歌模块 music_bot.MusicBot（start / step / stop），不改其内部逻辑。

屏幕文字识别完全复用项目现有方案：
    RootHost.capture()（Root screencap + ML Kit 中文 OCR）→ frame.Frame（文本行 + 边界框）。
结算页在打歌期间通过 RootHost 的后台 OCR 监视线程（getOcrWatchFrame）判断，
避免把 OCR 耗时压进六轨 5ms 采样循环；监视线程不可用时回退为回合内直采。

所有点击采用“等待下一个目标出现”机制：先 OCR 确认目标文字/目标页面出现才点击，
不做固定延时盲点；固定坐标点击（切下一首、难度完成返回）由用户在悬浮窗坐标设置里配置。

配置项（host.getAlbumConfig()）：
    completion_mode   legend_only | all_difficulties
    on_exception      stop（默认，邮件后停止）| continue/wait/retry（邮件后持续等待重试）
    next_x / next_y   coord_next_song 切下一首固定坐标（1280×720 参考系，同游戏挂机坐标）
    return_x / return_y  coord_difficulty_done_return 难度完成返回目录固定坐标
    difficulty_order  难度按屏幕位置从上到下的顺序，默认“普通,困难,大师,传说”
    difficulty_slots  无 OCR 难度名时的位置兜底（屏幅比例 x,y 四组，分号分隔）
    catalog_wait_max_ms  切下一首前目录检查最长等待，0 = 无限等待（需求 4.2 默认）
"""
import re
import time

from .coordinate import CoordinateMapper
from .frame import Frame, _map_get
from .music_bot import MusicBot

# ---- 需求固定参数（需求 3：这三项不可配置）----
ALBUM_SONG_COUNT = 12                 # album_song_count 固定 12
TARGET_COMPLETION_RATE = 100.0        # target_completion_rate 固定 100.0%
MAX_RETRY = None                      # max_retry：无限重试

# 补难度优先级（需求 3）
DIFFICULTY_PRIORITY = ("传说", "大师", "困难", "普通")

# 页面文案（需求 4/6/7 的全屏识别目标）
CATALOG_MARKER = "千音雅集"
PLAY_GO_TEXT = "前往演奏"
PLAY_START_TEXT = "开始演奏"
RATING_TEXT = "大音天籁"
SETTLE_LABEL = "演奏完成率"
RETRY_TEXT = "再次演奏"
NEXT_SELECT_TEXT = "选择曲目"

# 非预期界面（需求 8）：显式错误文案 / 疑似弹窗文案
ANOMALY_TEXTS = (
    "网络异常", "网络错误", "加载失败", "加载错误", "连接失败", "连接超时",
    "请求超时", "下载失败", "更新失败", "发生错误", "未知错误", "服务器错误",
)
POPUP_TEXTS = ("确定", "继续", "重试", "取消", "放弃", "忽略")
# 正常页面标记：出现任一标记即认为不是“无目标弹窗”
PAGE_MARKERS = (
    CATALOG_MARKER, PLAY_GO_TEXT, PLAY_START_TEXT, RATING_TEXT,
    SETTLE_LABEL, RETRY_TEXT, NEXT_SELECT_TEXT,
) + DIFFICULTY_PRIORITY

# 等待与轮询节奏（“等待下一个目标出现”机制，不做固定延时盲点）
OCR_INTERVAL_MS = 150          # 等待页面时两次 OCR 之间的间隔
PLAY_INTERVAL_MS = 5           # 演奏中打歌模块步进节奏
WATCH_INTERVAL_MS = 800        # 打歌期间后台 OCR 监视线程的截图/识别间隔
WATCH_CHECK_MS = 250           # 演奏中读取监视线程结果的间隔
WATCH_FALLBACK_MS = 10_000     # 监视线程超过该时长无结果则回退直采
PAGE_TIMEOUT_MS = 30_000       # 点击“前往演奏”后等待难度选择页的超时（超时发邮件）
SETTLE_PARSE_TIMEOUT_MS = 20_000  # 结算页出现后读取“演奏完成率”数值的超时
PLAY_POPUP_HOLD_MS = 15_000    # 演奏中疑似弹窗持续该时长才判为异常（避免误判 HUD 文字）
ALERT_COOLDOWN_MS = 5 * 60 * 1000  # 异常邮件最小间隔，防止刷屏
MUSIC_START_HOLD_MS_DEFAULT = 6_000  # 打歌模块启动保护：加载期不注入触点（0 = 立即启动）
CLICK_RETRY_MS = 2_500               # 点击后超过该时长仍未跳转且按钮还在 → 换位置重试
CLICK_RETRY_MAX = 3                  # 重试上限，超过按“点击无响应”发异常邮件

PHASE_STATE = {
    "START": "启动检查",
    "CATALOG": "目录：等待前往演奏",
    "DIFFICULTY": "难度选择",
    "PLAYING": "演奏中",
    "SETTLE": "结算判定",
    "RETURN_NEXT": "目录：等待切下一首",
    "DONE": "专辑完成",
    "STOPPED": "已停止",
}


class AlbumBot:
    def __init__(self, host):
        self.host = host
        cfg = host.getAlbumConfig() or {}
        self.completion_mode = str(_map_get(cfg, "completion_mode", "legend_only") or "legend_only")
        if self.completion_mode not in ("legend_only", "all_difficulties"):
            raise ValueError("completion_mode 只能是 legend_only 或 all_difficulties：" + self.completion_mode)
        self.on_exception = str(_map_get(cfg, "on_exception", "stop") or "stop")
        if self.on_exception not in ("stop", "continue", "wait", "retry"):
            raise ValueError("on_exception 只能是 stop / continue / wait / retry：" + self.on_exception)
        self.coord_next_song = (int(_map_get(cfg, "next_x", 0) or 0),
                                int(_map_get(cfg, "next_y", 0) or 0))
        self.coord_difficulty_done_return = (int(_map_get(cfg, "return_x", 0) or 0),
                                             int(_map_get(cfg, "return_y", 0) or 0))
        self.difficulty_order = self._parse_order(_map_get(cfg, "difficulty_order", ""))
        self.difficulty_slot_fractions = self._parse_slots(_map_get(cfg, "difficulty_slots", ""))
        self.catalog_wait_max_ms = max(0, int(_map_get(cfg, "catalog_wait_max_ms", 0) or 0))
        self.music_start_hold_ms = max(0, int(
            _map_get(cfg, "music_start_hold_ms", MUSIC_START_HOLD_MS_DEFAULT) or 0))

        self.running = False
        self.phase = "STOPPED"
        self.state = "待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = OCR_INTERVAL_MS
        self.song_index = 1
        self.current_difficulty = ""
        self.retry_count = 0
        self.mapper = None
        self.music = None
        self.music_started = False
        self.music_hold_until_ms = 0
        self.pending_click = None
        self.phase_since_ms = 0
        self.play_check_ms = 0
        self.play_popup_since_ms = None
        self.watch_last_ok_ms = 0
        self.last_alert_ms = None
        self.last_frame_texts = []
        self.started_at = ""

    # ------------------------------------------------------------------ 启停
    def start(self):
        if self.coord_next_song == (0, 0) or self.coord_difficulty_done_return == (0, 0):
            raise ValueError("请先在悬浮窗坐标设置中记录 coord_next_song 与 coord_difficulty_done_return")
        self.running = True
        self.song_index = 1
        self.current_difficulty = ""
        self.retry_count = 0
        self.music = None
        self.mapper = None
        self.last_alert_ms = None
        self.play_check_ms = 0
        self.play_popup_since_ms = None
        self.watch_last_ok_ms = 0
        self.last_frame_texts = []
        self.pending_click = None
        self.music_started = False
        self.music_hold_until_ms = 0
        self.started_at = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        self._enter("START")
        self.diagnostic = "全屏识别“千音雅集”（需求 4.1：仅启动时检查一次）"
        self._log("专辑补分启动：completion_mode=" + self.completion_mode
                  + "，on_exception=" + self.on_exception)

    def stop(self):
        self.running = False
        self._music_stop()
        self.state = "已停止"
        self._log("专辑补分已停止")

    # ------------------------------------------------------------------ 主步进
    def step(self):
        if not self.running:
            return
        try:
            if self.phase == "START":
                self._phase_start()
            elif self.phase == "CATALOG":
                self._phase_catalog()
            elif self.phase == "DIFFICULTY":
                self._phase_difficulty()
            elif self.phase == "PLAYING":
                self._phase_playing()
            elif self.phase == "SETTLE":
                self._phase_settle()
            elif self.phase == "RETURN_NEXT":
                self._phase_return_next()
        except Exception as exc:
            self._anomaly("流程异常", str(exc))

    # --------------------------------------------------------------- 各阶段
    def _phase_start(self):
        frame = self._capture()
        if frame is None:
            return
        if not frame.has(CATALOG_MARKER):
            # 需求 4.1：未识别到“千音雅集”直接停止，不发邮件、不重试。
            self.running = False
            self.phase = "STOPPED"
            self.state = "启动失败"
            self.diagnostic = "未识别到“千音雅集”，按需求 4.1 直接停止"
            self._log(self.diagnostic)
            return
        self._enter("CATALOG")
        self.diagnostic = "启动检查通过：已识别“千音雅集”，开始第 1/%d 首" % ALBUM_SONG_COUNT

    def _phase_catalog(self):
        frame = self._capture()
        if frame is None or self._guard_anomaly(frame, "目录"):
            return
        marker = frame.has(CATALOG_MARKER)
        target = frame.find(PLAY_GO_TEXT)
        if not (marker and target):
            self._retry_click(frame, "目录")
            self._wait_note("等待“千音雅集”目录与“前往演奏”按钮", self.catalog_wait_max_ms or None)
            return
        self.pending_click = None
        self._tap_text_item(target, PLAY_GO_TEXT)
        self._arm_click(PLAY_GO_TEXT, PLAY_GO_TEXT)
        self._enter("DIFFICULTY")
        self.diagnostic = "已点击“前往演奏”，等待难度选择页（第 %d/%d 首）" % (
            self.song_index, ALBUM_SONG_COUNT)

    def _phase_difficulty(self):
        frame = self._capture()
        if frame is None or self._guard_anomaly(frame, "难度选择"):
            return
        if not self._is_difficulty_page(frame):
            self._retry_click(frame, "难度选择")
            self._wait_note("等待难度选择页出现", PAGE_TIMEOUT_MS)
            return
        self.pending_click = None

        # 需求 6.1：进入难度选择页后按屏幕位置判定各难度是否已“大音天籁”。
        done = self._difficulty_completion(frame)
        self.diagnostic = "难度完成度：" + " ".join(
            ("✓" if done.get(name) else "✗") + name for name in DIFFICULTY_PRIORITY)

        if self.completion_mode == "legend_only":
            if done.get("传说"):
                self._tap_coord(self.coord_difficulty_done_return)
                self._enter("RETURN_NEXT")
                self.diagnostic = "传说已“大音天籁”，点击 coord_difficulty_done_return 返回目录"
                return
            target = "传说"
        else:
            target = None
            for name in DIFFICULTY_PRIORITY:
                if not done.get(name):
                    target = name
                    break
            if target is None:
                self._tap_coord(self.coord_difficulty_done_return)
                self._enter("RETURN_NEXT")
                self.diagnostic = "四个难度均“大音天籁”，点击 coord_difficulty_done_return 返回目录"
                return

        if not self._select_difficulty(frame, target):
            self._anomaly("无法选择难度", "未识别到“" + target + "”且位置兜底不可用")
            return
        start_button = frame.find(PLAY_START_TEXT)
        if start_button is None:
            self._anomaly("缺少目标按钮", "难度选择页未识别到“开始演奏”")
            return
        self._tap_text_item(start_button, PLAY_START_TEXT)
        self._arm_click(PLAY_START_TEXT, PLAY_START_TEXT)
        self.current_difficulty = target
        self._enter("PLAYING")
        try:
            self._play_session_start()
        except Exception as exc:
            self._anomaly("打歌模块启动失败", str(exc))
            return
        self.diagnostic = "已选择“" + target + "”并点击“开始演奏”"

    def _phase_playing(self):
        now = int(time.monotonic() * 1000)
        if not self.music_started:
            # 打歌模块启动保护：加载期不注入触点，只用监视帧看弹窗/结算/点击是否生效。
            self.state = "演奏准备"
            self.loop_interval_ms = OCR_INTERVAL_MS
            frame = self._watch_frame()
            if frame is not None:
                reason = self._play_anomaly_reason(frame, now)
                if reason is not None:
                    self._anomaly("演奏准备", reason)
                    return
                self._retry_click(frame, "演奏准备")
                if self._is_settlement_page(frame):
                    self._enter("SETTLE")
                    self.diagnostic = "启动保护期间即出现结算页，直接结算判定"
                    return
            if now < self.music_hold_until_ms:
                self.diagnostic = "打歌模块启动保护：约 %d 秒后启动（加载期不注入触点）" % (
                    (self.music_hold_until_ms - now + 999) // 1000)
                return
            try:
                self._music_module_start()
            except Exception as exc:
                self._anomaly("打歌模块启动失败", str(exc))
                return
            self.diagnostic = "打歌模块已启动（" + (self.current_difficulty or "未选难度") + "）"
            return

        self.state = "演奏中"
        self.loop_interval_ms = PLAY_INTERVAL_MS
        try:
            self._music_step()
        except Exception as exc:
            self._music_stop()
            self._anomaly("打歌模块异常", str(exc))
            return

        if now - self.play_check_ms < WATCH_CHECK_MS:
            return
        self.play_check_ms = now
        frame = self._watch_frame()
        if frame is None:
            self.diagnostic = "演奏中（第 %d/%d 首 · %s）" % (
                self.song_index, ALBUM_SONG_COUNT, self.current_difficulty or "未选难度")
            return
        reason = self._play_anomaly_reason(frame, now)
        if reason is not None:
            self._music_stop()
            self._anomaly("演奏中", reason)
            return
        if self._is_settlement_page(frame):
            # 需求 7.1/7.2：结算页判定依据 = 全屏识别“演奏完成率”。
            self._music_stop()
            self.pending_click = None
            self._enter("SETTLE")
            self.diagnostic = "检测到结算页“演奏完成率”，打歌模块已停止"
            return
        self.diagnostic = "演奏中（第 %d/%d 首 · %s）" % (
            self.song_index, ALBUM_SONG_COUNT, self.current_difficulty or "未选难度")

    def _phase_settle(self):
        frame = self._capture()
        if frame is None or self._guard_anomaly(frame, "结算"):
            return
        rate = self._parse_completion_rate(frame)
        if rate is None:
            self._wait_note("结算页未读到“演奏完成率”数值", SETTLE_PARSE_TIMEOUT_MS)
            return
        self.diagnostic = "演奏完成率 %.1f%%（目标 %.1f%%）" % (rate, TARGET_COMPLETION_RATE)
        if rate + 0.001 < TARGET_COMPLETION_RATE:
            # 需求 7.5：不查询手机温度，直接“再次演奏”，不重新选曲、不重新选难度。
            retry = frame.find(RETRY_TEXT)
            if retry is None:
                self._anomaly("缺少目标按钮", "结算页未识别到“再次演奏”")
                return
            self._tap_text_item(retry, RETRY_TEXT)
            self._arm_click(RETRY_TEXT, RETRY_TEXT)
            self.retry_count += 1
            self._enter("PLAYING")
            try:
                self._play_session_start()
            except Exception as exc:
                self._anomaly("打歌模块启动失败", str(exc))
                return
            self.diagnostic = "完成率 %.1f%% 未到 100.0%%，点击“再次演奏”（第 %d 次重试，无限重试）" % (
                rate, self.retry_count)
            return
        choose = frame.find(NEXT_SELECT_TEXT)
        if choose is None:
            self._anomaly("缺少目标按钮", "结算页未识别到“选择曲目”")
            return
        self._tap_text_item(choose, NEXT_SELECT_TEXT)
        self._arm_click(NEXT_SELECT_TEXT, NEXT_SELECT_TEXT)
        if self.completion_mode == "legend_only":
            self._enter("RETURN_NEXT")
            self.diagnostic = "已达 100.0%，点击“选择曲目”，准备切下一首"
        else:
            self._enter("CATALOG")
            self.diagnostic = "已达 100.0%，点击“选择曲目”，回到目录继续补下一个难度"

    def _phase_return_next(self):
        frame = self._capture()
        if frame is None or self._guard_anomaly(frame, "切下一首前目录检查"):
            return
        if not frame.has(CATALOG_MARKER):
            # 需求 4.2：未识别到“千音雅集”属于等待，不点击下一首、不触发邮件提醒。
            self._retry_click(frame, "切下一首前目录检查")
            self._wait_note("等待“千音雅集”确认已回目录", self.catalog_wait_max_ms or None)
            return
        self.pending_click = None
        self._tap_coord(self.coord_next_song)
        self.song_index += 1
        if self.song_index > ALBUM_SONG_COUNT:
            self.running = False
            self.phase = "DONE"
            self.state = "专辑完成"
            self.diagnostic = "%d 首全部处理完成，脚本已停止" % ALBUM_SONG_COUNT
            self._log(self.diagnostic)
            return
        self._enter("CATALOG")
        self.diagnostic = "已确认目录并点击 coord_next_song，开始第 %d/%d 首" % (
            self.song_index, ALBUM_SONG_COUNT)

    # ---------------------------------------------------------------- 等待机制
    def _wait_note(self, context, timeout_ms):
        """等待下一个目标出现：只轮询 OCR，不盲点；无限等待时状态每分钟刷新避免误报卡死。"""
        now = int(time.monotonic() * 1000)
        elapsed = max(0, now - self.phase_since_ms)
        self.state = "%s（%d 分钟）" % (context, elapsed // 60000)
        self.diagnostic = "%s；已等待 %d 秒" % (context, elapsed // 1000)
        self.loop_interval_ms = OCR_INTERVAL_MS
        if timeout_ms is not None and elapsed >= timeout_ms:
            self._anomaly("等待目标界面超时",
                          "%s 超过 %d 秒仍未出现" % (context, timeout_ms // 1000))

    # ------------------------------------------------------------ 页面与判定
    def _is_difficulty_page(self, frame):
        if frame.has(PLAY_START_TEXT):
            return True
        if frame.has(RATING_TEXT):
            return True
        return (not frame.has(CATALOG_MARKER)
                and any(frame.find(name) is not None for name in DIFFICULTY_PRIORITY))

    @staticmethod
    def _is_settlement_page(frame):
        return frame.has(SETTLE_LABEL) or (frame.has(RETRY_TEXT) and frame.has(NEXT_SELECT_TEXT))

    def _difficulty_slots(self, frame):
        """四个难度的屏幕位置：优先用 OCR 到的难度名，缺失的用配置比例兜底。"""
        slots = {}
        for name in self.difficulty_order:
            item = frame.find(name)
            if item is not None:
                slots[name] = (item.center_x, item.center_y)
        for name, (fx, fy) in zip(self.difficulty_order, self.difficulty_slot_fractions):
            if name not in slots:
                slots[name] = (frame.width * fx, frame.height * fy)
        return slots

    def _difficulty_completion(self, frame):
        """按屏幕位置把“大音天籁”映射到普通/困难/大师/传说（需求 6.1）。"""
        done = {name: False for name in self.difficulty_order}
        badges = [item for item in frame.texts if RATING_TEXT in (item.text or "")]
        if not badges:
            return done
        slots = self._difficulty_slots(frame)
        limit = frame.height * 0.3
        used = set()
        for badge in badges:
            best, best_distance = None, None
            for name, (sx, sy) in slots.items():
                if name in used:
                    continue
                distance = (badge.center_y - sy) ** 2 + ((badge.center_x - sx) * 0.5) ** 2
                if best_distance is None or distance < best_distance:
                    best, best_distance = name, distance
            if best is not None and best_distance is not None and best_distance ** 0.5 <= limit:
                used.add(best)
                done[best] = True
        return done

    def _select_difficulty(self, frame, name):
        item = frame.find(name)
        if item is not None:
            self._tap_text_item(item, name)
            return True
        slots = self._difficulty_slots(frame)
        if name in slots:
            self.mapper.tap(self.host, slots[name][0], slots[name][1])
            return True
        return False

    @staticmethod
    def _parse_completion_rate(frame):
        """读取“演奏完成率”数值：优先取与标签同区域最近的百分比。"""
        label = frame.find(SETTLE_LABEL)
        pattern = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*[%％]")
        candidates = []
        for item in frame.texts:
            # 容忍 OCR 把数字误识别为字母（l→1、O/o→0、全角％）。
            normalized = (item.text or "").replace("l", "1").replace("O", "0").replace("o", "0")
            for match in pattern.finditer(normalized):
                candidates.append((float(match.group(1)), item))
        if not candidates:
            return None
        if label is not None:
            candidates.sort(key=lambda c: (abs(c[1].center_y - label.center_y) * 2
                                           + abs(c[1].center_x - label.center_x)))
        return candidates[0][0]

    # ------------------------------------------------------------- 异常与邮件
    def _guard_anomaly(self, frame, context):
        reason = self._anomaly_reason(frame, context)
        if reason is not None:
            self._anomaly(context, reason)
            return True
        return False

    def _play_anomaly_reason(self, frame, now):
        for word in ANOMALY_TEXTS:
            if frame.has(word):
                return "检测到“" + word + "”"
        # 演奏 HUD 文案未知，疑似弹窗必须持续出现才判异常，避免误杀正常打歌。
        popup = any(frame.has(word) for word in POPUP_TEXTS) and not frame.has(SETTLE_LABEL)
        if popup:
            if self.play_popup_since_ms is None:
                self.play_popup_since_ms = now
            elif now - self.play_popup_since_ms >= PLAY_POPUP_HOLD_MS:
                return "疑似弹窗持续 %d 秒" % (PLAY_POPUP_HOLD_MS // 1000)
        else:
            self.play_popup_since_ms = None
        return None

    def _anomaly_reason(self, frame, context):
        for word in ANOMALY_TEXTS:
            if frame.has(word):
                return "检测到“" + word + "”"
        if context == "演奏中":
            return None
        if any(frame.has(marker) for marker in PAGE_MARKERS):
            return None
        for word in POPUP_TEXTS:
            if frame.has(word):
                return "疑似弹窗“" + word + "”"
        return None

    def _anomaly(self, where, detail):
        now = int(time.monotonic() * 1000)
        message = where + "：" + detail
        self.diagnostic = "异常 — " + message
        self._log("专辑补分异常 — " + message)
        self.loop_interval_ms = OCR_INTERVAL_MS
        if self.on_exception == "stop":
            # 需求 8【待确认】默认动作：发邮件后停止脚本。
            self.running = False
            self.phase = "STOPPED"
            self.state = "异常停止"
        else:
            self.state = "异常重试中"
        if self.last_alert_ms is None or now - self.last_alert_ms >= ALERT_COOLDOWN_MS:
            self.last_alert_ms = now
            self._send_alert(where, detail)

    def _send_alert(self, where, detail):
        sender = getattr(self.host, "sendEmailAlert", None)
        if not callable(sender):
            self._log("宿主未提供邮件提醒接口 sendEmailAlert，异常仅记录日志")
            return
        lines = [
            "RedFingerGameBot 专辑补分出现非预期情况。",
            "检测时间：" + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
            "启动时间：" + (self.started_at or "未知"),
            "补分模式：" + self.completion_mode,
            "当前曲目：第 %d/%d 首" % (self.song_index, ALBUM_SONG_COUNT),
            "当前难度：" + (self.current_difficulty or "未选择"),
            "重试次数：" + str(self.retry_count),
            "阶段：" + self.phase,
            "异常位置：" + where,
            "异常详情：" + detail,
        ]
        if self.last_frame_texts:
            lines.append("最近识别文字：" + " | ".join(self.last_frame_texts[:8]))
        try:
            sender("RedFingerGameBot 专辑补分异常提醒", "\n".join(lines))
        except Exception as exc:
            self._log("异常提醒邮件发送失败：" + str(exc))

    # ---------------------------------------------------------- 采集与打歌模块
    def _capture(self):
        try:
            frame = Frame.from_host(self.host.capture())
            self.mapper = CoordinateMapper(frame.width, frame.height)
            self.last_frame_texts = [(item.text or "").strip() for item in frame.texts][:8]
            return frame
        except Exception as exc:
            self._anomaly("截图/OCR 失败", str(exc))
            return None

    def _watch_frame(self):
        """打歌期间读取后台 OCR 监视帧；监视线程失效时回退为直采。"""
        now = int(time.monotonic() * 1000)
        getter = getattr(self.host, "getOcrWatchFrame", None)
        raw = getter() if callable(getter) else None
        if raw is not None:
            updated = int(_map_get(raw, "updatedAtMs", 0) or 0)
            if updated == 0 or now - updated <= 3 * WATCH_INTERVAL_MS:
                self.watch_last_ok_ms = now
                frame = Frame.from_host(raw)
                self.last_frame_texts = [(item.text or "").strip() for item in frame.texts][:8]
                return frame
        if self.watch_last_ok_ms and now - self.watch_last_ok_ms >= WATCH_FALLBACK_MS:
            self._log("OCR 监视帧超时，回退为演奏中直采确认结算页")
            self.watch_last_ok_ms = now
            return self._capture()
        return None

    def _play_session_start(self):
        """点击“开始演奏/再次演奏”后进入演奏会话：先开监视；打歌模块按启动保护延后注入触点。"""
        self.music_started = False
        self.play_check_ms = 0
        self.play_popup_since_ms = None
        self.watch_last_ok_ms = int(time.monotonic() * 1000)
        self.music_hold_until_ms = int(time.monotonic() * 1000) + self.music_start_hold_ms
        self.loop_interval_ms = OCR_INTERVAL_MS
        watcher = getattr(self.host, "startOcrWatcher", None)
        if callable(watcher):
            try:
                watcher(WATCH_INTERVAL_MS)
            except Exception as exc:
                self._log("后台 OCR 监视线程启动失败，改用演奏中直采：" + str(exc))
        if self.music_start_hold_ms <= 0:
            self._music_module_start()

    def _music_module_start(self):
        if self.music is None:
            self.music = MusicBot(self.host)  # 黑盒：已有打歌模块
        self.music.start()
        self.music_started = True
        self._log("打歌模块已启动（" + (self.current_difficulty or "未选难度") + "）")

    def _music_step(self):
        if self.music is not None and self.music_started:
            self.music.step()

    def _music_stop(self):
        self.music_started = False
        stopper = getattr(self.host, "stopOcrWatcher", None)
        if callable(stopper):
            try:
                stopper()
            except Exception as exc:
                self._log("停止 OCR 监视线程失败：" + str(exc))
        if self.music is not None:
            try:
                self.music.stop()
            except Exception as exc:
                self._log("打歌模块停止失败：" + str(exc))

    # ------------------------------------------------------------ 点击与重试
    def _tap_text_item(self, item, needle=None, variant=0):
        """点击文字目标：优先点目标文字自身在行内的比例位置，避免 OCR 行合并导致点偏。"""
        text = item.text or ""
        if needle and needle in text and len(text) > len(needle):
            index = text.find(needle)
            frac = (index + len(needle) / 2.0) / len(text)
            x = item.left + (item.right - item.left) * frac
        else:
            x = item.center_x
        if variant == 1:
            y = item.top + (item.bottom - item.top) * 0.3
        elif variant >= 2:
            y = item.top + (item.bottom - item.top) * 0.7
        else:
            y = item.center_y
        self._tap_screen(x, y)

    def _arm_click(self, text, needle):
        self.pending_click = {"text": text, "needle": needle,
                              "at": int(time.monotonic() * 1000), "retries": 0}

    def _retry_click(self, frame, context):
        """点击后“等待下一个目标出现”：目标未跳转且按钮仍在 → 换位置重试，多次无响应发邮件。"""
        pending = self.pending_click
        if pending is None:
            return
        now = int(time.monotonic() * 1000)
        if now - pending["at"] < CLICK_RETRY_MS:
            return
        item = frame.find(pending["text"])
        if item is None:
            return  # 按钮已消失：跳转正在进行，继续等待下一个目标
        if pending["retries"] >= CLICK_RETRY_MAX:
            self.pending_click = None
            self._anomaly("点击无响应", "“" + pending["text"] + "”已点击 "
                          + str(CLICK_RETRY_MAX + 1) + " 次仍未跳转（" + context + "）")
            return
        pending["retries"] += 1
        pending["at"] = now
        self._tap_text_item(item, pending["needle"], variant=pending["retries"])
        self.diagnostic = "“" + pending["text"] + "”点击未生效，换位置重试第 " \
                          + str(pending["retries"]) + " 次"
        self._log(self.diagnostic)

    def _tap_coord(self, coord):
        """用户自定义固定坐标（1280×720 参考系，同游戏挂机坐标）。"""
        if self.mapper is None:
            raise RuntimeError("尚未采集到屏幕尺寸，无法点击固定坐标")
        self.mapper.tap(self.host, coord[0], coord[1])

    def _tap_screen(self, x, y):
        width = self.mapper.screen_width if self.mapper else int(round(x)) + 1
        height = self.mapper.screen_height if self.mapper else int(round(y)) + 1
        self.host.tap(max(0, min(width - 1, round(x))), max(0, min(height - 1, round(y))))

    # ------------------------------------------------------------------ 杂项
    @staticmethod
    def _parse_order(value):
        names = [part.strip() for part in str(value or "").replace("，", ",").split(",")]
        names = [name for name in names if name]
        if len(names) == 4 and set(names) == set(DIFFICULTY_PRIORITY):
            return tuple(names)
        return DIFFICULTY_PRIORITY

    @staticmethod
    def _parse_slots(value):
        default = ((0.5, 0.25), (0.5, 0.42), (0.5, 0.58), (0.5, 0.75))
        text = str(value or "").strip()
        if not text:
            return default
        try:
            slots = []
            for pair in text.split(";"):
                x_str, y_str = pair.split(",")
                slots.append((float(x_str), float(y_str)))
            if len(slots) == 4:
                return tuple(slots)
        except Exception:
            pass
        return default

    def _enter(self, phase):
        self.phase = phase
        self.phase_since_ms = int(time.monotonic() * 1000)
        self.state = PHASE_STATE.get(phase, phase)
        self.loop_interval_ms = OCR_INTERVAL_MS

    def _log(self, message):
        logger = getattr(self.host, "log", None)
        if callable(logger):
            logger(message)
