"""Album-level automation controller. MusicBot remains an unchanged black-box engine."""
from .frame import Frame
from .music_bot import MusicBot

PRIORITY = ("传说", "大师", "困难", "普通")
DIFFICULTIES = ("普通", "困难", "大师", "传说")


class AlbumBot:
    def __init__(self, host):
        self.host = host
        self.config = host.getAlbumConfig()
        self.mode = str(self._get("completion_mode", "legend_only"))
        if self.mode not in ("legend_only", "all_difficulties"):
            self.mode = "legend_only"
        self.song_count = 12
        self.song_index = 1
        self.state = "专辑脚本待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = 350
        self.running = False
        self.music = MusicBot(host)
        self.music_active = False
        self.wait_target = None
        self.wait_action = None
        self.wait_started = 0
        self.retry_count = 0
        self.current_difficulty = ""
        self.completed = set()
        self.last_frame = None
        self._pending_tap = False
        self._last_result_poll = 0.0
        self._next_song_button_disappeared = False

    def _get(self, key, default):
        try:
            value = self.config.get(key)
            return default if value is None else value
        except Exception:
            try:
                return self.config[key]
            except Exception:
                return default

    def start(self):
        self.running = True
        self.state = "启动检查"
        self.diagnostic = "检查当前是否位于千音雅集目录"
        self._transition("启动检查", "千音雅集")

    def stop(self):
        self.running = False
        self._stop_music()
        self.state = "专辑脚本已停止"

    def _transition(self, state, target=None):
        import time
        self.state = state
        self.wait_target = target
        self.wait_started = time.monotonic()
        self.loop_interval_ms = 5 if state in ("打歌中", "再次演奏中") else 350

    def _stop_music(self):
        if self.music_active:
            try:
                self.music.stop()
            finally:
                self.music_active = False

    def _start_music(self):
        self._stop_music()
        self.music.start()
        self.music_active = True

    def _frame(self):
        return Frame.from_host(self.host.capture())

    def _tap_text(self, frame, text):
        item = frame.find(text)
        if item is None:
            return False
        self.host.tap(int(item.center_x), int(item.center_y))
        self._pending_tap = True
        return True

    def _tap_coord(self, x, y):
        self.host.tap(int(x), int(y))
        self._pending_tap = True

    def _wait_catalog_then(self, next_state):
        self._transition(next_state, "千音雅集")
        self.diagnostic = "等待千音雅集目录出现；未出现时不会点击下一首"

    def _alert(self, reason):
        try:
            self.host.sendAlbumAlert("音游专辑脚本异常", reason)
        except Exception as exc:
            self.host.log("专辑异常邮件发送失败：" + str(exc))
        self._stop_music()
        self.state = "异常暂停"
        self.diagnostic = reason + "；已尝试发送邮件，等待人工检查后重新启动"

    def _is_difficulty_page(self, frame):
        return all(frame.has(d) for d in DIFFICULTIES)

    def _rating_map(self, frame):
        labels = [x for x in frame.texts if "大音天籁" in x.text]
        difficulty_items = {d: frame.find(d) for d in DIFFICULTIES}
        result = set()
        # Associate each rating label with its nearest difficulty label in screen space.
        for rating in labels:
            candidates = [(abs(rating.center_x - item.center_x) +
                           abs(rating.center_y - item.center_y), name)
                          for name, item in difficulty_items.items() if item is not None]
            if candidates:
                distance, name = min(candidates)
                # Avoid assigning a rating to a distant, unrelated occurrence.
                if distance <= max(frame.width, frame.height) * 0.38:
                    result.add(name)
        return result

    def _choose_next_difficulty(self):
        for difficulty in PRIORITY:
            if difficulty not in self.completed:
                return difficulty
        return None

    def _begin_difficulty(self, frame, difficulty):
        if not self._tap_text(frame, difficulty):
            return False
        self.current_difficulty = difficulty
        self._transition("wait_start_button", "开始演奏")
        self.diagnostic = "已选择" + difficulty + "，等待开始演奏按钮"
        return True

    def _begin_play(self, frame):
        if self._tap_text(frame, "开始演奏"):
            self._transition("wait_game_start", None)
            self.diagnostic = "已点击开始演奏，等待打歌画面"
            return True
        return False

    def _enter_difficulty_page(self, frame):
        if self._tap_text(frame, "前往演奏"):
            self._transition("wait_difficulty_page", None)
            self.diagnostic = "等待难度选择页面"
            return True
        return False

    def step(self):
        if not self.running or self.state == "异常暂停":
            return
        try:
            if self.state in ("打歌中", "再次演奏中"):
                import time
                self.music.step()
                now = time.monotonic()
                self.diagnostic = "第%d/12首 · %s · %s" % (
                    self.song_index, self.current_difficulty, self.music.diagnostic)
                if now - self._last_result_poll >= 0.6:
                    self._last_result_poll = now
                    playing_frame = self._frame()
                    if playing_frame.has("演奏完成率"):
                        self._stop_music()
                        self._transition("wait_result")
                        self.diagnostic = "检测到结算页面，正在读取完成率"
                return

            frame = self._frame()
            self.last_frame = frame
            screen_text = frame.full_text
            if any(token in screen_text for token in ("网络异常", "网络连接失败", "加载失败", "发生错误")):
                self._alert("检测到异常界面：" + screen_text[:180])
                return
            if self.state.startswith("wait_") and self.state not in ("wait_return_catalog",):
                import time
                if self.wait_started and time.monotonic() - self.wait_started > 45:
                    self._alert("等待目标界面超时：" + str(self.wait_target or self.state))
                    return
            if self.state == "启动检查":
                if frame.has("千音雅集"):
                    self._transition("wait_enter_song_button", "前往演奏")
                    self.diagnostic = "启动检查通过"
                else:
                    self._stop_music()
                    self.running = False
                    self.state = "启动失败"
                    self.diagnostic = "启动时未识别到千音雅集，脚本停止"
                return

            if self.state == "wait_next_song_ready":
                if not frame.has("前往演奏"):
                    self._next_song_button_disappeared = True
                elif self._next_song_button_disappeared and frame.has("千音雅集"):
                    self._transition("wait_enter_song_button", "前往演奏")
                    self.diagnostic = "新歌曲目录已就绪"
                return

            if self.state == "wait_enter_song_button":
                if frame.has("千音雅集") and self._tap_text(frame, "前往演奏"):
                    self._transition("wait_difficulty_page")
                    self.diagnostic = "等待难度选择页"
                return

            if self.state == "wait_difficulty_page":
                if self._is_difficulty_page(frame):
                    self.completed = self._rating_map(frame)
                    self.diagnostic = "已识别难度页；已完成：" + ("、".join(sorted(self.completed)) or "无")
                    if self.mode == "legend_only":
                        if "传说" in self.completed:
                            self._transition("return_song_done")
                        else:
                            self._begin_difficulty(frame, "传说")
                    else:
                        difficulty = self._choose_next_difficulty()
                        if difficulty is None:
                            self._transition("return_song_done")
                        else:
                            self._begin_difficulty(frame, difficulty)
                return

            if self.state == "wait_start_button":
                self._begin_play(frame)
                return

            if self.state == "wait_game_start":
                # Gameplay screen is identified by disappearance of menu controls.
                if not frame.has("开始演奏") and not frame.has("前往演奏"):
                    self._start_music()
                    import time
                    self._last_result_poll = time.monotonic()
                    self._transition("打歌中")
                    self.diagnostic = "打歌模块已启动"
                return

            if self.state == "wait_result":
                if frame.has("演奏完成率"):
                    self._stop_music()
                    rate_text = frame.full_text.replace(" ", "").replace("％", "%")
                    if "100.0%" in rate_text:
                        self.retry_count = 0
                        if self._tap_text(frame, "选择曲目"):
                            self._transition("wait_return_catalog")
                            self.diagnostic = "完成率100%，返回当前歌曲目录"
                    else:
                        self.retry_count += 1
                        self._transition("retry_click")
                        self.diagnostic = "完成率未达100%，准备第%d次重试" % self.retry_count
                return

            if self.state == "retry_click":
                if self._tap_text(frame, "再次演奏"):
                    self._transition("wait_retry_start")
                    self.diagnostic = "等待再次演奏启动"
                return

            if self.state == "wait_retry_start":
                if not frame.has("演奏完成率") and not frame.has("再次演奏"):
                    self._start_music()
                    import time
                    self._last_result_poll = time.monotonic()
                    self._transition("再次演奏中")
                    self.diagnostic = "原曲目原难度重试中"
                return

            if self.state == "wait_return_catalog":
                if frame.has("千音雅集"):
                    if self.mode == "all_difficulties":
                        self._transition("wait_enter_song_button", "前往演奏")
                        self.diagnostic = "已返回当前歌曲目录，准备补下一难度"
                    else:
                        self._transition("next_song")
                return

            if self.state == "return_song_done":
                x = int(self._get("coord_difficulty_done_return_x", 0))
                y = int(self._get("coord_difficulty_done_return_y", 0))
                if x > 0 and y > 0:
                    self._tap_coord(x, y)
                    self._wait_catalog_then("next_song")
                else:
                    self._alert("未配置难度完成后返回目录的坐标")
                return

            if self.state == "next_song":
                # Requirement: verify catalog text immediately before every next-song tap.
                if frame.has("千音雅集"):
                    if self.song_index >= self.song_count:
                        self.running = False
                        self.state = "专辑完成"
                        self.diagnostic = "12首歌曲处理完成，脚本停止"
                        return
                    x = int(self._get("coord_next_song_x", 0))
                    y = int(self._get("coord_next_song_y", 0))
                    if x > 0 and y > 0:
                        self._tap_coord(x, y)
                        self.song_index += 1
                        self._next_song_button_disappeared = False
                        self._transition("wait_next_song_ready", "新歌曲前往演奏按钮")
                        self.diagnostic = "已点击下一首，等待新歌曲页面完成切换"
                return

            # Explicitly wait for expected page transitions rather than blind tapping.
            if self.state == "wait_difficulty_page" and not self._is_difficulty_page(frame):
                return
        except Exception as exc:
            self._alert("专辑脚本运行异常：" + str(exc))

