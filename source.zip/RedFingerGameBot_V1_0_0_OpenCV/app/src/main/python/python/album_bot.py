"""千音雅集专辑自动补难度脚本。

本模块只做“页面层”的事情：识别目录/难度/结算页、按配置选难度、开始演奏、
判定完成率、重试、切下一首、异常邮件。真正打歌完全复用已有的六轨打歌模块
``MusicBot``（屏幕采样 + Root 多点触控），不复制、不修改它的内部逻辑。

页面推进方式遵循规格里的“点击后等待下一个目标出现”：每次 step() 只做一次
截图识别 + 一个动作，动作之后不睡眠等固定时间，而是回到 step() 重新识别目标，
目标出现才继续。只有打歌阶段是阻塞的紧循环（由 MusicBot 的帧流驱动）。

退出检测说明：打歌期间不能持续跑 OCR，否则会漏音符。这里用“按键事件静音”
（连续 N 毫秒没有新的按键）作为候选时刻，才做一次 OCR 确认是否出现
“演奏完成率”。若只是歌曲间隙，OCR 结束后立刻恢复打歌。
"""

import re
import time

from .coordinate import CoordinateMapper
from .frame import Frame
from .music_bot import MusicBot


class AlbumBot:
    # ---------- 规格固定项 ----------
    # 补难度优先级：传说 > 大师 > 困难 > 普通
    DIFFICULTY_ORDER = ("legend", "master", "hard", "normal")
    # 难度选择页从上到下的显示顺序（仅用于按 Y 坐标把“大音天籁”映射到难度）
    DISPLAY_ORDER = ("normal", "hard", "master", "legend")
    DIFFICULTY_LABELS = {
        "legend": "传说",
        "master": "大师",
        "hard": "困难",
        "normal": "普通",
    }
    DIFFICULTY_ALIASES = {
        "legend": ("传说", "傳說"),
        "master": ("大师", "大師"),
        "hard": ("困难", "困難"),
        "normal": ("普通",),
    }
    RATING_ALIASES = ("大音天籁", "大音天籟")

    TITLE_ALIASES = ("千音雅集",)
    TEXT_ENTER_PLAY = "前往演奏"
    TEXT_START_PLAY = "开始演奏"
    TEXT_SELECT_TRACK = "选择曲目"
    TEXT_RETRY_PLAY = "再次演奏"
    TEXT_RESULT_MARK = "演奏完成率"

    # 只自动点击“重试/确定”这类明确按钮，绝不点“取消/放弃”，避免误退关卡。
    POPUP_WORDS = ("网络异常", "网络错误", "连接失败", "连接超时", "加载失败",
                   "服务器繁忙", "数据异常", "系统提示")
    POPUP_BUTTONS = ("重新加载", "重试", "确定", "确认", "知道了", "关闭")

    MODE_LEGEND_ONLY = 0
    MODE_ALL_DIFFICULTIES = 1

    # ---------- 配置默认值（与 RootHost.getAlbumConfig 的顺序一致） ----------
    CONFIG_DEFAULTS = (-1, -1, -1, -1, MODE_LEGEND_ONLY, 12, 90_000, 5_000, 30_000, 1)
    TARGET_RATE = 100.0
    RATE_EPSILON = 0.05          # 显示四舍五入容差：>= 99.95 视为 100.0%
    MAX_SONG_MS = 8 * 60 * 1000  # 单次演奏硬上限（防止结算页永远不出现）
    QUEUE_INTERVAL_MS = 300      # 页面态的外层轮询间隔
    PLAY_INTERVAL_MS = 5         # 打歌态由帧流驱动，不额外 sleep

    # ---------- 状态 ----------
    ST_START = "启动检查"
    ST_ENTER = "进入演奏"
    ST_DIFFICULTY = "识别难度"
    ST_START_BUTTON = "等待开始演奏"
    ST_PLAYING = "演奏中"
    ST_SETTLEMENT = "结算判定"
    ST_AFTER_SELECT = "返回目录"
    ST_NEXT = "切换下一首"
    ST_DONE = "全部完成"
    ST_STOPPED = "已停止"

    def __init__(self, host):
        self.host = host
        self._music = MusicBot(host)
        self._mapper = None
        self._load_config()

        self.running = False
        self.state = "专辑待命"
        self.diagnostic = "等待启动"
        self.loop_interval_ms = self.QUEUE_INTERVAL_MS

        self._song_index = 1
        self._song_done = set()
        self._target = None
        self._retry_in_song = 0
        self._total_retries = 0
        self._completed_difficulties = 0
        self._state_since = time.monotonic()
        self._capture_failures = 0
        self._error_count = 0
        self._last_alert_signature = ""
        self._last_alert_at = 0.0
        self._recent_logs = []
        self._last_frame = None
        self._last_tap_at = {}
        self._return_stuck_at = None

    # ------------------------------------------------------------------ 配置
    def _load_config(self):
        values = list(self.host.getAlbumConfig())
        if len(values) < len(self.CONFIG_DEFAULTS):
            values = list(self.CONFIG_DEFAULTS)
        self._next_song = (int(values[0]), int(values[1]))
        self._done_return = (int(values[2]), int(values[3]))
        self._mode = self.MODE_ALL_DIFFICULTIES if int(values[4]) == 1 else self.MODE_LEGEND_ONLY
        self._song_count = max(1, int(values[5]))
        self._page_timeout_ms = max(10_000, int(values[6]))
        self._quiet_ms = max(1_500, int(values[7]))
        self._first_note_grace_ms = max(10_000, int(values[8]))
        self._send_complete_email = int(values[9]) != 0

    def _coordinates_ready(self):
        for x, y in (self._next_song, self._done_return):
            if x < 0 or y < 0:
                return False
        return True

    def _mode_name(self):
        return "只补传说" if self._mode == self.MODE_LEGEND_ONLY else "四难度全补"

    # ------------------------------------------------------------------ 生命周期
    def start(self):
        self.running = False
        self.state = self.ST_START
        self.diagnostic = "正在识别“千音雅集”目录"
        self._load_config()
        self._song_index = 1
        self._song_done = set()
        self._target = None
        self._retry_in_song = 0
        self._total_retries = 0
        self._completed_difficulties = 0
        self._capture_failures = 0
        self._error_count = 0
        self._music = MusicBot(self.host)

        if not self._coordinates_ready():
            self.state = "未启动"
            self.diagnostic = "请先在“坐标设置”中记录“下一首”和“已完成返回”两个坐标"
            self._log(self.diagnostic)
            return

        checker = getattr(self.host, "isAlbumAlertConfigured", None)
        if callable(checker):
            try:
                if not checker():
                    self._log("邮件提醒未配置：出现异常时只写日志，不会发邮件")
            except Exception:
                pass

        # 规格 4.1：启动时只检查一次“千音雅集”，识别不到直接停止。
        frame = self._capture()
        if frame is None or self._find(frame, self.TITLE_ALIASES) is None:
            self.state = self.ST_STOPPED
            self.diagnostic = "启动时未识别到“千音雅集”，脚本不启动"
            self._log(self.diagnostic)
            return

        self.running = True
        self._enter(self.ST_ENTER, "已确认目录，开始处理第 1/%d 首" % self._song_count)
        self._log("专辑脚本启动：%s，目标完成率 %.1f%%"
                  % (self._mode_name(), self.TARGET_RATE))

    def stop(self):
        self.running = False
        self._release_touches()
        if self.state not in (self.ST_DONE, self.ST_STOPPED, "未启动"):
            self.state = self.ST_STOPPED
            self.diagnostic = "脚本已停止"

    def step(self):
        if not self.running:
            return
        self.loop_interval_ms = self.QUEUE_INTERVAL_MS
        try:
            if self._stop_requested():
                self._log("收到停止请求，结束专辑脚本")
                self.state = self.ST_STOPPED
                self.diagnostic = "收到停止请求"
                self.running = False
                self._release_touches()
                return
            handler = {
                self.ST_ENTER: self._step_enter,
                self.ST_DIFFICULTY: self._step_difficulty,
                self.ST_START_BUTTON: self._step_start_button,
                self.ST_AFTER_SELECT: self._step_after_select,
                self.ST_NEXT: self._step_next_song,
                self.ST_SETTLEMENT: self._step_settlement_page,
            }.get(self.state)
            if handler is None:
                self._fatal("内部状态异常：" + str(self.state))
                return
            handler()
        except Exception as exc:  # 页面/OCR 抖不动时不要把整条视频流程打死
            self._error_count += 1
            self.diagnostic = "异常（%d/3）：%s" % (self._error_count, exc)
            self._log("专辑脚本异常：" + repr(exc))
            if self._error_count >= 3:
                self._fatal("连续异常，已停止：%s" % exc)

    # ------------------------------------------------------------------ 页面步骤
    def _step_enter(self):
        """等待“前往演奏”，点击后进入难度选择页。"""
        frame = self._capture()
        if frame is None:
            return
        if self._handle_popup(frame):
            return
        kind = self._page_kind(frame)
        if kind == "difficulty":
            self._enter(self.ST_DIFFICULTY, "已在难度选择页")
            return
        if kind == "settlement":
            self._play_and_settle(frame)
            return
        item = self._find(frame, (self.TEXT_ENTER_PLAY,))
        if item is None:
            self.loop_interval_ms = 400
            self._wait_or_alert("“前往演奏”按钮", frame)
            return
        self._tap_item(item, "前往演奏")
        self._enter(self.ST_DIFFICULTY, "已点击“前往演奏”，等待难度选择页")

    def _step_difficulty(self):
        """难度选择页：识别四个难度的“大音天籁”状态并决定下一步。"""
        frame = self._capture()
        if frame is None:
            return
        if self._handle_popup(frame):
            return
        if self._find(frame, (self.TEXT_RESULT_MARK,)) is not None:
            self._play_and_settle(frame)
            return
        kind = self._page_kind(frame)
        if kind == "difficulty":
            self._evaluate_difficulties(frame)
            return
        if kind == "directory":
            if self._state_elapsed_ms() >= 1500:
                enter = self._find(frame, (self.TEXT_ENTER_PLAY,))
                if enter is not None:
                    self._tap_item(enter, "前往演奏")
                    self._enter(self.ST_DIFFICULTY, "仍停留在目录，重新点击“前往演奏”")
                    return
        self._wait_or_alert("难度选择页", frame)

    def _evaluate_difficulties(self, frame):
        done = self._read_done_difficulties(frame)
        if done is None:
            # OCR 偶发漏字：再抓两帧确认，避免误判后选错难度。
            for _ in range(2):
                time.sleep(1.0)
                retry = self._capture()
                if retry is None:
                    continue
                done = self._read_done_difficulties(retry)
                if done is not None:
                    frame = retry
                    break
        if done is None:
            self._fatal("无法把“大音天籁”对应到四个难度，请检查难度页排版", frame)
            return

        # 本次运行里刚打到 100% 的难度直接记为已完成，避免 OCR 漏字导致重复演奏。
        done = {key: bool(done.get(key)) or key in self._song_done
                for key in self.DIFFICULTY_ORDER}
        self._log("难度状态：" + "、".join(
            "%s=%s" % (self.DIFFICULTY_LABELS[k], "大音天籁" if done[k] else "未达标")
            for k in self.DISPLAY_ORDER))
        self.diagnostic = self._progress_text(
            "已达标 " + "/".join("1" if done[k] else "0" for k in self.DISPLAY_ORDER))

        if self._mode == self.MODE_LEGEND_ONLY:
            if done["legend"]:
                self._back_to_directory("传说已是大音天籁")
                return
            self._select_difficulty(frame, "legend")
            return

        pending = [key for key in self.DIFFICULTY_ORDER if not done[key]]
        if not pending:
            self._back_to_directory("四个难度均已是大音天籁")
            return
        self._select_difficulty(frame, pending[0])

    def _step_start_button(self):
        frame = self._capture()
        if frame is None:
            return
        if self._handle_popup(frame):
            return
        if self._find(frame, (self.TEXT_RESULT_MARK,)) is not None:
            self._play_and_settle(frame)
            return
        kind = self._page_kind(frame)
        if kind == "difficulty":
            item = self._find(frame, (self.TEXT_START_PLAY,))
            if item is not None:
                self._tap_item(item, "开始演奏")
                self._enter(self.ST_PLAYING, "已点击“开始演奏”，调用打歌模块")
                self._play_and_settle()
                return
            if self._state_elapsed_ms() >= 5000 and self._target:
                self._select_difficulty(frame, self._target)
                return
            self._wait_or_alert("“开始演奏”按钮", frame)
            return
        self._wait_or_alert("“开始演奏”按钮", frame)

    def _step_after_select(self):
        """点击“选择曲目”后等待回到“千音雅集”目录。"""
        frame = self._capture()
        if frame is None:
            return
        if self._handle_popup(frame):
            return
        kind = self._page_kind(frame)
        if kind == "settlement":
            # 刚点过“选择曲目”，给页面一点时间关闭；超过 2.5 秒还停在结算页才重新处理。
            if self._may_tap("select_track", 2500):
                self._play_and_settle(frame)
            else:
                self.diagnostic = "等待结算页关闭"
            return
        if kind == "difficulty":
            self._enter(self.ST_DIFFICULTY, "已在难度选择页，重新识别")
            return
        if kind == "directory":
            if self._mode == self.MODE_ALL_DIFFICULTIES:
                self._enter(self.ST_ENTER, "已回到目录，重新进入难度选择页补下一个难度")
            else:
                self._enter(self.ST_NEXT, "已回到目录，准备切换下一首")
            return
        self._wait_or_alert("“千音雅集”目录", frame)

    def _step_next_song(self):
        """规格 4.2：点击下一首之前必须全屏识别到“千音雅集”。"""
        frame = self._capture()
        if frame is None:
            return
        if self._handle_popup(frame):
            return
        if self._find(frame, self.TITLE_ALIASES) is None:
            if self._page_kind(frame) == "difficulty":
                # 上一首结束时若还停在难度页，先按“已完成返回”回目录。
                if self._may_tap("done_return", 1500):
                    self._tap_point(self._done_return, "已完成返回")
                    self._enter(self.ST_NEXT, "停留在难度页，先返回目录")
                # 坐标录错时这里会一直点不动，90 秒提醒一次（仍然不点下一首）。
                if self._return_stuck_at is None:
                    self._return_stuck_at = time.monotonic()
                elif time.monotonic() - self._return_stuck_at >= 90:
                    self._return_stuck_at = time.monotonic()
                    self._alert("返回目录按钮可能未生效",
                                "在难度选择页反复点击“已完成返回”仍未回到目录，"
                                "请检查该固定坐标。\n" + self._context(frame))
                return
            # 未识别到目录属于“等待”，不点击、不发邮件、无限等（规格 4.2）。
            self.loop_interval_ms = 500
            self.diagnostic = self._progress_text(
                "等待目录出现（已等待 %d 秒，不会点击下一首）"
                % (self._state_elapsed_ms() // 1000))
            return
        if self._song_index >= self._song_count:
            self._finish_all()
            return
        self._return_stuck_at = None
        self._tap_point(self._next_song, "下一首")
        self._song_index += 1
        self._song_done = set()
        self._target = None
        self._retry_in_song = 0
        self._enter(self.ST_ENTER,
                    "已切换至第 %d/%d 首，等待“前往演奏”"
                    % (self._song_index, self._song_count))

    def _step_settlement_page(self):
        frame = self._capture()
        if frame is None:
            return
        if self._handle_popup(frame):
            return
        if self._find(frame, (self.TEXT_RESULT_MARK,)) is not None:
            self._play_and_settle(frame)
            return
        self._wait_or_alert("结算页“演奏完成率”", frame)

    # ------------------------------------------------------------------ 难度
    def _row_geometry(self, frame):
        """用难度名称做锚点，拟合四行的 Y 坐标；缺失的行用线性外推补齐。"""
        found = {}
        for key in self.DISPLAY_ORDER:
            aliases = self.DIFFICULTY_ALIASES[key]
            hits = [item for item in frame.texts if self._matches(item.text, aliases)]
            if hits:
                found[key] = self._pick_anchor(hits, aliases, frame)
        if len(found) < 2:
            return None

        points = [(self.DISPLAY_ORDER.index(key), item.center_y)
                  for key, item in found.items()]
        count = len(points)
        mean_i = sum(p[0] for p in points) / count
        mean_y = sum(p[1] for p in points) / count
        denominator = sum((p[0] - mean_i) ** 2 for p in points)
        slope = (sum((p[0] - mean_i) * (p[1] - mean_y) for p in points) / denominator
                 if denominator else 0.0)
        intercept = mean_y - slope * mean_i

        xs = sorted(item.center_x for item in found.values())
        fallback_x = xs[len(xs) // 2]
        tolerance = min(max(0.028 * frame.height, 0.45 * abs(slope)), 0.13 * frame.height)

        rows = {}
        for index, key in enumerate(self.DISPLAY_ORDER):
            item = found.get(key)
            rows[key] = {
                "x": item.center_x if item else fallback_x,
                "y": item.center_y if item else intercept + slope * index,
                "tolerance": tolerance,
                "estimated": item is None,
            }
        return rows

    def _pick_anchor(self, hits, aliases, frame):
        """同名文字可能出现多次，优先精确匹配，其次取最靠近“大音天籁”簇的一条。"""
        exact = [item for item in hits if self._compact(item.text) in aliases]
        pool = exact or hits
        ratings = self._rating_items(frame)
        if ratings:
            median = sorted(item.center_y for item in ratings)[len(ratings) // 2]
            return min(pool, key=lambda item: abs(item.center_y - median))
        return max(pool, key=lambda item: item.bottom - item.top)

    def _rating_items(self, frame):
        return [item for item in frame.texts
                if self._matches(item.text, self.RATING_ALIASES)]

    def _read_done_difficulties(self, frame):
        """返回 {难度: 是否已是“大音天籁”}；无法定位四行时返回 None。"""
        rows = self._row_geometry(frame)
        if rows is None:
            return None
        ratings = self._rating_items(frame)
        done = {}
        for key in self.DISPLAY_ORDER:
            row = rows[key]
            if not ratings:
                done[key] = False
                continue
            nearest = min(ratings, key=lambda item: abs(item.center_y - row["y"]))
            done[key] = abs(nearest.center_y - row["y"]) <= row["tolerance"]
        return done

    def _select_difficulty(self, frame, key):
        rows = self._row_geometry(frame)
        label = self.DIFFICULTY_LABELS[key]
        if rows is None or key not in rows:
            self._fatal("未能定位“%s”难度按钮" % label, frame)
            return
        row = rows[key]
        self._target = key
        # 名称漏识别时用拟合出的行位置；X 取同列锚点中位数，仍在同一列上。
        self._tap_xy(row["x"], row["y"],
                     "难度·%s%s" % (label, "（按行位置）" if row["estimated"] else ""))
        self._enter(self.ST_START_BUTTON,
                    "已选择“%s”难度，等待“开始演奏”" % label)

    def _back_to_directory(self, reason):
        self._may_tap("done_return", 0)   # 记下这次点击，避免页面未切走时又补一刀
        self._tap_point(self._done_return, "已完成返回")
        self._enter(self.ST_NEXT, reason + "，返回目录后切换下一首")

    # ------------------------------------------------------------------ 打歌 + 结算
    def _play_and_settle(self, frame=None):
        """打歌 -> 结算 -> 未达标就再次演奏，直到 100.0%。"""
        while True:
            if self._stop_requested():
                self.state = self.ST_STOPPED
                self.diagnostic = "收到停止请求"
                self.running = False
                self._release_touches()
                return
            if frame is None:
                result = self._run_song()
                kind = result[0]
                if kind == "stop":
                    self.state = self.ST_STOPPED
                    self.diagnostic = "收到停止请求"
                    self.running = False
                    self._release_touches()
                    return
                if kind == "not_started":
                    self._enter(self.ST_START_BUTTON,
                                "未检测到演奏开始，重新等待“开始演奏”")
                    return
                if kind == "error":
                    self._fatal(result[1], self._last_frame)
                    return
                frame = result[1]

            rate, frame = self._read_rate_with_retry(frame)
            if rate is None:
                self._fatal("结算页已出现，但读不到“演奏完成率”的数值", frame)
                return

            if rate >= self.TARGET_RATE - self.RATE_EPSILON:
                self._on_song_cleared(rate, frame)
                return

            self._retry_in_song += 1
            self._total_retries += 1
            self._enter(self.ST_SETTLEMENT,
                        self._progress_text("完成率 %.1f%%，未达 100.0%%，再次演奏"
                                            % rate))
            self._log("第 %d 首 %s 完成率 %.1f%%，第 %d 次“再次演奏”"
                      % (self._song_index, self._target_label(), rate,
                         self._retry_in_song))
            if self._retry_in_song in (10, 30, 60):
                self._alert("同一首已重试 %d 次仍未达到 100%%" % self._retry_in_song,
                            "脚本会继续无限重试。\n" + self._context(frame))
            item = self._find(frame, (self.TEXT_RETRY_PLAY,))
            if item is None:
                self._fatal("结算未达标，但界面上找不到“再次演奏”", frame)
                return
            self._tap_item(item, "再次演奏")
            # 不重新选曲、不重新选难度，直接再次调用打歌模块。
            frame = None

    def _on_song_cleared(self, rate, frame):
        if self._target and self._target not in self._song_done:
            self._song_done.add(self._target)
            self._completed_difficulties += 1
        self._retry_in_song = 0
        self._enter(self.ST_SETTLEMENT,
                    self._progress_text("本次完成率 %.1f%%" % rate))
        self._log("第 %d 首 %s 达成 %.1f%%"
                  % (self._song_index, self._target_label(), rate))
        item = self._find(frame, (self.TEXT_SELECT_TRACK,))
        if item is None:
            self._alert("结算页找不到“选择曲目”",
                        "已完成 100.0%，但无法点击“选择曲目”。\n" + self._context(frame))
            self._enter(self.ST_AFTER_SELECT, "等待“选择曲目”")
            return
        self._may_tap("select_track", 0)  # 记下这次点击，避免页面未切走时又补一刀
        self._tap_item(item, "选择曲目")
        self._enter(self.ST_AFTER_SELECT, "已点击“选择曲目”，等待返回目录")

    def _run_song(self):
        """阻塞打歌，直到出现结算页 / 需要重新点开始 / 出错 / 被要求停止。"""
        music = self._music
        try:
            music.start()
        except Exception as exc:
            return ("error", "打歌模块初始化失败：%s" % exc)

        self._enter(self.ST_PLAYING, self._progress_text("六轨打歌中"))
        self.loop_interval_ms = self.PLAY_INTERVAL_MS
        started = time.monotonic()
        first_note = None
        last_note = 0.0
        last_check = started
        presses = 0
        errors = 0
        quiet_seconds = self._quiet_ms / 1000.0
        grace_seconds = self._first_note_grace_ms / 1000.0
        max_seconds = self.MAX_SONG_MS / 1000.0

        while True:
            if self._stop_requested():
                self._release_touches()
                return ("stop",)
            try:
                music.step()
            except Exception as exc:
                errors += 1
                self._release_touches()
                self._log("打歌模块异常（%d/3）：%s" % (errors, exc))
                if errors >= 3:
                    return ("error", "打歌模块连续异常：%s" % exc)
                time.sleep(0.8)
                try:
                    music = MusicBot(self.host)
                    music.start()
                    self._music = music
                    presses = 0
                except Exception as inner:
                    return ("error", "打歌模块无法恢复：%s" % inner)
                continue

            now = time.monotonic()
            # 用“是否产生新的按键”作为音符活动信号：静态色块只会在第一帧触发一次，
            # 不会把非演奏页误判成一直在打歌。
            current = int(getattr(music, "press_count", 0) or 0)
            if current > presses:
                presses = current
                if first_note is None:
                    first_note = now
                last_note = now
            elapsed = now - started

            if first_note is None:
                # 迟迟没有按键：可能是还没进演奏、卡在加载页或其实已经结算。
                if elapsed < grace_seconds or (now - last_check) < 15.0:
                    continue
                last_check = now
                self._release_touches()
                frame = self._capture()
                if frame is not None:
                    if self._find(frame, (self.TEXT_RESULT_MARK,)) is not None:
                        return ("settlement", frame)
                    if self._page_kind(frame) == "difficulty":
                        return ("not_started",)
                if elapsed >= max_seconds:
                    return ("error", "长时间没有检测到音符，也未出现结算页")
                continue

            hard_limit = elapsed >= max_seconds
            if (now - max(last_note, last_check, first_note)) < quiet_seconds and not hard_limit:
                continue

            # 静音候选时刻：松开所有触点后再 OCR，避免残留触点卡在谱面上。
            self._release_touches()
            frame = self._capture()
            last_check = now
            if frame is not None and self._find(frame, (self.TEXT_RESULT_MARK,)) is not None:
                return ("settlement", frame)
            if hard_limit:
                return ("error", "单次演奏超过 %d 分钟仍未出现结算页"
                        % (self.MAX_SONG_MS // 60000))
            self.diagnostic = self._progress_text("打歌中（静音复核）")

    # ------------------------------------------------------------------ 结算数值
    def _read_rate_with_retry(self, frame):
        rate = self._read_rate(frame)
        tries = 0
        while rate is None and tries < 6:
            tries += 1
            time.sleep(1.0)
            retry = self._capture()
            if retry is None:
                continue
            frame = retry
            if self._handle_popup(frame):
                continue
            rate = self._read_rate(frame)
        return rate, frame

    def _read_rate(self, frame):
        mark = None
        for item in frame.texts:
            if self.TEXT_RESULT_MARK in self._compact(item.text):
                mark = item
                break

        candidates = []
        for item in frame.texts:
            text = str(item.text or "").replace("％", "%")
            for match in re.finditer(r"(\d{1,3}(?:[.,]\d{1,2})?)\s*%", text):
                try:
                    candidates.append((item, float(match.group(1).replace(",", "."))))
                except ValueError:
                    continue
        if not candidates:
            # 个别机型/字号会把“%”识别丢，退化为“完成率标签同高度附近的 x.y”。
            if mark is not None:
                for item in frame.texts:
                    if abs(item.center_y - mark.center_y) > 0.05 * frame.height:
                        continue
                    match = re.search(r"(\d{1,3}\.\d)", str(item.text or ""))
                    if match:
                        self._log("百分比符号缺失，按同高度的数值解析")
                        return float(match.group(1))
            return None
        if mark is not None:
            for item, value in candidates:
                if item is mark:
                    return value
            nearest = min(candidates, key=lambda pair: abs(pair[0].center_y - mark.center_y))
            return nearest[1]
        # 标签漏识别时只在全屏仅有一个百分比时采信，避免读到“最高完成率”等旁值。
        if len(candidates) == 1:
            self._log("未识别到“演奏完成率”标签，按全屏唯一百分比处理")
            return candidates[0][1]
        return None

    # ------------------------------------------------------------------ 页面辅助
    def _capture(self):
        try:
            frame = Frame.from_host(self.host.capture())
        except Exception as exc:
            self._capture_failures += 1
            self.diagnostic = "截图/文字识别失败（%d/5）" % self._capture_failures
            self._log("截图或 OCR 失败：%s" % exc)
            if self._capture_failures >= 5:
                self._fatal("连续 5 次截图/OCR 失败，已停止")
            return None
        self._capture_failures = 0
        self._error_count = 0
        self._last_frame = frame
        self._mapper = CoordinateMapper(frame.width, frame.height)
        return frame

    def _page_kind(self, frame):
        """settlement / difficulty / directory / other，按“先具体后兜底”的顺序判定。"""
        if self._find(frame, (self.TEXT_RESULT_MARK,)) is not None:
            return "settlement"
        if self._find(frame, (self.TEXT_START_PLAY,)) is not None:
            return "difficulty"
        if self._find(frame, (self.TEXT_ENTER_PLAY,)) is not None:
            return "directory"
        if self._find(frame, self.TITLE_ALIASES) is not None:
            return "directory"
        # “开始演奏”漏识别时，用四个难度名 + 评级文字兜底，避免一直干等。
        if self._row_geometry(frame) is not None and self._rating_items(frame):
            return "difficulty"
        return "other"

    def _handle_popup(self, frame):
        """弹窗/网络异常：先邮件提醒，再尝试点“重试/确定”这类安全按钮。"""
        word = None
        for candidate in self.POPUP_WORDS:
            if self._find(frame, (candidate,)) is not None:
                word = candidate
                break
        if word is None:
            return False
        body = "检测到可能阻断流程的提示：%s\n%s" % (word, self._context(frame))
        button = None
        label = ""
        for candidate in self.POPUP_BUTTONS:
            button = self._find(frame, (candidate,))
            if button is not None:
                label = candidate
                break
        if button is None:
            self._alert("检测到弹窗（未找到可点击按钮）", body)
            return False
        self._alert("检测到弹窗，已尝试关闭", body)
        self._tap_item(button, "弹窗·" + label)
        self._log("已点击弹窗按钮：" + label)
        return True

    def _wait_or_alert(self, target, frame=None):
        elapsed = self._state_elapsed_ms()
        self.diagnostic = self._progress_text("等待%s（%d 秒）" % (target, elapsed // 1000))
        if elapsed >= self._page_timeout_ms:
            self._alert("等待界面超时：%s" % target,
                        "等待%s超过 %d 秒。脚本会继续等待，目标界面出现后自动继续。\n%s"
                        % (target, self._page_timeout_ms // 1000,
                           self._context(frame or self._last_frame)))

    # ------------------------------------------------------------------ 动作
    def _may_tap(self, key, gap_ms):
        """同一动作在页面还没切走时不要连点，避免把一次慢加载点成两次。"""
        now = time.monotonic()
        last = self._last_tap_at.get(key, 0.0)
        if now - last < gap_ms / 1000.0:
            return False
        self._last_tap_at[key] = now
        return True

    def _tap_item(self, item, label=""):
        self._tap_xy(item.center_x, item.center_y, label)
    def _tap_xy(self, x, y, label=""):
        try:
            self.host.tap(int(round(x)), int(round(y)))
            self._log("点击%s @(%d,%d)" % (label or "文字目标", int(round(x)), int(round(y))))
        except Exception as exc:
            self._log("点击%s失败：%s" % (label, exc))

    def _tap_point(self, point, label):
        if self._mapper is None:
            self._log("尚未取得屏幕尺寸，无法点击" + label)
            return
        # 坐标记录在 1280x720 横屏参考系里，这里按当前截图尺寸换算成屏幕像素。
        screen_x, screen_y = self._mapper.to_screen(point[0], point[1])
        self._tap_xy(screen_x, screen_y, label)

    def _release_touches(self):
        music = self._music
        release = getattr(music, "_release_all", None)
        try:
            if callable(release):
                release()
            else:
                self.host.releaseAllTouches()
        except Exception as exc:
            self._log("释放触点失败：%s" % exc)

    def _stop_requested(self):
        check = getattr(self.host, "isStopRequested", None)
        if not callable(check):
            return False
        try:
            return bool(check())
        except Exception:
            return False

    # ------------------------------------------------------------------ 状态/日志/邮件
    def _enter(self, state, diagnostic=""):
        self.state = state
        self._state_since = time.monotonic()
        if diagnostic:
            self.diagnostic = diagnostic
        self.loop_interval_ms = self.PLAY_INTERVAL_MS if state == self.ST_PLAYING \
            else self.QUEUE_INTERVAL_MS

    def _state_elapsed_ms(self):
        return int((time.monotonic() - self._state_since) * 1000)

    def _target_label(self):
        return self.DIFFICULTY_LABELS.get(self._target, "—")

    def _progress_text(self, detail):
        prefix = "第%d/%d首 · %s" % (self._song_index, self._song_count, self._target_label())
        return prefix + (" · " + detail if detail else "")

    def _compact(self, text):
        return re.sub(r"\s+", "", str(text or ""))

    def _matches(self, text, aliases):
        compact = self._compact(text)
        return any(alias in compact for alias in aliases)

    def _find(self, frame, aliases):
        if frame is None:
            return None
        for item in frame.texts:
            if self._matches(item.text, aliases):
                return item
        return None

    def _screen_dump(self, frame, limit=28):
        if frame is None:
            return "（无截图）"
        parts = []
        for item in frame.texts[:limit]:
            text = self._compact(item.text)
            if text:
                parts.append("%s@(%d,%d)" % (text, item.center_x, item.center_y))
        return " | ".join(parts) if parts else "（本帧 OCR 没有文字）"

    def _context(self, frame):
        logs = " / ".join(self._recent_logs[-6:])
        return ("状态：%s\n歌曲：第 %d/%d 首\n模式：%s\n目标难度：%s\n已重试：%d 次\n"
                "画面文字：%s\n最近日志：%s" % (self.state, self._song_index, self._song_count,
                                          self._mode_name(), self._target_label(),
                                          self._retry_in_song, self._screen_dump(frame), logs))

    def _alert(self, subject, body):
        """同一现象 5 分钟内只发一封，避免无限重试刷爆邮箱。"""
        signature = subject + "|" + self._compact(body)[:160]
        now = time.monotonic()
        if signature == self._last_alert_signature and now - self._last_alert_at < 300:
            return False
        self._last_alert_signature = signature
        self._last_alert_at = now
        full = "%s\n\n%s\n\n时间：%s" % (
            body, self._progress_text(""), time.strftime("%Y-%m-%d %H:%M:%S"))
        sender = getattr(self.host, "sendAlbumAlert", None)
        queued = False
        if callable(sender):
            try:
                queued = bool(sender("专辑脚本 · " + subject, full))
            except Exception as exc:
                self._log("发送邮件失败：%s" % exc)
        self._log("邮件提醒：%s（%s）" % (subject, "已提交" if queued else "未提交"))
        return queued

    def _fatal(self, reason, frame=None):
        self._alert("脚本停止，需要人工处理", reason + "\n" + self._context(frame))
        self.state = self.ST_STOPPED
        self.diagnostic = reason
        self._log("脚本停止：" + reason)
        self.running = False
        self._release_touches()

    def _finish_all(self):
        self.state = self.ST_DONE
        self.diagnostic = "%d 首全部完成，补完 %d 个难度，重试 %d 次" % (
            self._song_count, self._completed_difficulties, self._total_retries)
        self._log(self.diagnostic)
        if self._send_complete_email:
            self._alert("专辑处理完成",
                        "专辑 %d 首已全部按“%s”处理完成。\n补完难度：%d 个\n累计重试：%d 次"
                        % (self._song_count, self._mode_name(),
                           self._completed_difficulties, self._total_retries))
        self.running = False
        self._release_touches()

    def _log(self, message):
        line = str(message)
        self._recent_logs.append(line)
        self._recent_logs = self._recent_logs[-20:]
        logger = getattr(self.host, "log", None)
        if callable(logger):
            try:
                logger(line)
            except Exception:
                pass
