# -*- coding: utf-8 -*-
"""专辑自动完成脚本 — 异常邮件提醒模块。

只使用 Python 标准库（smtplib / ssl / email），SMTP 配置未确认前为纯日志模式，
不会阻塞主流程：任何邮件异常只记录日志，绝不抛出。
"""
import smtplib
import ssl
import time
from email.header import Header
from email.mime.text import MIMEText


class EmailAlerter:
    """带冷却去重的邮件告警器。"""

    def __init__(self, cfg, log=None):
        self.cfg = cfg
        self._log = log or (lambda m: None)
        email_cfg = getattr(cfg, "EMAIL_CONFIG", {}) or {}
        self.email_cfg = dict(email_cfg)
        self.enabled = bool(getattr(cfg, "EMAIL_ENABLED", False))
        self.last_sent = {}  # key -> epoch ms

    # ---------------------------------------------------------- public

    def send(self, key, subject, body, force=False):
        """发送告警邮件。key 用于同类告警冷却去重；force=True 跳过冷却。"""
        now = int(time.time() * 1000)
        cooldown = int(getattr(self.cfg, "ALERT_COOLDOWN_MS", 300_000))
        if not force:
            last = self.last_sent.get(key, 0)
            if now - last < cooldown:
                self._log("邮件冷却中，跳过：" + subject)
                return False
        self.last_sent[key] = now

        if not self.enabled:
            self._log("[邮件未启用] " + subject + " | " + body)
            return False
        return self._deliver(subject, body)

    # ---------------------------------------------------------- internal

    def _deliver(self, subject, body):
        c = self.email_cfg
        host = c.get("smtp_host")
        user = c.get("smtp_user")
        password = c.get("smtp_password")
        from_addr = c.get("from_addr") or user
        to_addrs = [a for a in (c.get("to_addrs") or []) if a]
        if not host or not from_addr or not to_addrs:
            self._log("[邮件配置不完整] " + subject + " | " + body)
            return False

        prefix = c.get("subject_prefix") or ""
        message = MIMEText(body, "plain", "utf-8")
        message["Subject"] = Header(prefix + subject, "utf-8")
        message["From"] = from_addr
        message["To"] = ",".join(to_addrs)

        port = int(c.get("smtp_port", 465))
        use_ssl = bool(c.get("use_ssl", True))
        try:
            if use_ssl:
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(host, port, timeout=30, context=context) as server:
                    if user:
                        server.login(user, password)
                    server.sendmail(from_addr, to_addrs, message.as_string())
            else:
                with smtplib.SMTP(host, port, timeout=30) as server:
                    server.ehlo()
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()
                    if user:
                        server.login(user, password)
                    server.sendmail(from_addr, to_addrs, message.as_string())
            self._log("告警邮件已发送：" + subject)
            return True
        except Exception as error:
            self._log("告警邮件发送失败：" + str(error))
            return False
