# -*- coding: utf-8 -*-
"""专辑自动完成脚本 — 启动前配置。

所有点击坐标均为 GameBot 既有参考坐标系（横屏 1280×720）内的固定坐标，
由 CoordinateMapper 映射到实际屏幕分辨率，与游戏挂机/音游模块坐标体系一致。
"""

# ============================ 任务参数 ============================

# 完成模式：
#   "legend_only"       — 每首歌只补「传说」难度
#   "all_difficulties"  — 每首歌补齐全部四个难度
COMPLETION_MODE = "legend_only"

# 专辑内固定歌曲数量
ALBUM_SONG_COUNT = 12

# 目标完成率（结算判定阈值，单位 %）
TARGET_COMPLETION_RATE = 100.0

# 重试上限。None = 无限重试。
MAX_RETRY = None

# 断点续跑时的起始歌曲序号（1-based）。重新启动脚本时按需修改。
START_SONG_INDEX = 1

# 补难度优先级：传说 > 大师 > 困难 > 普通
DIFFICULTY_PRIORITY = ("传说", "大师", "困难", "普通")

# ============================ 用户自定义固定坐标 ============================

# 「下一首」按钮固定坐标（目录页 → 下一首歌的难度选择页）
# 【待确认】请填入实际坐标
COORD_NEXT_SONG = (640, 360)

# 难度选择页「目标已完成」时返回专辑目录的固定坐标
# 【待确认】请填入实际坐标
COORD_DIFFICULTY_DONE_RETURN = (80, 60)

# ============================ 目录门检查（千音雅集） ============================

# 启动与每次点击 coord_next_song 前，全屏 OCR 必须识别到该文字：
# - 启动时：识别到 → 允许运行；未识别到 → 直接停止（仅启动时检查一次）
# - 点击下一首前：识别到 → 确认回到目录，点击下一首；
#   未识别到 → 继续等待，不点击，不报错（暂定无限等待）
CATALOG_GATE_WORD = "千音雅集"

# ============================ 页面识别关键词 ============================
# 【待确认】以下关键词需与实际游戏页面 OCR 文案核对；每个页面命中任意一个即认定。
# 判定优先级：结算页 > 难度选择页 > 目录页（避免关键词交叉误判）。

KEYWORDS_CATALOG = ("千音雅集", "专辑", "曲目列表", "歌曲列表")
KEYWORDS_DIFFICULTY = ("难度选择", "选择难度", "难度")

# 难度名称关键词（含繁体/英文兜底）
DIFFICULTY_KEYWORDS = {
    "传说": ("传说", "傳說", "LEGEND", "Legend"),
    "大师": ("大师", "大師", "MASTER", "Master"),
    "困难": ("困难", "困難", "HARD", "Hard"),
    "普通": ("普通", "NORMAL", "Normal"),
}

# 难度页完成标记：出现在难度名附近即视为该难度已 100% 完成 / 未完成
DIFFICULTY_DONE_WORDS = ("已完成", "已通关", "CLEAR", "Clear")
DIFFICULTY_NOT_DONE_WORDS = ("未通关", "未完成", "尚未", "NEW")

# ============================ 单曲流程入口与难度状态识别 ============================

# 单曲流程入口按钮文案：点击后等待难度选择页出现
PLAY_ENTRY_WORDS = ("前往演奏",)

# 难度选择页全屏识别的难度评级标记；按屏幕位置映射到四个难度
DIFFICULTY_STATUS_WORD = "大音天籁"

# 四个难度的锚点坐标（参考系 1280×720）：屏幕上的「大音天籁」映射到
# 距离最近的难度锚点，得到 difficulty_status = {难度: bool}。
# 【待确认】请按真机难度选择页布局调整（同难度的标记应最靠近自己的锚点）。
DIFFICULTY_ANCHORS = {
    "普通": (240, 360),
    "困难": (560, 360),
    "大师": (880, 360),
    "传说": (1200, 360),
}

# 「大音天籁」距所有锚点都超过该距离（参考像素）时忽略（非难度区域的同名词）
DIFFICULTY_MATCH_MAX_DIST = 350

# 结算页文案
# 结算页判定依据：全屏识别「演奏完成率」；目标完成率固定 100.0%
KEYWORDS_SETTLEMENT = ("演奏完成率",)
SETTLEMENT_RATE_WORDS = ("演奏完成率", "完成率", "完成度", "达成率")
# 未达 100.0% 时点击的重试按钮：点击后直接调用打歌模块，
# 不重新选曲、不重新选难度，打完再次等待「演奏完成率」，无限重试。
SETTLEMENT_RETRY_WORDS = ("再次演奏",)
# （备用）返回类按钮文案，当前流程未使用
SETTLEMENT_CONTINUE_WORDS = ("继续", "返回", "确定")

# 结算达到 100.0% 后点击的按钮（单曲流程收尾，回目录切下一首）
SETTLEMENT_SELECT_SONG_WORDS = ("选择曲目",)

# 开始演奏按钮文案
PLAY_START_WORDS = ("开始演奏", "开始", "演奏")

# 演奏/结算异常弹窗兜底词（仅在识别状态处理，避免与结算按钮冲突）
POPUP_WORDS = ("确定", "知道了", "关闭")

# ============================ 异常处理 ============================

# 网络异常文案（全屏命中任一即视为网络异常 → 邮件提醒）
EXCEPTION_NETWORK_WORDS = ("网络异常", "网络错误", "连接失败", "连接超时", "网络连接失败")

# 加载失败文案（命中任一 → 邮件提醒）
EXCEPTION_LOAD_WORDS = ("加载失败", "载入失败", "加载错误")

# 发送异常邮件后的动作【待确认】：
#   "continue" — 继续当前流程/继续重试（默认，与无限重试一致）
#   "pause"    — 暂停，等待人工重启
#   "stop"     — 停止脚本
# 注意：点击下一首前未识别到「千音雅集」属于正常等待，不发邮件、不受此配置影响。
ON_ALERT_ACTION = "continue"

# ============================ 难度页 OCR 解析参数 ============================

# 难度名附近查找完成率百分比文本的搜索半径（参考像素）
RATE_SEARCH_RADIUS_X = 350
RATE_SEARCH_RADIUS_Y = 60

# ============================ 等待与超时（毫秒） ============================

# 等待下一个目标出现时的 OCR 轮询间隔
POLL_INTERVAL_MS = 300

# 点击后等待「下一个目标出现」的超时；超时即判定异常并发邮件
TARGET_WAIT_TIMEOUT_MS = 15000

# 「开始演奏」点击后进入演奏画面的确认超时
PLAY_CONFIRM_TIMEOUT_MS = 10000

# 单次演奏最长时长（超时视为卡死：停止黑盒引擎、邮件告警、进入恢复）
PLAY_TIMEOUT_MS = 600_000

# 连续 N 帧未识别到任何已知页面才判定未知页面（避免过渡动画误判）
UNKNOWN_PAGE_CONFIRM_FRAMES = 3
UNKNOWN_PAGE_TIMEOUT_MS = 30000

# 演奏期间结算页巡检方式：
#   "background" — 后台线程 OCR 巡检（推荐；不阻塞黑盒演奏节拍，不会因 OCR 卡顿漏按键）
#   "inline"     — 主循环内同步巡检（OCR 期间演奏节拍会停顿，仅作兑底）
#   "off"        — 不巡检（仅靠 PLAY_TIMEOUT_MS 超时兑底）
SETTLE_CHECK_MODE = "background"

# 演奏期间结算页 OCR 巡检间隔（越小越灵敏，但 OCR 开销越大）
SETTLE_CHECK_INTERVAL_MS = 5000

# 恢复动作：按返回键次数与等待
RECOVERY_MAX_BACKS = 3
RECOVERY_WAIT_TIMEOUT_MS = 10000

# 连续失败多少次发一封重试提醒邮件
RETRY_ALERT_EVERY = 5

# 同类告警邮件的最小发送间隔（防止刷屏）
ALERT_COOLDOWN_MS = 300_000

# ============================ 邮件 SMTP 配置【待确认】 ============================
# SMTP 信息确认后把 EMAIL_ENABLED 改为 True 并补齐字段。

EMAIL_ENABLED = False

EMAIL_CONFIG = {
    "smtp_host": None,        # 【待确认】例如 "smtp.example.com"
    "smtp_port": 465,         # 【待确认】SSL 常用 465，STARTTLS 常用 587
    "smtp_user": None,        # 【待确认】SMTP 登录账号
    "smtp_password": None,    # 【待确认】SMTP 授权码/密码
    "use_ssl": True,          # False 时尝试 STARTTLS
    "from_addr": None,        # 【待确认】发件人
    "to_addrs": [],           # 【待确认】收件人列表，如 ["you@example.com"]
    "subject_prefix": "[专辑挂机]",
}
