"""Host-side smoke test for the album automation state machine.

It replaces the phone with a tiny simulated game: pages are plain text frames,
taps on those frames change the page, and the six-lane sampler is fed a short
note stream. This validates the album flow (difficulty mapping, retry, next-song
confirmation) without Android, Root or a real device.

Run: python ALBUM_SCRIPT_SMOKE_TEST.py
"""
import sys
import time

from app.src.main.python.python.album_bot import AlbumBot

WIDTH, HEIGHT = 1280, 720
NEXT_SONG = (1200, 660)
DONE_RETURN = (100, 660)
DIFFICULTY_ROWS = {"normal": 300, "hard": 380, "master": 460, "legend": 540}
DIFFICULTY_NAMES = {"normal": "普通", "hard": "困难", "master": "大师", "legend": "传说"}


def item(text, x, y):
    return {"text": text, "left": x - 45, "top": y - 16, "right": x + 45, "bottom": y + 16}


class FakeGame:
    """Simulated album: page text, difficulty ratings, a short note stream, tap routing."""

    def __init__(self, mode, done_by_song=None, first_attempt_rate=98.0, directory_delay=2):
        self.mode = mode
        self.done = {song: set(values) for song, values in (done_by_song or {}).items()}
        self.first_attempt_rate = first_attempt_rate
        self.directory_delay = directory_delay
        self.song = 1
        self.page = "directory"
        self.pending_page = None
        self.pending_delay = 0
        self.selected = None
        self.attempts = 0
        self.notes = 0
        self.rate = 100.0
        self.page_during_next_tap = None
        self.tap_log = []
        self.violations = []

    # ---------- album config ----------
    def getAlbumConfig(self):
        return [NEXT_SONG[0], NEXT_SONG[1], DONE_RETURN[0], DONE_RETURN[1],
                1 if self.mode == "all" else 0, 12, 5000, 200, 300, 0]

    def getMusicCoordinateConfig(self):
        return [778, 1100, 1440, 1780, 2100, 2440, 1210, 230, -1]

    def isStopRequested(self):
        return False

    def sendAlbumAlert(self, subject, body):
        self.alerts = getattr(self, "alerts", []) + [subject]
        return True

    def log(self, message):
        pass

    # ---------- page frames ----------
    def _switch(self, page, delay=0):
        self.pending_page = page
        self.pending_delay = delay

    def _texts(self):
        if self.page == "directory":
            return [item("千音雅集", 640, 60), item("前往演奏", 1000, 620),
                    item("夜半歌声", 400, 300)]
        if self.page == "difficulty":
            texts = [item(DIFFICULTY_NAMES[key], 640, y)
                     for key, y in DIFFICULTY_ROWS.items()]
            texts.append(item("开始演奏", 640, 650))
            for key in self.done.get(self.song, ()):
                texts.append(item("大音天籁", 950, DIFFICULTY_ROWS[key]))
            return texts
        if self.page == "settlement":
            return [item("演奏完成率", 640, 300),
                    item("%.1f%%" % self.rate, 640, 340),
                    item("再次演奏", 480, 620), item("选择曲目", 800, 620)]
        return []

    def capture(self):
        if self.pending_page is not None:
            if self.pending_delay > 0:
                self.pending_delay -= 1
            else:
                self.page = self.pending_page
                self.pending_page = None
        return {"width": WIDTH, "height": HEIGHT, "texts": self._texts(), "enemies": []}

    # ---------- taps ----------
    def tap(self, x, y):
        if self.page == "directory" and abs(x - NEXT_SONG[0]) < 30 and abs(y - NEXT_SONG[1]) < 30:
            self.page_during_next_tap = self.page
            self.tap_log.append(("coord", "next_song"))
            if len(self.done.get(self.song, ())) < (4 if self.mode == "all" else 1):
                self.violations.append("第 %d 首未补完就点了下一首" % self.song)
            self.song += 1
            return
        if self.page == "difficulty" and abs(x - DONE_RETURN[0]) < 30 and abs(y - DONE_RETURN[1]) < 30:
            self.tap_log.append(("coord", "done_return"))
            self._switch("directory", self.directory_delay)
            return

        for text in self._texts():
            if text["left"] <= x <= text["right"] and text["top"] <= y <= text["bottom"]:
                self._tap_text(text["text"])
                return
        self.tap_log.append(("miss", (x, y)))

    def _tap_text(self, text):
        self.tap_log.append(("text", text))
        if text == "前往演奏":
            self._switch("difficulty", 1)
        elif text == "开始演奏":
            self.attempts += 1
            self.rate = self.first_attempt_rate if self.attempts == 1 else 100.0
            self.notes = 24
            self.page = "playing"
        elif text == "再次演奏":
            self.attempts += 1
            self.rate = 100.0
            self.notes = 12
            self.page = "playing"
        elif text == "选择曲目":
            if self.rate >= 99.95:
                self.done.setdefault(self.song, set()).add(self.selected)
            self._switch("directory", self.directory_delay)
        elif text in DIFFICULTY_NAMES.values():
            self.selected = next(key for key, name in DIFFICULTY_NAMES.items() if name == text)

    # ---------- six-lane sampler ----------
    def initializeMultiTouch(self, width, height):
        return "fake-type-b"

    def captureBlueValues(self, xs, y):
        if self.notes > 0:
            self.notes -= 1
            lane = self.notes % 2
            blue = [255] * 6
            blue[lane] = 90
            return {"blue": blue, "captureMs": 0, "decodeMs": 0}
        if self.page == "playing":
            self.page = "settlement"
        return {"blue": [255] * 6, "captureMs": 0, "decodeMs": 0}

    def updateTouches(self, states, xs, ys):
        return 0

    def releaseAllTouches(self):
        pass


def run(bot, limit=4000):
    bot.start()
    # Page-mode timeouts stay generous; only the play-loop quiet window is shortened.
    bot._quiet_ms = 200
    bot._first_note_grace_ms = 300
    bot.MAX_SONG_MS = 15000
    start = time.monotonic()
    steps = 0
    while bot.running and steps < limit:
        bot.step()
        steps += 1
        if time.monotonic() - start > 90:
            raise AssertionError("模拟运行超时，可能状态机卡住：state=%s diag=%s"
                                 % (bot.state, bot.diagnostic))
    bot.stop()
    return steps


def test_legend_only_retries_and_advances():
    game = FakeGame("legend")
    bot = AlbumBot(game)
    run(bot)
    assert not game.violations, game.violations
    assert bot.state == bot.ST_DONE, (bot.state, bot.diagnostic)
    # 第 12 首处理完直接收尾，不再点下一首，所以只切了 11 次。
    assert game.song == 12, game.song
    # 第 1 首第一次 98% 会“再次演奏”，第二次 100% 才切下一首。
    assert ("text", "再次演奏") in game.tap_log
    assert game.tap_log.count(("coord", "next_song")) == 11
    # legend_only 每首只选一次难度并点一次“开始演奏”；重试走“再次演奏”，不会再选曲选难度。
    starts = [entry for entry in game.tap_log if entry == ("text", "开始演奏")]
    assert len(starts) == 12, len(starts)
    assert len([e for e in game.tap_log if e == ("text", "传说")]) == 12
    print("legend_only: 12 首完成、98% -> 再次演奏 -> 100% 通过")


def test_all_difficulties_priority_and_no_early_advance():
    # 第 1 首的传说已经是大音天籁，其余三首难度都要补。
    game = FakeGame("all", done_by_song={1: {"legend"}}, first_attempt_rate=100.0)
    bot = AlbumBot(game)
    run(bot)
    assert not game.violations, game.violations
    assert bot.state == bot.ST_DONE, (bot.state, bot.diagnostic)
    assert game.song == 12, game.song
    assert len(game.done[1]) == 4, game.done[1]
    assert game.done[1] == {"legend", "master", "hard", "normal"}, game.done[1]
    order = [entry[1] for entry in game.tap_log
             if entry[0] == "text" and entry[1] in DIFFICULTY_NAMES.values()]
    assert order[:3] == ["大师", "困难", "普通"], order[:3]
    assert game.tap_log.count(("coord", "next_song")) == 11
    print("all_difficulties: 传说>大师>困难>普通 顺序补齐、四难度齐全后才切歌")


def test_startup_requires_album_page():
    class NotAlbum(FakeGame):
        def capture(self):
            return {"width": WIDTH, "height": HEIGHT, "texts": [item("大厅", 640, 60)]}

    game = NotAlbum("legend")
    bot = AlbumBot(game)
    bot.start()
    assert bot.running is False
    assert bot.state == bot.ST_STOPPED
    assert "千音雅集" in bot.diagnostic
    print("启动检查: 未识别到“千音雅集”直接停止")


def test_missing_coordinates_blocks_start():
    class NoCoords(FakeGame):
        def getAlbumConfig(self):
            values = super().getAlbumConfig()
            values[0] = values[1] = -1
            return values

    bot = AlbumBot(NoCoords("legend"))
    bot.start()
    assert bot.running is False
    assert "坐标" in bot.diagnostic
    print("坐标未设置: 脚本拒绝启动并提示先记录坐标")


def test_all_difficulties_already_complete_advances_without_playing():
    game = FakeGame("all", done_by_song={1: {"legend", "master", "hard", "normal"}},
                    first_attempt_rate=100.0)
    bot = AlbumBot(game)
    run(bot)
    assert not game.violations, game.violations
    first_next = game.tap_log.index(("coord", "next_song"))
    first_start = game.tap_log.index(("text", "开始演奏"))
    assert first_start > first_next, "第 1 首四难度已达标时不应再演奏"
    assert game.done[1] == {"legend", "master", "hard", "normal"}
    print("all_difficulties: 四难度已完成时直接返回目录并切歌，不重复演奏")


def make_frame(entries):
    """entries: (text, x, y) -> an OCR frame in the album's landscape space."""
    from app.src.main.python.python.frame import Frame
    texts = [{"text": text, "left": x - 45, "top": y - 16, "right": x + 45, "bottom": y + 16}
             for text, x, y in entries]
    return Frame.from_host({"width": WIDTH, "height": HEIGHT, "texts": texts, "enemies": []})


def test_difficulty_mapping_by_position():
    bot = AlbumBot(FakeGame("all"))
    frame = make_frame([
        ("普通", 640, 300), ("困难", 640, 380), ("大师", 640, 460), ("传说", 640, 540),
        ("大音天籁", 950, 300),            # 普通已达标
        ("大音天籁", 950, 460),            # 大师已达标
        ("开始演奏", 640, 650),
    ])
    done = bot._read_done_difficulties(frame)
    assert done == {"normal": True, "hard": False, "master": True, "legend": False}, done
    print("难度映射: “大音天籁”按 Y 坐标正确对应 普通/困难/大师/传说")


def test_difficulty_mapping_extrapolates_missing_label():
    bot = AlbumBot(FakeGame("all"))
    # OCR 漏掉“大师”，用三行锚点线性外推出第四行，仍然要判对。
    frame = make_frame([
        ("普通", 640, 300), ("困难", 640, 380), ("传说", 640, 540),
        ("大音天籁", 950, 460),            # 大师行（外推）
        ("大音天籁", 950, 540),            # 传说行
    ])
    done = bot._read_done_difficulties(frame)
    assert done == {"normal": False, "hard": False, "master": True, "legend": True}, done
    print("难度映射: 名称漏识别时按行距外推，仍能定位大师/传说")


def test_rate_parsing():
    bot = AlbumBot(FakeGame("legend"))
    assert bot._read_rate(make_frame([("演奏完成率", 640, 300), ("100.0%", 640, 340)])) == 100.0
    assert bot._read_rate(make_frame([("演奏完成率 98.5%", 640, 300)])) == 98.5
    assert bot._read_rate(make_frame([("演奏完成率", 640, 300), ("100％", 640, 340)])) == 100.0
    # 没有“演奏完成率”标签、又存在多个百分比时必须读不出来，而不是瞎猜。
    assert bot._read_rate(make_frame([("最高完成率 100.0%", 640, 200), ("本次 97.0%", 640, 400)])) is None
    print("完成率解析: 标签+数值、同行、百分号缺失兜底与多值拒绝均正确")


def test_next_song_waits_for_directory_without_alert():
    class NoTitle(FakeGame):
        def capture(self):
            # 目录还在加载：既没有“千音雅集”，也没有别的可点目标。
            return {"width": WIDTH, "height": HEIGHT, "texts": [item("加载中", 640, 300)]}

    game = NoTitle("legend")
    bot = AlbumBot(game)
    bot.running = True
    bot.state = bot.ST_NEXT
    bot._song_index = 3
    for _ in range(30):
        bot.step()
    assert game.tap_log == [], game.tap_log
    assert getattr(game, "alerts", []) == [], "缺少目录时不应发邮件"
    assert bot.state == bot.ST_NEXT
    print("目录检查: 未识别到“千音雅集”时只等待，不点下一首、不发邮件")


if __name__ == "__main__":
    test_startup_requires_album_page()
    test_missing_coordinates_blocks_start()
    test_difficulty_mapping_by_position()
    test_difficulty_mapping_extrapolates_missing_label()
    test_rate_parsing()
    test_next_song_waits_for_directory_without_alert()
    test_legend_only_retries_and_advances()
    test_all_difficulties_priority_and_no_early_advance()
    test_all_difficulties_already_complete_advances_without_playing()
    print("Album automation smoke test passed")
    sys.exit(0)
