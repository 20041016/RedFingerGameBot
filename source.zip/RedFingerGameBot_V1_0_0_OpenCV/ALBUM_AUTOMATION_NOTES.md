# 专辑补分自动化（千音雅集）实现说明

对应《音游专辑自动脚本需求规格》。本模块只负责页面识别、完成判定、选难度、开始演奏、
结算判断、重试、切下一首、异常邮件提醒；打歌部分黑盒调用已有打歌模块 `music_bot.MusicBot`，
不改动其内部逻辑。

## 与需求条款的对应

| 需求 | 实现 |
| --- | --- |
| 2. 全屏 OCR/文字识别 | 复用项目现有方案：`RootHost.capture()`（Root `screencap` + ML Kit 中文 OCR）→ `frame.Frame` 文本行与边界框 |
| 2. 文字目标点击 / 自定义固定坐标点击 | 文字目标：OCR 文本行中心 `host.tap`；固定坐标：`coord_next_song`、`coord_difficulty_done_return`（1280×720 参考系，经 `CoordinateMapper` 映射，与游戏挂机坐标同空间、同一套坐标记录流程） |
| 2. 打歌模块黑盒调用 | `MusicBot.start() / step() / stop()`，仅在“开始演奏/再次演奏”后启动 |
| 2. 等待下一个目标出现 | 所有跳转均先 OCR 确认目标文字/目标页面再点击，无固定延时盲点（`_wait_note` 只轮询） |
| 3. 启动前配置项 | `completion_mode`、`coord_next_song`、`coord_difficulty_done_return` 由悬浮窗“专辑补分参数”窗口配置（SharedPreferences `album_config`）；`album_song_count=12`、`target_completion_rate=100.0%`、无限重试为代码常量；邮件配置复用现有“邮箱提醒设置”（`EmailSettingsActivity` / `EmailAlertManager`） |
| 4.1 启动检查 | `START` 阶段全屏识别“千音雅集”，仅检查一次；未识别到直接停止，不发邮件 |
| 4.2 切下一首前目录检查 | `RETURN_NEXT` 阶段必须识别到“千音雅集”才点击 `coord_next_song`；未识别到属于等待（默认无限等，状态文案每分钟刷新避免误报卡死），不发邮件 |
| 5. 专辑主循环 | 固定 12 首循环，`song_index` 计数，12 首完成后停止脚本 |
| 6.1 难度选择页 | 点击“前往演奏”→ 等待难度页（超时 30s 发邮件）→ 全屏识别“大音天籁”并按屏幕位置映射到 普通/困难/大师/传说 |
| 6.2 模式 A/B | `legend_only` / `all_difficulties` 按需求伪代码实现；补难度优先级 传说>大师>困难>普通 |
| 7. 结算与重试 | 结算页判定 = 全屏识别“演奏完成率”；读取完成率（容忍 OCR 误识别 l/0、全角％）；<100.0% 直接“再次演奏”并重新调用打歌模块（不重新选曲/选难度，不查温度），无限重试 |
| 8. 异常处理 | 弹窗/网络异常/加载失败/等待超时/其他非预期界面 → `host.sendEmailAlert`（`EmailAlertManager.sendAlertAsync`，5 分钟最小间隔防刷屏） |

## 实机问题修复（第一轮反馈）

### 1. 点击“前往演奏”有时点不中

原因：① OCR 会把按钮文字与邻近文字合并成一行，行框中心偏到两块文字中间；
② 截图+OCR 有 0.3~0.8s 延迟，动画/浮球遮挡时点下去无反应，而原实现点一次就不再重试。

修复（album_bot.py）：
- 点击位置按目标文字在 OCR 行内的**比例位置**计算（合并行时点在目标文字自身范围内）；
- 点击后继续“等待下一个目标出现”：超过 2.5s 仍未跳转且按钮仍在 → 换位置（行框 30%/70% 高度）
  重试，最多 3 次；仍无响应按“点击无响应”发异常邮件。

### 2. 点击“开始演奏”后一启动打歌模块就卡屏（画面冻结、熄屏无效、系统有声）

原因：黑盒的采样通道是 `screenrecord --output-format=raw-frames` 常驻录屏流（README 标注
“实验版”、从未实机验证）；同时 OCR 监视线程在跑 `screencap`——两个抓屏通道并发打
SurfaceFlinger，云手机虚拟化显示合成器被卡死后画面帧不再更新；另外加载页深色背景会让
六轨采样全程“蓝值<220”，打歌模块六根手指在加载期一直按着。

修复：
- **打歌采样默认切到安全的 screencap 路径**（`album_config.music_capture_mode`，与 OCR 监视
  共用 synchronized 的 screencap 通道，串行化、绝不并发抓屏）；`screenrecord` 保留为可选
  实验模式（悬浮窗“专辑补分参数”里可切换，实测稳定后再用）。
- **打歌模块启动保护**（`album_config.music_start_hold_ms`，默认 6000ms，可调 0~15000）：
  点击“开始演奏/再次演奏”后先只开 OCR 监视、不注入触点，加载期结束后才启动黑盒。

### 实机定位建议（如果仍卡屏）

1. 先跑独立“音游辅助”模式：若同样卡 → 问题在黑盒采集/触控链路而非专辑流程；
2. 悬浮窗“专辑补分参数”确认“打歌采样模式”为 `screencap`；若切到 `screenrecord` 才卡 →
   证实是 raw-frames 流卡显示合成器；
3. 若 screencap 模式仍卡 → 嫌疑收窄到 sendevent 触控注入（getevent 选错设备节点），把
   `logcat -s RFG-Touch RFG-ScreenCapture RFG-RootHost` 和悬浮窗诊断文字发回分析。

## 实机问题修复（第二轮反馈）

### 3. 悬浮窗日志文字被截屏 OCR 识别到

悬浮窗状态/诊断文案（含“前往演奏/开始演奏”等目标词）会出现在截屏里被 OCR 识别，
造成误匹配/点到悬浮窗上。修复：OCR 遮罩——悬浮窗与坐标窗口的屏幕矩形实时同步到
`RootHost.setOverlayOcrMask / setWindowOcrMask`，落在遮罩区域内的 OCR 文本行全部丢弃，
不影响悬浮窗继续显示日志。

### 4. 难度页/结算页误报“缺少目标按钮”

原因：① ML Kit 常在按钮文字间插空格或拆行（“开 始 演 奏”“开始/演奏”），精确子串匹配不上；
② 页面识别到时按钮可能还没渲染完，原代码当帧找不到就直接报异常。修复：匹配改为去空白 +
跨行拼接定位；按钮未出现属于“等待下一个目标出现”（带超时），不再当帧报异常。

### 5. 黑盒采样不正常（不卡屏后遗留）

修复：screencap 采样改用**常驻 Root shell**（免逐帧起 su 进程，显著提速）；PNG 按块结构
解析帧边界；采样坐标方向可配 `music_capture_axis`（auto/direct/rot90/rot270）——前 3 帧会打
日志 `screencap 采样映射 WxH → 方向，蓝值 [...]`（logcat -s RFG-RootHost）：
- 若蓝值一直不动/明显不对 → 在悬浮窗“专辑补分参数”里切 `music_capture_axis` 试 direct/rot90/rot270；
- 若 FPS 过低仍打不中 → 把悬浮窗诊断文字和上述日志发回。

## 配置项补充（album_config）

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `music_capture_mode` | `screencap` | 打歌采样通道；`screenrecord` 为实验快路径 |
| `music_capture_axis` | `auto` | screencap 坐标方向：auto/direct/rot90/rot270 |
| `music_start_hold_ms` | `6000` | 打歌模块启动保护时长，0 = 立即启动 |
| `catalog_wait_max_ms` | `0` | 切下一首前目录检查最长等待，0 = 无限 |

## 新增/修改文件

- `app/src/main/python/python/album_bot.py` — 新增，`AlbumBot` 状态机（Python 引擎，Chaquopy 调用）
- `app/src/main/java/com/redfinger/gamebot/RootHost.java` — 新增 `getAlbumConfig()`、`sendEmailAlert()`、
  后台 OCR 监视线程 `startOcrWatcher/getOcrWatchFrame/stopOcrWatcher`；`capture()` 改为 synchronized；
  `captureBlueValues` 支持 screencap/screenrecord 双采样通道（默认 screencap，串行化防并发抓屏）
- `app/src/main/java/com/redfinger/gamebot/EmailAlertManager.java` — 新增公开 `sendAlertAsync()`
- `app/src/main/java/com/redfinger/gamebot/BotService.java` — 新增 `MODE_ALBUM` 引擎接线、
  “专辑补分参数”悬浮窗（两个固定坐标 + 模式切换）、演奏阶段紧循环调度、12 首完成后自行停止
- `app/src/main/java/com/redfinger/gamebot/MainActivity.java` — 新增功能卡片“03 专辑补分”
- `ALBUM_ENGINE_SMOKE_TEST.py` — 新增，离线烟雾测试（验收标准 1–8）
- `MUSIC_ENGINE_SMOKE_TEST.py`、`PYTHON_ENGINE_SMOKE_TEST.py` — 修复历史遗留：FakeHost 补齐
  `getMusicCoordinateConfig` / `getGameCoordinateConfig`（两份旧测试在现版本引擎上本来就跑不过）

## 打歌期间的 OCR 结算检测（性能设计）

六轨打歌是 ~5ms 采样循环，把 ML Kit OCR（数百毫秒）塞进循环会漏按、永远达不到 100.0%。
因此打歌期间由 Java 侧后台线程（`RootHost.startOcrWatcher`，默认 800ms 一帧）做全屏 OCR，
Python 每 250ms 读一次监视帧判断“演奏完成率”/异常，节奏循环零阻塞；
监视帧超过 10s 无更新时自动回退为演奏中直采兜底。

## 难度“大音天籁”的位置映射

1. 优先按 OCR 识别到的难度名（普通/困难/大师/传说）位置，把“大音天籁”徽标映射到最近的难度；
2. 难度名识别不到时，用可配置的位置兜底 `difficulty_slots`（屏幅比例，默认四行
   `0.5,0.25;0.5,0.42;0.5,0.58;0.5,0.75`，顺序由 `difficulty_order`（默认“普通,困难,大师,传说”）决定）。
   如果实机布局是四列横向排列，请把 slots 改成对应列比例。
3. 点击难度：优先点难度名文字；文字不可见时点其槽位坐标。

## 【待确认】项的当前处理

- 邮件配置：复用现有邮箱提醒设置界面（SMTP 服务器/端口/账号/授权码/收件人），未做新配置项。
- 切下一首前等“千音雅集”：默认无限等待（不发邮件）；`album_config.catalog_wait_max_ms` 可设最长等待，超时按异常发邮件。
- 发邮件后动作：`on_exception` = `stop`（默认，邮件后停止脚本）或 `continue`（邮件后持续等待/重试，
  只在目标出现才点击，等价于“暂停等待人工/记录后继续重试”）。界面里可切换。

## 验证状态

- `python3 ALBUM_ENGINE_SMOKE_TEST.py` 17 项全部通过（含验收标准 1–8、点击重试、
  OCR 空格/拆行容错、按钮未渲染等待、打歌启动保护的离线模拟）。
- `MUSIC_ENGINE_SMOKE_TEST.py`、`PYTHON_ENGINE_SMOKE_TEST.py` 回归通过。
- 4 个改动的 Java 文件通过 javalang 语法解析检查。
- 本环境无 Android SDK/Gradle，**未构建 APK、未在红手指实机验证**；上线前需实机确认：
  1. 难度选择页布局与“大音天籁”位置映射（必要时调整 `difficulty_slots`/`difficulty_order`）；
  2. 两个固定坐标的记录与点击；
  3. 打歌期间后台 OCR 监视线程对实机帧率的影响；
  4. 结算页“演奏完成率”实际 OCR 文案与完成率数值读取。
