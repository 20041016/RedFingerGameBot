# PRESS_LEAD_MS floating setting

- The music floating settings window includes a signed integer input for `PRESS_LEAD_MS`.
- Default: `60` ms. Accepted range: `-1000` to `1000` ms.
- Save stores the value in the existing `music_coordinates` SharedPreferences.
- If music mode is already running, the new value is applied to the Python engine asynchronously; otherwise it is loaded on the next music-engine start.
- Restore Default resets this value to `60` along with the music coordinate defaults.
