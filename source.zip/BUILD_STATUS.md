# V0.7 构建状态

- [x] V0.6 Android 工程骨架
- [x] Root su 路径兼容：优先探测红手指 `/data/.mci/su`
- [x] APK 内 Root 身份预检：检查 `uid=0`，未授权时停止自动操作
- [x] 服务停止流程调整，避免在单线程循环上排队等待 stop()
- [x] 悬浮窗支持拖动
- [x] 添加 GitHub Actions 云端 Debug APK 构建工作流
- [x] 添加手机浏览器云构建说明
- [ ] 云端 Gradle 构建首次验证
- [ ] 红手指 APK Root 授权实测
- [ ] 实机截图方向与触控坐标核对
- [ ] 实机 OCR 场景识别测试
- [ ] 完整挂机流程测试

**本版本是更完整的 Android 工程源码，不是已编译 APK。**
