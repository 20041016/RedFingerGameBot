package com.redfinger.gamebot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BotService extends Service {
    public static final String ACTION_START = "com.redfinger.gamebot.START";
    public static final String ACTION_STOP = "com.redfinger.gamebot.STOP";
    private static final String CHANNEL = "rfgb_service";
    private static final int NOTIFICATION_ID = 601;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean active = false;
    private RootHost host;
    private PyObject engine;
    private WindowManager windowManager;
    private View overlay;
    private TextView status;
    private boolean engineStarted = false;
    private WindowManager.LayoutParams overlayParams;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            active = false;
            removeOverlay();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification("正在初始化"));
        if (!active) {
            active = true;
            showOverlay();
            worker.execute(this::initializeAndLoop);
        }
        return START_STICKY;
    }

    private void initializeAndLoop() {
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            host = new RootHost(getCacheDir());

            // Do not begin screenshot/touch automation until APK root access is confirmed.
            String rootInfo = host.checkRoot();
            host.log("Root 授权成功：" + rootInfo);
            updateStatus("Root 已授权，初始化 OCR");

            PyObject module = Python.getInstance().getModule("python.bot");
            engine = module.callAttr("GameBot", host);
            engine.callAttr("start");
            engineStarted = true;
            updateStatus("运行中");

            while (active) {
                try {
                    engine.callAttr("step");
                    Object state = engine.get("state").toJava(String.class);
                    updateStatus(String.valueOf(state));
                } catch (Exception e) {
                    host.log("挂机循环错误：" + e);
                    updateStatus("运行错误：" + e.getMessage());
                    Thread.sleep(1000);
                }
                if (active) Thread.sleep(300);
            }
        } catch (Exception e) {
            android.util.Log.e("RFG-Service", "初始化失败", e);
            updateStatus("初始化失败：" + e.getMessage());
            active = false;
        } finally {
            try {
                if (engine != null && engineStarted) engine.callAttr("stop");
            } catch (Exception ignored) {}
            if (host != null) host.close();
            host = null;
            engine = null;
            engineStarted = false;
            removeOverlay();
            main.post(() -> {
                stopForeground(true);
                stopSelf();
            });
        }
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(10, 6, 10, 6);
        panel.setBackgroundColor(0xDD202020);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setText("状态：正在初始化");
        panel.addView(status);

        Button stop = new Button(this);
        stop.setText("停止挂机");
        stop.setOnClickListener(v -> {
            active = false;
            removeOverlay();
            stopForeground(true);
            stopSelf();
        });
        panel.addView(stop);

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.x = 12;
        overlayParams.y = 120;

        // Drag the floating panel without intercepting the stop button click.
        final int[] down = new int[2];
        final float[] touch = new float[2];
        panel.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                down[0] = overlayParams.x;
                down[1] = overlayParams.y;
                touch[0] = event.getRawX();
                touch[1] = event.getRawY();
                return false;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                overlayParams.x = down[0] + (int) (event.getRawX() - touch[0]);
                overlayParams.y = down[1] + (int) (event.getRawY() - touch[1]);
                try { windowManager.updateViewLayout(panel, overlayParams); }
                catch (Exception ignored) {}
                return true;
            }
            return false;
        });

        overlay = panel;
        try { windowManager.addView(overlay, overlayParams); }
        catch (Exception e) {
            android.util.Log.e("RFG-Service", "悬浮窗创建失败", e);
            overlay = null;
            status = null;
        }
    }

    private void updateStatus(String value) {
        main.post(() -> {
            if (status != null) status.setText("状态：" + value);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(value));
        });
    }

    private void removeOverlay() {
        main.post(() -> {
            if (overlay != null) {
                try { windowManager.removeView(overlay); }
                catch (Exception ignored) {}
                overlay = null;
                status = null;
            }
        });
    }

    private Notification buildNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("RedFinger GameBot")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "挂机服务", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        active = false;
        removeOverlay();
        worker.shutdown();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
