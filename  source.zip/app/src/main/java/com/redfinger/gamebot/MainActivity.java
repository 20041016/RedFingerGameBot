package com.redfinger.gamebot;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 701;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);

        TextView title = new TextView(this);
        title.setText("RedFinger GameBot V0.6\n独立挂机引擎");
        title.setTextSize(22);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("首次使用：授予悬浮窗权限，然后启动后台服务。Root 权限会在首次执行 su 时由红手指弹窗请求。");
        info.setTextSize(15);
        layout.addView(info);

        Button overlay = new Button(this);
        overlay.setText("授予悬浮窗权限");
        overlay.setOnClickListener(v -> requestOverlayPermission());
        layout.addView(overlay);

        Button start = new Button(this);
        start.setText("启动挂机服务");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
                return;
            }
            Intent i = new Intent(this, BotService.class);
            i.setAction(BotService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        });
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("停止挂机服务");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, BotService.class);
            i.setAction(BotService.ACTION_STOP);
            startService(i);
        });
        layout.addView(stop);

        setContentView(layout);
    }

    private void requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
        }
    }
}
